# JuezMARP
Todos los ejercicios del juez de la asignatura de Métodos Algorítmicos y Resolución de Problemas

## Listado de ejercicios
### Los ~~ejercicios tachados~~ están mal o no acabados. Los temas ***en negrita e itálica*** están completos con todos los ejercicios correctos.
- [***Tema 1 - Árboles AVL, árboles binarios de búsqueda y conjuntos mediante árboles***](./Tema1)
    - [1-1 : ¿Es un árbol AVL?](./Tema1/EJ1/EJ1.cpp) // [<font color="dodgerblue">Enunciado</font>](./Enunciados/T1/EJ1.pdf)
    - [1-2: k-ésimo menor elemento](./Tema1/EJ2) // [<font color="dodgerblue">Enunciado</font>](./Enunciados/T1/EJ2.pdf)
    - [1-Opcional 1 : Añadir la operación minimum a la clase Set](./Tema1/OPC1/)
- [Tema 2 - Colas de prioridad, montículos binarios, heapsort y colas de prioridad variable](./Tema2)
    - [2-1: Lo que cuesta sumar](./Tema2/EJ1/EJ1.cpp) // [<font color="dodgerblue">Enunciado</font>](./Enunciados/T2/EJ1.pdf)
    - [2-2: Unidad Curiosa de Monitorización](./Tema2/EJ2/EJ2.cpp) // [<font color="dodgerblue">Enunciado</font>](./Enunciados/T2/EJ2.pdf)
    - [2-3: Ordenando a los pacientes en urgencias](./Tema2/EJ3/EJ3.cpp)
    - [2-4: Multitarea](./Tema2/EJ4/EJ4.cpp)
    - [2-5: La Ley D'Hondt](./Tema2/EJ5/EJ5.cpp)
    - [2-6: Pájaros en vuelo](./Tema2/EJ6)
    - [2-7: Volando drones](./Tema2/EJ7/EJ7.cpp)
    - [2-8: Tridente de temas candentes](./Tema2/EJ8)
    - [~~2-Opcional 80: Coleccionando comics~~](./Tema2/OPC80/OPC80.cpp)
- [Tema 3 - Grafos](./Tema3)
    - [Tema 3.1 - Grafos no dirigidos y sus recorridos](./Tema3/3.1)
        - [3-1: Árboles libres](./Tema3/3.1/EJ1/EJ1.cpp)
        - [3-2: Los amigos de mis amigos son mis amigos](./Tema3/3.1/EJ2/EJ2.cpp)
        - [3-3: Detección de manchas negras](./Tema3/3.1/EJ3/EJ3.cpp)
    - [Tema 3.2 - Grafos dirigidos y sus recorridos]



