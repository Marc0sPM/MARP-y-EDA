/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * MARP34 Miguel Ramírez Castrillo
 * MARP21 Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include "IndexPQ.h"
#include <unordered_map>
using namespace std;


/*@ <answer>
 Para resolver este problema hacemos uso de la clase IndexPQ, modificándola para que en lugar de aceptar
 solamente enteros, acepte strings (realmente cualquier tipo, lo hemos hecho genérico),
 modificando el vector de posiciones por un unordered_map de mV (map-value) a posiciones.
 Modificamos también algunos métodos que lo necesiten para implememntar el unordered_map.

 Luego, en el main, nos creamos un struct tweet, que va a guardar información referente a los eventos
(en este caso, el número de citas que tenga y su antigüedad, en tiempo). También tenemos
 un struct comparator que implementa la comparación para ver qué evento tiene más prioridad que otro.

 Finalmente, en el método resuelveCaso declaramos un IndexPQ<tweet, string, comparator> (hemos modificado
 el template de IndexPQ para que no solo haya que pasarle el tipo a comparar, sino para que también nos
 pida el tipo que va a tener nuestro unordered_map como clave, en este caso, un string) y declaramos
 también un unordered_map registro de string a tweet, el cual se encargará de ser un soporte a la hora
 de sumar y restar el número de citas al evento correspondiente.

 En la entrada hacemos un switch detectando si bien estamos en un caso 'C', un caso
 'E' y un caso 'TC', al mismo tiempo que nos guardamos en el unordered_map registro las prioridades a la hora
 de actualizarlas (debido a que el método update simplemente sustituye una prioridad por otra, en lugar
 de sumarlas). Si estamos en los casos C o E, actualizamos su información en registro y finalmente
 actualizamos su información en el IndexPQ. Si estamos en el caso TC, simplemente hacemos top y pop
 tres veces, guardando los elementos popeados en un vector temporal, y posteriormente los volvemos a
 insertar una vez hayamos terminado de mostrarlos.

 Como las complejidades de las operaciones de inserción, búsqueda y count del unordered_map son constantes,
 solo nos importarán las relativas al propio IndexPQ. El método update tiene complejidad O(log k), y este
 se llama de manera única si se trata de las operaciones C y E; mientras que la operación TC llama
 3 veces al método pop (O(log k)) y otras 3 veces al método update (O(log k)), y 3 veces al
 método vector::push_back (O(1)), por tanto TC también sería O(log k) [siendo k el número de elementos
 insertados en la PQ], por lo que al final nos queda que la complejidad del ejercicio es O(n log k), siendo
 n el número de eventos que se consulten y k el número de temas insertados en el IndexPQ.

 PD: Miguel (MARP34) también lo ha enviado desde casa para probar una solución puesto que en el laboratorio
 nos ha dado WA, por lo que no es necesario corregirle a él.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct tweet {
    int numCitas;
    int momento;
};

struct comparator {
    bool operator()(const tweet& prio1, const tweet& prio2) {
        return prio1.numCitas > prio2.numCitas || ((prio1.numCitas == prio2.numCitas) && prio1.momento > prio2.momento);
    }
};

bool resuelveCaso() {

    int numEventos;
    cin >> numEventos;

    if (!cin)
        return false;

    string op, hashtag;
    int numCitas;
    IndexPQ<tweet, std::string, comparator> pQ;
    unordered_map<string, tweet> registro;
    for (int i = 0; i < numEventos; ++i) {
        cin >> op;
        if (op == "C" || op == "E") {
            cin >> hashtag >> numCitas;
            if (registro.count(hashtag) == 0) {
                registro[hashtag] = { numCitas, i };
            }
            else {
                if (op == "E") numCitas *= -1;
                registro[hashtag] = { registro[hashtag].numCitas + numCitas, i };
            }
            pQ.update(hashtag, registro[hashtag]);
        }
        else {
            vector<pair<string, tweet>> aux;
            int x = 3;
            if (pQ.size() < 3) x = pQ.size();
            for (int i = 1; i <= x; ++i) {
                std::cout << i << " " << pQ.top().elem << "\n";
                //std::cout << i << " " << pQ.top().elem << " citas: " << pQ.top().prioridad.numCitas << " tiempo: " << pQ.top().prioridad.momento << "\n";
                aux.push_back({ pQ.top().elem, pQ.top().prioridad });
                pQ.pop();
            }
            for (auto e : aux) pQ.update(e.first, e.second);
        }
    }
    std::cout << "---\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Resolvemos
    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}



