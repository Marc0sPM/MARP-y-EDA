/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * MARP21 Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <limits>
#include <queue>
#include <vector>
using namespace std;


/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct partido {
    long indice;
    long votos;
    long escanos;
    double coeficiente;

    partido(long indice, long votos, long escanos, long coeficiente) : indice(indice), votos(votos), escanos(escanos), coeficiente(coeficiente) {}

};

bool operator<(const partido& a, const partido& b) {
    return (a.coeficiente < b.coeficiente || ((a.coeficiente == b.coeficiente) && a.votos < b.votos) || (a.coeficiente == b.coeficiente) && (a.votos == b.votos) && a.indice > b.indice);
}

bool resuelveCaso() {

    // leemos la entrada
    int C, N;
    cin >> C >> N;

    if (C == 0)
        return false;

    priority_queue<partido> queue;
    vector<partido> partidosOrden;

    // leer el resto del caso y resolverlo

    for(int i = 0; i < C; ++i) {
        int votos = 0;
        cin >> votos;
        auto tmp = partido(i, votos, 0, (double)votos);
        queue.push(tmp);
        partidosOrden.push_back(tmp);
    }
    for(int j = 0; j < N; ++j) {
        auto p = queue.top();
        queue.pop();
        p.escanos++;
        p.coeficiente = (double)p.votos/(1.0 + (double)p.escanos);
        partidosOrden[p.indice] = p;
        queue.push(p);
    }

    for(int k = 0; k < C; ++k) {
        cout << to_string(partidosOrden[k].escanos) + " ";
        queue.pop();
    }
    cout << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Resolvemos
    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
