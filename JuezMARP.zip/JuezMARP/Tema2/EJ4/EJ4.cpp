/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include <string>
using namespace std;

/*@ <answer>
    Para resolver este ejercicio hacemos uso de un struct DatosTarea que nos guardará la información
    correspondiente a cada nueva tarea: comienzo, final y periodo, que son bastante descriptivos.
    Definimos también el operator<, ya que vamos a usar una cola de menores.

    Leemos la entrada (diferenciamos en si tenemos o no tenemos repeticiones para cambiar periodo por 0
    o su correspondiente valor).

    Y posteriormente llamamos al método conflicto, que saca el elemento prioritario, lo compara con el tiempo
    actual (inicialmente, -1). Si el tiempo es mayor que el inicio de nuestra tarea, es que tenemos un conflicto.
    Si no, igualamos el tiempo al final de la tarea con la que lo hemos comparado, y en caso de tener
    repeticiones, lo introducimos dentro de la cola con su nuevo inicio y final. Para evitar problemas
    con tareas que sobrepasen nuestro tiempo, introducimos como máximo (tanto aquí como en la lectura)
    el mínimo entre el tiempo que queremos procesar y el final de la tarea.

    Por tanto, como la complejidad de introducir un elemento es O(log n) y la de sacar uno es también
    O(log n), pero no sabemos cuántas consultas K tendremos en un tiempo T (depende de cuánto sea el
    periodo de cada consulta), por tanto tendremos que la complejidad total será O(K log n), siendo K
    el número de consultas que se realicen dado un tiempo T.
 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct DatosTarea {
    long long comienzo, final, periodo;

    bool operator<(const DatosTarea& other) const {
        return (other.comienzo < this->comienzo || (other.comienzo == this->comienzo && other.final < this->final));
    }
};

bool conflicto(priority_queue<DatosTarea>& q, long long periodo) {
    int final = -1;
    bool conflictoBool = false;
    while(!q.empty() && !conflictoBool) {
        auto e1 = q.top();
        q.pop();
        if(final > e1.comienzo) conflictoBool = true;
        final = e1.final;
        if(e1.periodo > 0) {
            if(!q.empty() && (e1.comienzo + e1.periodo) <= periodo) {
                q.push({e1.comienzo + e1.periodo, min(periodo, e1.final + e1.periodo), e1.periodo});
            }
        }
    }
    return conflictoBool;
}

bool resuelveCaso() {
    if (!std::cin)  // fin de la entrada
        return false;

    long long tareasUnicas = 0, tareasRepetitivas = 0, periodo = 0;
    cin >> tareasUnicas >> tareasRepetitivas >> periodo;
    priority_queue<DatosTarea> queue;

    for(int i = 0; i < tareasUnicas; ++i) {
        long long comienzo = 0, final = 0;
        cin >> comienzo >> final;
        queue.push({comienzo, min(final, periodo) ,0});
    }
    for(int j = 0; j < tareasRepetitivas; ++j) {
        long long comienzo = 0, final = 0, periodoRep = 0;
        cin >> comienzo >> final >> periodoRep;
        queue.push({comienzo, min(final, periodo) ,periodoRep});
    }

    if (!std::cin)  // fin de la entrada
        return false;

    conflicto(queue, periodo) ? cout << "SI\n" : cout << "NO\n";

    // COMPLETAR
    return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}

