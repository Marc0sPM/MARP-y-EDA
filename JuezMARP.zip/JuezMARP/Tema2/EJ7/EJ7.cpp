
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

/*@ <answer>

    Para resolver este ejercicio he utilizado dos clases, caja_pilas, que contendrá 2 priority_queues de
    enteros, una con las pilas de 9 voltios y otra con las pilas de 1.5 voltios, y métodos para devolver
    el top de cada una de las colas de prioridad, para insertar, y para comprobar si son vacías o no, luego
    todos los métodos de esta clase son de complejidad constante O(1), menos los de inserción, que son
    logarítimicos en el número de pilas, O(log A) y O(log B), respectivamente;
    y la clase dron, que contiene dos enteros a modo de pilas (una de 9v y otra de 1.5v)
    y un booleano haVolado que nos indica si ese dron ya ha volado ese fin de semana,
    así como métodos que insertan las pilas y un método vuela, que le resta las horas correspondientes
    de vuelo de ese fin de semana a las dos pilas que están en el dron, luego que todos los métodos
    de esta clase son consantes O(1).

    Finalmente, en el método resuelveCaso se lee la entrada y se inserta tanto en un vector de drones
    como en nuestra caja de pilas; entonces, siendo N el número de drones, A el número de pilas de 9v
    y B el número de pilas de 1.5v, tenemos que la lectura es O(max[N,A * log(A),B * log(B)]). Por otra parte, para la resolución
    del problema, tenemos un bucle que acaba cuando una de las cajas está vacía, y recorre primero una vez
    todos los drones insertando las pilas y haciéndolos volar, devolviendo el número de horas voladas y sumándoselo
    a un total. Después, se vuelve a recorrer el vector de drones para reinsertar las pilas que no estén vacías
    (cuyas horas sean mayores que 0) de nuevo en la caja y finalmente imprimiendo por pantalla el número de horas
    voladas en cada fin de semana.

    Por tanto, la complejidad final del ejercicio, sin tener en cuenta la lectura de la entrada,
    es la de recorrer dos veces el vector de drones e insertar de nuevo en la caja las pilas, por tanto
    O(min[A,B] * N * max[log(A), log(B)]), siendo el min[A,B] el número de veces que el bucle while
    se repite (es decir, el mínimo número de pilas que haya en la caja).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>


class caja_pilas {
public:
    priority_queue<int> pilas_9v;
    priority_queue<int> pilas_1_5v;

    int top9voltios() {
        int tmp = pilas_9v.top();
        pilas_9v.pop();
        return tmp;
    }

    int top1p5voltios() {
        int tmp = pilas_1_5v.top();
        pilas_1_5v.pop();
        return tmp;
    }

    void insertar9v(int pila) {
        if(pila > 0) pilas_9v.push(pila);
    }

    void insertar1p5v(int pila) {
        if(pila > 0) pilas_1_5v.push(pila);
    }

    bool vacia() const { return pilas_9v.empty() || pilas_1_5v.empty();}
};

class dron {
public:
    int pila_9v;
    int pila_1_5v;
    bool haVolado = false;

    int vuela() {
        int horasVoladas = std::min(pila_9v, pila_1_5v);
        pila_9v -= horasVoladas;
        pila_1_5v -= horasVoladas;
        return horasVoladas;
    }

    void insertarPilas(int pila9v, int pila1p5v) {
        this->pila_9v = pila9v;
        this->pila_1_5v = pila1p5v;
    }

    dron() : pila_9v(0), pila_1_5v(0) {}
};

bool resuelveCaso() {

    int drones, pilas9v, pilas1p5v;
    cin >> drones >> pilas9v >> pilas1p5v;

    // leer los datos de la entrada

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones

    std::vector<dron> vectorDrones;
    caja_pilas caja;

    int horas = 0;
    for(int i = 0; i < pilas9v; ++i) {
        cin >> horas;
        caja.insertar9v(horas);
    }

    for(int j = 0; j < pilas1p5v; ++j) {
        cin >> horas;
        caja.insertar1p5v(horas);
    }

    for(int k = 0; k < drones; ++k) {
        vectorDrones.push_back(dron());
    }

    // escribir la solución
    while(!caja.vacia()) {
        int tiempoAcum = 0;
        for(auto it = vectorDrones.begin(); it != vectorDrones.end(); ++it) {
            if(!caja.vacia()) {
                it->insertarPilas(caja.top9voltios(), caja.top1p5voltios());
                tiempoAcum += it->vuela();
                it->haVolado = true;
            }
        }

        for(auto ot = vectorDrones.begin(); ot != vectorDrones.end(); ++ot) {
            if(ot->haVolado) {
                caja.insertar9v(ot->pila_9v);
                caja.insertar1p5v(ot->pila_1_5v);
                ot->haVolado = false;
            }
        }
        std::cout << tiempoAcum << " ";
    }
    std::cout << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
