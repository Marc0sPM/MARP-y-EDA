/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include <string>
#include <stack>
#include <climits>
using namespace std;

/*@ <answer>

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct comic {
    long id;
    long pila;
};

bool operator<(const comic& a, const comic& b) {
    return a.id > b.id;
}

bool resuelveCaso() {
    if (!std::cin)  // fin de la entrada
        return false;

    long numeroPilas = 0;
    cin >> numeroPilas;

    priority_queue<comic> q;
    vector<stack<comic>> vC;

    long menor = LONG_MAX;
    for(int i = 0; i < numeroPilas; ++i) {
        int elems = 0;
        cin >> elems;
        stack<comic> tmp;
        for(int j = 0; j < elems; ++j) {
            int a;
            cin >> a;
            if(a < menor) menor = a;
            tmp.push({a, i});
        }
        vC.push_back(tmp);
        q.push(tmp.top());
    }
    if (!std::cin)  // fin de la entrada
        return false;

    int contador = 0;
    int numeroAnalizado = -1;
    while(numeroAnalizado != menor) {
        contador++;
        auto e = q.top();
        numeroAnalizado = e.id;
        q.pop();
        if(!vC[e.pila].empty()) {
            vC[e.pila].pop();
            q.push(vC[e.pila].top());
        }
    }

    cout << contador << "\n";


    // COMPLETAR
    return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}

