/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
using namespace std;

/*@ <answer>
    Para resolver este ejercicio hacemos uso de un struct DatosRegistro que nos guardará la información
    correspondiente a cada nuevo registro: tiempoEnvio es el tiempo en el que se mandará la
    información; la id es la id del registro; y el periodo es el tiempo en el que hay que mandar cada registro.
    En el struct, añado el operador <, que ordenará en una cola de prioridad (cola de menores) nuestros registros,
    siendo el menor el que tenga menor tiempo de envío (la acumulación de períodos), y en caso de igualdad, el que
    tenga menor identificador.

    Por último, vamos sacando los elementos de la cola de prioridad conforme estén ordenados, los sacamos por
    consola, le sumamos de nuevo el periodo a su tiempo de envío, y lo volvemos a introducir en la cola.

    Por tanto, como la complejidad de sacar un elemento de la cola es O(log n) y volver a introducirlo es
    O(log n), y tenemos que esta acción se repite K veces, siendo K el número de envíos, tenemos que
    la complejidad total de la solución es O(K log n), sin contar la complejidad de la introducción inicial
    de los elementos en la lista.
 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct DatosRegistro {
    long long tiempoEnvio;
    long id;
    long periodo;

    bool operator<(const DatosRegistro& other) const {
        return (other.tiempoEnvio < this->tiempoEnvio || (this->tiempoEnvio == other.tiempoEnvio && other.id < this->id));
    }
};


bool resuelveCaso() {
    int N;
    cin >> N;
    if (N == 0)
        return false;

    priority_queue<DatosRegistro> queue;

    for(int i = 0; i < N; ++i) {
        long id, periodo;
        cin >> id >> periodo;
        queue.push({periodo, id, periodo});
    }

    int envios;
    cin >> envios;

    for(int i = 0; i < envios; ++i) {
        auto e = queue.top();
        queue.pop();
        cout << e.id<<"\n";
        e.tiempoEnvio += e.periodo;
        queue.push(e);
    }
    cout << "---\n";

    // COMPLETAR

    return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
