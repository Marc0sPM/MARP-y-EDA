/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include <string>
using namespace std;

/*@ <answer>
    Para resolver este ejercicio hacemos uso de un struct DatosPaciente que nos guardará la información
    correspondiente a cada nuevo registro: dolencia es la dolencia de cada paciente;
    el nombre es el nombre del paciente; y el tiempoEspera es el tiempo en el que el paciente lleva esperando.
    Para mayor comodidad, el tiempo va al revés (a mayor sea el número, menos tiempo llevas esperando).
    En el struct, añado el operador >, que ordenará en una cola de prioridad (cola de mayores) nuestros registros,
    siendo el mayor el que tenga mayor dolencia y menor tiempoEspera (lleva más tiempo esperando) en caso de
    igualdad.

    Por cada consulta 'I' metemos un nuevo paciente a la cola de prioridad, y por cada consulta 'A', quitamos
    el de mayor prioridad.

    Por tanto, como la complejidad de introducir un elemento es O(log n) y la de sacar uno es también
    O(log n), sabiendo que tendremos en total K consultas, nuestra complejidad es de O(K log n), siendo K
    el número de consultas.
 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct DatosPaciente {
    unsigned long dolencia;
    string nombre;
    unsigned long tiempoEspera;

    bool operator>(const DatosPaciente& other) const {
        return (other.dolencia > this->dolencia || (this->dolencia == other.dolencia && other.tiempoEspera < this->tiempoEspera));
    }
};

bool resuelveCaso() {
    int N;
    cin >> N;
    if (N == 0)
        return false;

    priority_queue<DatosPaciente, vector<DatosPaciente>, std::greater<DatosPaciente>> queue;

    unsigned long bucles = 0;
    char consulta = ' ';
    unsigned long dolencia = 0;
    string nombre;
    for(int i = 0; i < N; ++i) {
        cin >> consulta;
        if(consulta == 'I') {
            cin >> nombre >> dolencia;
            queue.push({dolencia, nombre, bucles});
            ++bucles;
        }
        else if(consulta == 'A') {
            auto e = queue.top();
            queue.pop();
            cout << e.nombre << "\n";
        }
    }
    cout << "---\n";

    // COMPLETAR

    return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
