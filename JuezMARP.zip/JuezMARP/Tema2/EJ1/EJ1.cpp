/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
using namespace std;

/*@ <answer>
    Para resolver este ejercicio hacemos uso de una cola de mínimos y un acumulador (que va a ser nuestra
    solución). La solución mínima viene de ir sumando todo el rato los dos números más pequeños, es decir,
    en nuestro caso, los dos primeros elementos de la cola de mínimos. Los vamos sumando y los guardamos
    en un acumulador. El resultado de la suma se guarda posteriormente en la cola de mínimos (en la posición
    que le toque), y vamos repitiendo este proceso hasta que solo haya un elemento en la cola.

    La función es O(n), siendo n el número de elementos en la cola, ya que tenemos que recorrerlos todos
    una vez como máximo porque tenemos que obtener la suma final de todos los elementos.
 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

long long calcularEsfuerzo(priority_queue<long long, vector<long long>, greater<long long>>& queue) {
    if(queue.empty()) return 0;
    else {
        long long acum = 0;
        while(queue.size() > 1) {
            long long elem1 = queue.top();
            queue.pop();
            long long elem2 = queue.top();
            queue.pop();
            acum += elem1 + elem2;
            queue.push(elem1 + elem2);
        }
        return acum;
    }
}

bool resuelveCaso() {
    int N;
    cin >> N;
    if (N == 0)
        return false;

    priority_queue<long long, vector<long long>, greater<long long>> queue;
    int valor;
    if(N > 1) {
        for (int i = 0; i < N; ++i) {
            cin >> valor;
            queue.push(valor);
        }
    }
    else cin >> valor;

    // COMPLETAR
    cout << calcularEsfuerzo(queue) << endl;

    return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
