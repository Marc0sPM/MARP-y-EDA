
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include "TreeSet_AVL_tami.h"
using namespace std;


/*@ <answer>

 Para resolver este ejercicio usaremos un Set, implementado mediante árboles AVL
 que contendrá las edades de los pájaros. Haremos uso también del método k-ésimo que implementamos
 en el tema 1. Simplemente nos limitamos a introducir los elementos en el set y devolvemos el elemento
 mitad + 1, que es nuestra mediana.

 El coste, por tanto, es el de buscar el k-ésimo elemento, por tanto O(n/2 log n) ~ O(n log n)

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

bool resuelveCaso() {

    // leer los datos de la entrada
    int edad, pajaros;
    cin >> edad >> pajaros;

    if (edad == 0 && pajaros == 0)
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    Set<int> set;

    set.insert(edad);
    for(int i = 0; i < pajaros; ++i) {
        int paj1, paj2;
        cin >> paj1 >> paj2;
        set.insert(paj1);
        set.insert(paj2);
        cout << set.kesimo((set.size())/ 2 + 1) << " ";
    }
    cout << "\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
