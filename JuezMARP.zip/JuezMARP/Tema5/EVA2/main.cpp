
/*@ <authors>
 *
 * Alejandro Massó Martínez - MARP21
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <string>
#include <sstream>
#include "EnterosInf.h"
#include "Matriz.h"
using namespace std;


/*@ <answer>

 Para resolver este problema haremos uso de programación dinámica descendente. Siendo v y w listas de canciones,
 usaremos para este problema una matriz de tamaño (tam(v) + 1 x tam(w) + 1) inicializada a -1. Cada una de las
 celdas de la matriz, una vez rellenas, contendrá el número de canciones en común en las dos listas a la derecha
 de la posición de los iteradores i y j, por ejemplo, mat[0][0] devolverá el número de canciones en común entre
 las dos listas a partir de las posiciones 0 de la primera lista y 0 de la segunda (es decir, devolverá el número
 total de canciones en común). Para rellenar la matriz, se usará una recursión y unos casos base y
 recursivos que explicaremos a continuación:

 Casos base:
 Si el iterador i es mayor que el número de elementos en lista1, se devuelve 0
 (según nuestra explicación, es imposible que haya elementos comunes a la derecha del fin de la lista).
 Si el iterador j es mayor que el número de elementos en lista2, se devuelve 0 (la explicación es la misma).
 Casos recursivos:
 Si el elemento i-ésimo de la lista1 es distinto que el elemento j-ésimo de la lista2, devolveremos el máximo
 número de elementos comunes bien cambiando la i o bien la j, es decir, max(crearLista(i + 1, j), crearLista(i, j+1)).
 Si los elementos i-esimo de la lista1 y el j-ésimo de la lista2 coinciden, se elegirá el máximo valor en bien
 elegir esa canción y entre no elegirla, es decir, max(crearLista(i+1,j+1), max(crearLista(i+1,j),crearLista(i,j+1)))

 Al ser programación dinámica, cualquier caso que ya esté anteriormente resuelto se devuelve, por ello antes de nada
 se hace una comprobación para ver si la casilla está o no ya rellena (es decir, si es igual o no a -1). Si está
 rellena, se devuelve su valor, y si no, procede a rellenarse.

 Para reconstruir la solución basta con ir comprobando si el elemento (i,j) en la matriz es o bien igual al
 elemento (i+1, j), al elemento (i, j+1) o al elemento (i+1, j+1) + 1. Si es este último caso, procederemos a meter
 el valor de uno de los dos vectores (deben ser el mismo valor para los dos si está bien hecho el ejercicio) en el
 vector solución, que es el que llamaremos para imprimir por pantalla.

 Por tanto, la complejidad del ejercicio es del orden de O(tam(v), tam(j)) tanto en tiempo (si se da el caso
 de que ninguno de los elementos se repite en las listas, se recorrerá entera) como en espacio (es imposible
 reducir la solución a un vector puesto que se nos pide devolver la reconstrucción de la solución).

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

int crearLista(Matriz<int>& mat, const vector<string>& l1, const vector<string>& l2, int i, int j) {
    if(i >= mat.numfils() - 1) {
        mat[i][j] = 0;
        return 0;
    }
    else if(j >= mat.numcols() - 1) {
        mat[i][j] = 0;
        return 0;
    }
    int res = mat[i][j];
    if(res == -1) {
        if(l1[i] != l2[j]) {
            int tmp = max(crearLista(mat, l1, l2, i + 1, j), crearLista(mat, l1, l2, i, j+1));
            mat[i][j] = tmp;
            return tmp;
        }
        else{
            int tmp = max(crearLista(mat, l1, l2, i + 1, j + 1) + 1, max(crearLista(mat, l1, l2, i + 1, j), crearLista(mat, l1, l2, i, j+1)));
            mat[i][j] = tmp;
            return tmp;
        }
    } else return res;
}

vector<string> reconstruirSolucion(const Matriz<int>& m, const vector<string>& l1) {
    vector<string> tmp;
    for(int i = 0, j = 0; i < m.numfils() - 1 && j < m.numcols() - 1;) {
        if(m[i][j] == m[i+1][j]) ++i;
        else if(m[i][j] == m[i][j+1]) ++j;
        else if(m[i][j] == m[i+1][j+1] + 1) {
            tmp.push_back(l1[i]);
            ++i;
            ++j;
        }
    }
    return tmp;
}

vector<string> leerLista() {
  string linea;
  getline(cin, linea);
  if (!cin)
    return {};
  vector<string> sec;
  stringstream ss(linea);
  string pal;
  while (ss >> pal)
    sec.push_back(pal);
  return sec;
}


bool resuelveCaso() {
  
  // leemos la entrada
  auto lista1 = leerLista();
  if (!cin)
    return false;
  auto lista2 = leerLista();

  // resolver el caso
  
  Matriz<int> mat(lista1.size() + 1, lista2.size() + 1, -1);

  crearLista(mat, lista1, lista2, 0, 0);
  auto l3 = reconstruirSolucion(mat, lista1);
  for(auto e : l3) {
      std::cout << e << " ";
  }
  std::cout << "\n";
  
  return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
  // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  // Resolvemos
  while (resuelveCaso());
  
  // para dejar todo como estaba al principio
#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
#endif
  return 0;
}
