
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

/*@ <answer>
  
 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.
 
 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>


struct peliculas {
    int comienzo;
    int duracion;
    int final;
    peliculas(int comienzo, int duracion) : comienzo(comienzo), final(comienzo + duracion), duracion(duracion) {}
    friend bool operator<(const peliculas& p1, const peliculas& p2) {
        return p1.comienzo < p2.comienzo;
    }
};

int siguientePeli(int desde, const std::vector<peliculas>& pelis) {
    int descanso = 10;
    int i;
    for(i = desde + 1; i < pelis.size();) {
        if(pelis[i].comienzo > (pelis[desde].final + descanso)) {
            return i;
        }
        else ++i;
    }
    if(i == pelis.size()) return -1;
}

// tiempoMax(desde) = max(tiempoMax(desde + 1), duracion_desde + f(siguiente_pelicula_posible))
int tiempoMax(int desde, const std::vector<peliculas>& pelis) {
    if(desde == pelis.size()) return 0;

    int sig = siguientePeli(desde, pelis);
    if(sig != -1) return max(tiempoMax(desde + 1, pelis), tiempoMax(sig, pelis) + pelis[desde].duracion);
    else return pelis[desde].duracion;
}

bool resuelveCaso() {
   
   // leer los datos de la entrada
   int numPelis;

   cin >> numPelis;

    if (numPelis == 0)
        return false;

   std::vector<peliculas> pelis;

   for(int i = 0; i < numPelis; ++i) {
       int horas, minutos, comienzo, duracion;
       char sep;
       cin >> horas >> sep >> minutos >> duracion;
       peliculas tmp(horas*60 + minutos, duracion);
       pelis.push_back(tmp);
   }
   std::sort(pelis.begin(), pelis.end());
   cout << tiempoMax(0, pelis) << "\n";
   
   // resolver el caso posiblemente llamando a otras funciones
   
   // escribir la solución

   return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
   // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
   std::ifstream in("casos.txt");
   auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
   
   while (resuelveCaso());
   
   // para dejar todo como estaba al principio
#ifndef DOMJUDGE
   std::cin.rdbuf(cinbuf);
   system("PAUSE");
#endif
   return 0;
}
