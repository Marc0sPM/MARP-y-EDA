
/*@ <authors>
 *
 * Alejandro Massó Martínez - MARP21
 * Miguel Ramírez Castrillo - MARP34
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include "Matriz.h"
using namespace std;


/*@ <answer>

 Para resolver este problema hacemos uso de programación dinámica descendente.
 Para ello hacemos uso de una matriz de un tipo casilla, que contiene el valor de la casilla y el número de
 caminos que llegan a esa casilla desde el origen. En cada iteración del bucle solo se pasa una vez por cada casilla
 siempre y cuando haya un camino hasta esa casilla. Si la casilla cumple que su valor más su posición en cualquiera
 de las dos direcciones posibles (derecha y abajo) no excede los límites de la matriz, entonces se añadirá el número
 de casillas que referencien a esa casilla a la nueva casilla accedida. Para acceder al numero total de caminios que
 llegan al final de la matriz se accederá al valor matriz[N-1][M-1].numero una vez terminada la función.

 La llamada recursiva sería del tipo, siendo la función devolverCaminos(i, j), donde i son las filas y j las columnas
 y v(i,j) es el valor de la casilla (i,j):
 devolverCaminos(i + v(i,j), j), si i + v(i,j) <= N - 1 && devolverCaminos(i,j) != 0;
 devolverCaminos(i, j + v(i,j)) si j + v(i,j) <= M - 1 && devolverCaminos(i,j) != 0;

 Los casos base serían:
 devolverCaminos(0,0) = 1;

 La llamada inicial sería:
 devolverCaminos(0,0);

 El coste total del algoritmo es del orden O(N * M) tanto en tiempo como en espacio, debido a que aunque este
 método se haga de manera ascendente, es imposible guardarlo como un vector y acceder a la solución final (solo sería
 posible en el caso del problema del cambio de monedas) debido a que puede haber saltos de fila de valor mayor que 1.

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

struct casilla {
    int valor = 0;
    int numero = 0;
};

void devolverCaminos(Matriz<casilla>& mat, int N, int M) {
    for(int i = 0; i < N; ++i) {
        for(int j = 0; j < M; ++j) {
            if(mat[i][j].numero >= 1) {
                int tmp = mat[i][j].valor;
                if(i + tmp <= N-1) mat[i + tmp][j].numero += mat[i][j].numero;
                if(j + tmp <= M - 1) mat[i][j + tmp].numero += mat[i][j].numero;
            }
        }
    }
}

bool resuelveCaso() {
  
  // leemos la entrada
  int N, M;
  cin >> N >> M;

  if (!cin)
    return false;


  Matriz<casilla> mat(N, M, {0,0});

  // leer el resto del caso y resolverlo
  for(int i = 0; i < N; ++i) {
      for(int j = 0; j < M; ++j) {
          cin >> mat[i][j].valor;
      }
  }

  mat[0][0].numero = 1;
  devolverCaminos(mat, N, M);
  std::cout << mat[N-1][M-1].numero << "\n";
  
  return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
  // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  // Resolvemos
  while (resuelveCaso());
  
  // para dejar todo como estaba al principio
#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
#endif
  return 0;
}
