
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <limits>
using namespace std;

/*@ <answer>

 Para este problema plantearemos 3 algoritmos de programación dinámica (aunque realmente son 2 distintos):
 - Para calcular si se puede o no crear una cuerda con las cuerdas que tenemos y las maneras en las que se pueden hacer
 usaremos una recursión básica (en ambos casos iguales). Necesitaremos un vector con los tamaños de las cuerdas (v), el
 índice en el vector (i) y la longitud de la cuerda pedida (j). Si la longitud de la cuerda que se quiere usar es mayor que
 la longitud pedida (v[i] > j), llamaremos a la función con los parámetros (v, i - 1, j) (esto es, se comprobará si se
 puede formar la longitud con el resto de cuerdas de nuestro vector). Si es menor, devolveremos el resultado de no incluir
 esa cuerda (sePuede(v, i - 1, j)) o incluirla (sePuede(v, i-1, j - li)). Los casos base son, si la longitud es 0, entonces
 devolvemos true (o 1, en caso de las maneras) ya que siempre habrá una manera de hacer una cuerda de longitud 0 (no usando
 cuerdas de nuestro vector); y si no tenemos cuerdas que usar, devolveremos false (o 0), ya que es imposible formar
 una cuerda de longitud j sin cuerdas.

 - Para calcular el mínimo número de cuerdas necesarias y su coste mínimo bastará con implementar un algoritmo de
 programación dinámica ascendente, igual que el del cambio de monedas, sabiendo que para obtener el coste mínimo
 no podremos optimizar el problema espacialmente usando un vector, ya que, recordemos, solo el problema del cambio
 de monedas es el único que permite encontrar el número de monedas de cada tipo que se usan (en el caso de este
 problema, el coste mínimo) una vez optimizada su complejidad espacial de O(i, j) a O(j).

 Por tanto, el coste en tiempo de este problema es del orden de O(i * j), siendo igual la complejidad en espacio.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

int maneras(const vector<int>& cuerdas, int indice, int longitud) {
    if(longitud == 0) return 1;
    else if(indice == -1) return 0;

    if(cuerdas[indice] > longitud) return maneras(cuerdas, indice - 1, longitud);
    else return maneras(cuerdas, indice -1, longitud) + maneras(cuerdas, indice - 1, longitud - cuerdas[indice]);
}

struct minimosNumyCoste {
    int minimo;
    long coste;
};

minimosNumyCoste minimos(const vector<int>& cuerdas, const vector<int>& costes, int longitud) {
    minimosNumyCoste sol;
    int n = cuerdas.size();
    vector<vector<int>> tmp(n+1, vector<int>(longitud + 1, numeric_limits<int>::max()));
    tmp[0][0] = 0;
    for(int i = 1; i <= n; ++i) {
       tmp[i][0] = 0;
       for(int j = 1; j <= longitud; ++j) {
           if(cuerdas[i-1] > j) tmp[i][j] = tmp[i-1][j];
           else tmp[i][j] = min(tmp[i-1][j], tmp[i][j - cuerdas[i - 1]] + 1);
       }
    }
    sol.minimo = tmp[n][longitud];
    if(tmp[n][longitud] != numeric_limits<int>::max()) {
        int i = n, j = longitud;
        while (j > 0) {
            if (cuerdas[i - 1] <= j && tmp[i][j] != tmp[i - 1][j]) {
                sol.coste += costes[i - 1];
                j -= cuerdas[i - 1];
            } else --i;
        }
    }

    return sol;
}

bool resuelveCaso() {
    // leer los datos de la entrada
    int N, L;
    cin >> N >> L;

    vector<int> cordeles(N, 0);
    vector<int> costes(N, 0);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    for(int i = 0; i < N; ++i) {
        cin >> cordeles[i] >> costes[i];
    }

    int mn = maneras(cordeles, cordeles.size() - 1, L);
    cout << (mn != 0 ? "SI " : "NO\n");
    if(mn != 0) {
        minimosNumyCoste mins = minimos(cordeles, costes, L);
        cout << mn << " " << mins.minimo << " " << mins.coste << "\n";
    }

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
