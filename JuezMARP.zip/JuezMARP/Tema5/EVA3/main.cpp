
/*@ <authors>
 *
 * Alejandro Massó Martínez (MARP21)
 * Miguel Ramírez Castrillo (MARP34)
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include "EnterosInf.h"
using namespace std;


/*@ <answer>

    Para resolver este problema haremos uso de programación dinámica ascendente. Para ello adaptaremos el problema
    del cambio de monedas, explicado en la semana 10, utilizando un segundo vector, formas, que guardará el número
    de formas posibles de obtener el valor mínimo de monedas necesarias para pagar una cierta cantidad C.

    Se distinguirán en este problema dos recursiones: la recursión del cambio de monedas, y la de las formas:

    Para el cambio de monedas, será la siguiente:

    monedas(i,j) = min(monedas(i-1, j), monedas(i, j - vi) + 1), donde i es el índice la moneda en el vector de monedas,
    j es la cantidad a devolver y vi el valor de la moneda. En nuestro método, eso se consigue mediante el if - else if
    del método monedas.

    Por otra parte, tenemos la recursión formas, que es tal que:

    formas(i, j) = formas(i, j) + formas(i, j-vi), si monedas(i,j) == monedas(i, j-vi);
    formas(i, j) = formas(i, j-vi) si monedas(i,j) > monedas(i, j-vi).

    Los casos base son:
    monedas(i, 0) = 0;
    formas(i, 0) = 1;

    La complejidad en tiempo es del orden O(nC), siendo n el número de monedas y C la cantidad total, y en espacio,
    es del orden de O(C), ya que se usa un vector de tamaño C y no una matriz.

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

EntInf monedas(vector<int> const& M, int C) {
    int n = M.size();
    vector<EntInf> monedas(C + 1, Infinito);
    vector<EntInf> formas(C+1, 0);
    monedas[0] = 0;
    formas[0] = 1;
    // calcular la matriz sobre el propio vector
    for (int i = 1; i <= n; ++i) {
        for (int j = M[i - 1]; j <= C; ++j) {
            if(monedas[j] == monedas[j - M[i-1]] + 1) formas[j] = formas[j] + formas[j - M[i-1]];
            else if(monedas[j] > monedas[j - M[i-1]] + 1) {
                formas[j] = formas[j - M[i - 1]];
                monedas[j] = monedas[j - M[i-1]] + 1;
            }
        }
    }
    return formas[C];
}

bool resuelveCaso() {
  
  int C, N;
  cin >> C >> N;
  if (!cin)
    return false;

  // leer el resto del caso y resolverlo
  std::vector<int> monedasVec;
  for(int i = 0; i < N; ++i) {
      int tmp;
      cin >> tmp;
      monedasVec.push_back(tmp);
  }

  std::cout << monedas(monedasVec, C) << "\n";
  
  
  return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
  // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  // Resolvemos
  while (resuelveCaso());
  
  // para dejar todo como estaba al principio
#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
#endif
  return 0;
}
