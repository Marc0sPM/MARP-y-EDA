
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#include "Grafo.h"
#include <limits>

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class RecorridoProfundidad {
private:
    std::vector<bool> visit;
    std::vector<int> ant;
    std::vector<int> menor;

    void dfs(Grafo const& g, int v, std::vector<int> const& precios) {
        visit[v] = true;
        menor[v] = std::min(menor[v], precios[v]);
        for(int w : g.ady(v)) {
            if(!visit[w]) {
                menor[w] = std::min(menor[w], precios[w]);
                ant[w] = v;
                menor[v] = std::min(menor[v], menor[w]);
            }
        }
    }
public:
    RecorridoProfundidad(const Grafo& g, const std::vector<int>& precios) : visit(g.V(), false), ant(g.V()), menor(g.V(), std::numeric_limits<int>().max()) {
        for(int i = 0; i < g.V(); ++i) {
            dfs(g, i, precios);
        }
    }

    int menorDe(int k) const { return menor[k];}
};

bool resuelveCaso() {
   Grafo gr(cin, 1);

    if (!std::cin)  // fin de la entrada
        return false;
    int S;
    cin >> S;

    std::vector<int> precios(gr.V(), std::numeric_limits<int>().max());
    for(int i = 0; i < S; ++i) {
        int pt, pr;
        cin >> pt >> pr;
        precios[pt - 1] = pr;
    }
    int K;
    cin >> K;
    RecorridoProfundidad rp(gr, precios);
    for(int j = 0; j < K; ++j) {
        int tmp, tmp2;
        cin >> tmp;
        tmp2 = rp.menorDe(tmp);
        if(tmp2 != std::numeric_limits<int>().max()) cout << tmp2 << "\n";
        else cout << "MENUDO MARRON\n";
    }
    cout << "---\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
