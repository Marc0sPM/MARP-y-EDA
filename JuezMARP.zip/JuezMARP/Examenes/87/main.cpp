
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

struct actividad {
    int inicio, final;
    actividad(int ini, int fin) : inicio(ini), final(fin) {}
};

class cmp {
public:
    bool operator()(const actividad& a1, const actividad& a2) {
        return a1.inicio < a2.inicio;
    }
};

bool resuelveCaso() {
    int N;
    cin >> N;

    if (N == 0)
        return false;

    std::vector<actividad> activs;
    for(int i = 0; i < N; ++i) {
        int ini, fin;
        cin >> ini >> fin;
        activs.emplace_back(ini, fin);
    }
    std::sort(activs.begin(), activs.end(), cmp());

    int iterInicial = 0, iterSig = 1, finalMenor = activs[iterInicial].final, total = 0;
    while(iterSig < activs.size()) {
        if(activs[iterSig].inicio < finalMenor) {
            total++;
            finalMenor = std::min(finalMenor, activs[iterSig].final);
            iterSig++;
        }
        else {
            finalMenor = activs[iterInicial].final;
            iterInicial = iterSig + 1;
            iterSig += 2;
        }
    }

    std::cout << total << "\n";
    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
