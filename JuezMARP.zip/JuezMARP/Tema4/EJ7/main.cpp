
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

struct Trabajo {
    int inicio, fin;
};

bool comp(const Trabajo &a, const Trabajo &b) {
    return a.fin < b.fin;
}

bool resuelveCaso() {

    int C, F, N;
    cin >> C >> F >> N;

    if (C == 0 && F == 0 && N == 0)
        return false;

    vector<Trabajo> trabajos(N);
    for (int i = 0; i < N; ++i) {
        cin >> trabajos[i].inicio >> trabajos[i].fin;
    }
    sort(trabajos.begin(), trabajos.end(), comp);

    int momentoActual = C;
    int maximoMomento = 0;
    int trabajosSeleccionados = 0;
    int mejorTrabajo = 0;

    for (int j = 0; j < N; ++j) {
        if (trabajos[j].inicio <= momentoActual && trabajos[j].fin > maximoMomento) {
            mejorTrabajo = j;
            maximoMomento = trabajos[j].fin;
            momentoActual = maximoMomento;
            trabajosSeleccionados++;
        }
    }

    if (maximoMomento < F) {
        cout << "Imposible\n";
    } else {
        cout << trabajosSeleccionados << "\n";
    }

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
