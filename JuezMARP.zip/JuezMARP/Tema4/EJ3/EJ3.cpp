
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Para resolver el problema hacemos uso de un algoritmo voraz prácticamente idéntico al del ejercicio anterior,
 el de "¡Nos invaden!". Para ello, hacemos uso de dos vectores ordenados de mayor a menor (uno de ellos contiene las
 tallas necesitadas por los jugadores y otro las tallas que dispone el equipo). Este algoritmo va comparando, mediante
 dos iteradores, uno para el vector de disponibles y otro para el de necesitadas, talla a talla de las camisetas.
 Si la talla de una de las camisetas que tenemos disponibles vale para uno de los jugadores, incrementamos ambos iteradores;
 si no, miramos si bien la talla es mayor que lo que el jugador necesita, en cuyo caso, probaremos con otras camisetas; o bien
 es menor que la talla, en cuyo caso, y al estar el vector ordenado en valores decrecientes, no habrá ninguna talla de
 las que tengamos restante que le valga al jugador, por lo que tendremos que comprar una camiseta y probar si esa misma
 le sirve a otro. Al final de todo, para compensar que se nos hayan acabado las camisetas pero sigamos teniendo jugadores,
 sumamos la diferencia entre donde se ha quedado nuestro iterador de jugadores con respecto al final del vector al número
 de camisetas totales que hay que comprar.

 El algoritmo funciona porque, al estar el vector ordenado en valores decrecientes, comparamos la talla más grande
 que tenemos disponible con el jugador con la talla más grande que hay. Si esa camiseta no le vale al jugador por ser
 más grande que su talla, no le va a servir a ninguno de los otros jugadores, puesto que tienen tallas menores o iguales
 al jugador con la que la estamos comparando. Si la talla le sirve, "adjudicamos" esa camiseta a ese jugador y resolvemos
 el problema para los jugadores y las tallas restantes. En cambio, si la talla es más pequeña, como tenemos el vector
 ordenado, todas las tallas que tenemos después son menores o iguales a esa, por lo que ese jugador en concreto no va a
 poder usar ninguna de las tallas que tenemos disponibles, obligándonos a comprar una camiseta para él. Una vez resuelto
 el problema para ese jugador, lo resolvemos para el resto de jugadores usando la misma talla que teníamos seleccionada
 actualmente.

 El algoritmo de cálculo tiene coste O(min(N,M)), ya que solamente se recorrerá uno de los dos vectores (el que menor
 tamaño tenga) entero. Sin embargo, y puesto que ambos vectores tienen que estar ordenados en orden decreciente, prevalece
 el coste de la ordenación de los vectores, haciendo que el coste total del ejercicio sea del
 orden de O(max((N log N), (M log M))), donde N es el número de jugadores y M el número de tallas con las que contamos,
 suponiendo también un coste de O(max(N,M)) en espacio, debido a los vectores.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>
bool tallaMayor(int tallaCamiseta, int tallaJugador) {
    return (tallaCamiseta - tallaJugador > 1);
}

bool tallaMenor(int tallaCamiseta, int tallaJugador) {
    return (tallaCamiseta - tallaJugador < 0);
}

bool tallaValida(int tallaCamiseta, int tallaJugador) {
    return (!tallaMayor(tallaCamiseta, tallaJugador) && !(tallaMenor(tallaCamiseta, tallaJugador)));
}

int calculoCamisetas(std::vector<int> const& disponibles, std::vector<int> const& necesitadas) {
    int iterDispon = 0, iterNecesit = 0, camisetasNecesitadas = 0;
    while(iterDispon != disponibles.size() && iterNecesit != necesitadas.size()) {
        if(tallaValida(disponibles[iterDispon], necesitadas[iterNecesit])) {
            iterDispon++;
            iterNecesit++;
        }
        else {
            if(tallaMayor(disponibles[iterDispon], necesitadas[iterNecesit])) {
                iterDispon++;
            }
            else if(tallaMenor(disponibles[iterDispon], necesitadas[iterNecesit])) {
                camisetasNecesitadas++;
                iterNecesit++;
            }
        }
    }
    if(iterDispon == disponibles.size()) camisetasNecesitadas += necesitadas.size() - iterNecesit;
    return camisetasNecesitadas;
}

bool resuelveCaso() {
    int N, M;
    cin >> N >> M;
    if (!std::cin)  // fin de la entrada
        return false;

    std::vector<int> tallasNecesitadas;
    std::vector<int> tallasDisponibles;

    for(int i = 0; i < N; ++i) {
        int tmp;
        cin >> tmp;
        tallasNecesitadas.push_back(tmp);
    }
    for(int j = 0; j < M; ++j) {
        int tmp;
        cin >> tmp;
        tallasDisponibles.push_back(tmp);
    }
    std::sort(tallasNecesitadas.begin(), tallasNecesitadas.end(), std::greater<int>());
    std::sort(tallasDisponibles.begin(), tallasDisponibles.end(), std::greater<int>());

    std::cout << calculoCamisetas(tallasDisponibles, tallasNecesitadas) << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
