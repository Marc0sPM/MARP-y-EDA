
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

struct peliculas {
    int horaComienzo;
    int duracion;
    peliculas(int hora, int duracion) {
        this->horaComienzo = hora;
        this->duracion = duracion;
    }
    int finalPeli() const {return horaComienzo + duracion;}
};

class comparator {
public:
    bool operator()(peliculas const& p1, peliculas const& p2) {
        return p1.horaComienzo <= p2.horaComienzo;
    }
};

int cuantasPelis(std::vector<peliculas> const& pelis) {
    int iteradorComparar = 0, iteradorPelis = 1, numPelis = 1;
    while(iteradorPelis < pelis.size()) {
        if(pelis[iteradorPelis].horaComienzo < pelis[iteradorComparar].finalPeli() + 10) {
            iteradorPelis++;
        }
        else {
            iteradorComparar = iteradorPelis;
            iteradorPelis++;
            numPelis++;
        }
    }
    return numPelis;
}

bool resuelveCaso() {
    int N;
    cin >> N;
    if (N == 0)
        return false;

    std::vector<peliculas> vecPeliculas;
    for(int i = 0; i < N; ++i) {
        std::string hora;
        int duracion;
        std::cin >> hora >> duracion;
        int horas = std::stoi(hora.substr(0, 2));
        int minutos = std::stoi(hora.substr(3, 2));
        vecPeliculas.emplace_back(horas * 60 + minutos, duracion);
    }
    std::sort(vecPeliculas.begin(), vecPeliculas.end(), comparator());

    std::cout << cuantasPelis(vecPeliculas) << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
