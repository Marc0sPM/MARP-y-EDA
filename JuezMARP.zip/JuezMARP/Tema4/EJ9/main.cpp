
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Para resolver este problema haremos uso de un algoritmo voraz sobre un vector de enteros ordenado por valores
 de menor a mayor. Este ejercicio es idéntico al problema 39, en el que calculábamos el número total de coches
 que podíamos hacer funcionar dadas unas pilas y su voltaje. En este caso, el principio que usamos es el siguiente:
 si tenemos el vector ordenado de menor a valor, y la suma del menor peso del que disponemos en ese momento con el
 mayor peso que disponemos en ese momento es mayor al peso máximo permitido por el telesilla, significa que, con
 todos los pesos que nos quedan (que van a ser mayores que el menor que disponemos ahora mismo) el mayor peso siempre
 va a superar el valor permitido si lo sumamos con los restantes; por tanto, nos deshacemos del mayor peso permitido,
 y lo ponemos a él solo en un telesilla. Vamos comprobando el resto de pesos e intentamos emparejarlos. En todos los
 casos sumamos un telesilla. Al final, cuando hayamos recorrido todo el vector, si ambos iteradores se nos han quedado
 apuntando a un mismo elemento, ese elemento se ha quedado sin emparejar (normalmente, el de en medio), y por tanto,
 sumamos un telesilla más.

 El coste del algoritmo, como en los demás ejercicios, es del orden de O(U), siendo U el número de usuarios; sin embargo,
 el coste total del ejercicio es del orden de O(U log U), ya que prevalece el coste de la ordenación del vector de pesos
 al coste del algoritmo. Por otra parte, el coste en espacio es del orden de O(U).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

bool resuelveCaso() {
    int P, U;
    cin >> P >> U;

    if (!std::cin)  // fin de la entrada
        return false;

    std::vector<int> pesos;
    for(int i = 0; i < U; ++i) {
        int tmp;
        cin >> tmp;
        pesos.push_back(tmp);
    }
    std::sort(pesos.begin(), pesos.end(), std::less<int>());

    int ini = 0, fin = U - 1, sillasTotales = 0;
    while(ini < fin) {
        if(pesos[ini] + pesos[fin] > P) {
            --fin;
        }
        else {
            ++ini;
            --fin;
        }
        sillasTotales++;
    }
    if(ini == fin) sillasTotales++;

    std::cout << sillasTotales << "\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
