
/*@ <authors>
 *
 * Alejandro Massó Martínez - MARP21
 * Miguel Ramírez Castrillo - MARP34
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include "DigrafoValorado.h"
#include "IndexPQ.h"
#include <queue>
using namespace std;


/*@ <answer>

 Para resolver este problema lo subdividimos en dos partes: la primera de todas, haremos uso del algoritmo de
 Dijkstra para obtener las menores distancias desde un vértice de un digrafo valorado de longs con conexiones
 reversibles a todos los demás. Esto lo aplicaremos para ambas desalinizadoras.
 El coste del algoritmo de Dijkstra es del orden de O(M log N), con coste adicional en espacio lineal.

 Por otra parte, tenemos un algoritmo voraz, que hará uso de un struct pueblos, que contiene un long con el valor
 de la diferencia de las distancias desde cada desalinizadora a cada pueblo y su índice en los vectores de distancias.
 El algoritmo inserta en una cola de prioridad de pueblos, cada pueblo según su diferencia de distancias en orden
 decreciente y posteriormente recorre la cola de pueblos siempre eligiendo la distancia mínima para cada caso, si todavía
 hay camiones disponibles que puedan salir desde la desalinizadora más cercana. Si no los hay, se eligirá la otra distancia.

 Este algoritmo funciona porque en los casos donde la diferencia es mayor siempre se escoge la distancia menor, mientras
 que en los casos donde la diferencia sea menor, escogerá o bien la distancia menor si desde esa planta hay camiones libres,
 y si no, la otra distancia, sabiendo que la diferencia va a ser más pequeña. El coste en espacio es lineal en el número de
 vértices O(N), pero en complejidad se tiene en cuenta la ordenación en la cola de prioridad, por tanto (N log N)

 Por tanto, el coste total del algoritmo es O(M log N + N log N)

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;

    int origen;

    void relaja(AristaDirigida<T> a) {
        int v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int orig) : origen(orig), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()) {
        dist[orig] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T distancia(int v) const {return dist[v];}

};

struct pueblos {
    long distancia;
    int vertice;
};

class comparator {
public:
    bool operator() (const pueblos& p1, const pueblos& p2 ) {
        return p1.distancia < p2.distancia;
    }
};

bool resuelveCaso() {
    // leemos la entrada
    int N, M;
    cin >> N >> M;

    if (!cin)
        return false;

    // leer el resto del caso y resolverlo

    DigrafoValorado<long> dg(N);

    for(int i = 0; i < M; ++i) {
        int p1, p2, valor;
        cin >> p1 >> p2 >> valor;
        AristaDirigida<long> tmp(p1 - 1, p2 - 1, valor);
        AristaDirigida<long> tmp2(p2 - 1, p1 - 1, valor);
        dg.ponArista(tmp);
        dg.ponArista(tmp2);
    }

    Dijkstra<long> dj1(dg, 0);
    Dijkstra<long> dj2(dg, N-1);

    long costeFinal = 0;


    priority_queue<pueblos, std::vector<pueblos>, comparator> pq;
    for(int i = 1; i < N - 1; ++i) {
        long tmp = abs(dj1.distancia(i) - dj2.distancia(i));
        pq.push({tmp, i});
    }

    int norte = 0, sur = 0;
    while(!pq.empty()) {
        pueblos diff = pq.top();
        pq.pop();
        if(dj1.distancia(diff.vertice) <= dj2.distancia(diff.vertice)) {
            if(norte < ((N-2)/2)) {
                norte++;
                costeFinal += dj1.distancia(diff.vertice) * 2;
            }
            else {
                sur++;
                costeFinal += dj2.distancia(diff.vertice) * 2;
            }
        }
        else {
            if(sur < ((N-2)/2)) {
                sur++;
                costeFinal += dj2.distancia(diff.vertice) * 2;
            }
            else {
                norte++;
                costeFinal += dj1.distancia(diff.vertice) * 2;
            }
        }
    }

    std::cout << costeFinal << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Resolvemos
    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
