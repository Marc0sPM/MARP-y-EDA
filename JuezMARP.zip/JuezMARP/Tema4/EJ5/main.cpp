
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Para resolver este problema usamos un algoritmo voraz que calcula la máxima puntuación posible dado un determinado
 número de partidos N, sin que importe qué puntuación corresponde a qué partido. Para conseguir la mayor puntuación
 total, necesitaremos conseguir la mayor puntuación en cada uno de los partidos de manera individual, y eso lo conseguimos
 restándole a la mayor puntuación total local la menor puntuación rival. Para ello simplemente tenemos que ordenar
 el vector de resultados locales de mayor a menor y el de resultados rivales de menor a mayor, calcular la diferencia
 de puntos (local - rival), y sumarla si no es negativa.

 El algoritmo funciona porque vamos calculando por cada uno de los partidos la mayor puntuación total. Esto se puede
 demostrar con un ejemplo: imaginemos que para calcular la diferencia máxima, di, utilizamos un resultado local almacenado,
 en el vector de resultados locales, bi, y un resultado rival almacenado en el vector de resultados rivales, ri;
 entonces, di = bi - ri. Como sabemos que esa es la diferencia máxima, no habrá ningún otro resultado local que, con
 esa puntuación rival nos permita tener un resultado mayor que ese en ese partido, por tanto, al resolver el mismo caso
 para el resto de partidos, maximizamos la diferencia máxima y minimizamos el número de derrotas.

 La complejidad del algoritmo es del orden de O(N), ya que recorremos los dos vectores de manera simultánea; sin embargo,
 prevalece el ordenamiento de ambos vectores al recorrido de estos, por lo que la complejidad en tiempo es del orden
 de O(N log N), siendo N el número de partidos pronosticados. Por otra parte, la complejidad en espacio es también
 del orden de O(N) ya que usamos dos vectores, ambos de tamaño N.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

bool resuelveCaso() {
    int n;
    cin >> n;
    // leer los datos de la entrada
    if (n == 0)
        return false;

    std::vector<int> rivales;
    std::vector<int> locales;
    for(int i = 0; i < n; ++i) {
        int tmp;
        cin >> tmp;
        rivales.push_back(tmp);
    }
    for(int j = 0; j < n; ++j) {
        int tmp;
        cin >> tmp;
        locales.push_back(tmp);
    }
    std::sort(rivales.begin(), rivales.end(), std::less<int>());
    std::sort(locales.begin(), locales.end(), std::greater<int>());
    int total = 0;
    for(int k = 0; k < n; ++k) {
        total += (locales[k] - rivales[k] >= 0 ? locales[k] - rivales[k] : 0);
    }
    std::cout << total << "\n";
    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
