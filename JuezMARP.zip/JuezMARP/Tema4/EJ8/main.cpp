
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;


/*@ <answer>

 Para resolver este problema utilizaremos un algoritmo voraz con un vector de enteros ordenado por valores de menor
 a mayor. Para conseguir el mayor número posible de coches funcionando, necesitaremos siempre emparejar la pila de menor
 voltaje disponible en ese momento con la pila de mayor voltaje disponible en ese momento. Una vez las hemos emparejado,
 pasamos a la siguiente de menor voltaje y la siguiente de mayor voltaje disponibles (esto es, incrementando el iterador
 de pilas de menor voltaje y decrementando el de mayor voltaje). Es por eso que necesitamos tener el vector de pilas
 ordenado de menor voltaje a mayor voltaje. Si la suma del menor voltaje con el mayor no nos da un voltaje mayor o
 igual al pedido, entonces descartamos la pila de menor voltaje, y probamos si la siguiente menor sí que lo cumple.
 Se van probando las sucesivas pilas hasta que los iteradores lleguen ambos a la misma pila o hasta que el de menor
 voltaje sea mayor que el de mayor voltaje.

 El algoritmo funciona porque, al estar el vector ordenado de menor a mayor, si la pila de menor voltaje sumada a la
 de mayor voltaje no consigue ser mayor o igual al voltaje deseado, todas las pilas que estuviesen por detrás (si las
 hubiese, es decir, pilas de menor voltaje que la actual) se descartarían, ya que sumarían incluso menos que lo que se
 ha conseguido sumar. Es por ello que hay que ir iterando hasta conseguir el voltaje deseado. Si se han descartado
 todas las pilas hasta la última de todas (que es la que mayor voltaje tiene) significaría que con nuestras pilas
 disponibles no seríamos capaces de conseguir el voltaje deseado.

 La eficiencia del algoritmo es del orden de O(N), ya que se recorre una sola vez el vector de pilas; sin embargo,
 al tener un orden del vector, se impone el coste en tiempo de la ordenación, dejando el coste total del ejercicio
 en O(N * log N), donde N es el número de pilas. Por otra parte, el coste espacial es del orden de O(N), ya que
 contamos con un solo vector.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

void resuelveCaso() {
    int N, V;
    cin >> N >> V;
    std::vector<int> pilas;
    for(int i = 0; i < N; ++i) {
        int tmp;
        cin >> tmp;
        pilas.push_back(tmp);
    }
    std::sort(pilas.begin(), pilas.end(), std::less<int>());

    int ini = 0, fin = N - 1, totalPilas = 0;
    while(ini < fin) {
        if(pilas[ini] + pilas[fin] >= V) {
            ++totalPilas;
            ++ini;
            --fin;
        }
        else ++ini;
    }

    std::cout << totalPilas << "\n";
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
