
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

struct edificio {
    int inicio;
    int final;
    edificio(int ini, int final) : inicio(ini), final(final) {}
};

class comp {
public:
    bool operator()(const edificio& e1, const edificio& e2) {
        return e1.inicio < e2.inicio;
    }
};

int calcularTuneles(std::vector<edificio> const& edificios) {
    int edifActual = 0, edifSiguiente = 1, numTunel = 0;
    while(edifSiguiente < edificios.size()) {
        if(edificios[edifSiguiente].inicio < edificios[edifActual].final) {
            edifSiguiente++;
        }
        else {
            numTunel++;
            edifActual = edifSiguiente;
            edifSiguiente++;
        }
    }
    numTunel++;
    return numTunel;
}

bool resuelveCaso() {
    int N;
    cin >> N;
    if (N == 0)
        return false;
    std::vector<edificio> edificios;
    for(int i = 0; i < N; ++i) {
        int ini, final;
        cin >> ini >> final;
        edificios.emplace_back(ini, final);
    }

    std::sort(edificios.begin(), edificios.end(), comp());
    std::cout << calcularTuneles(edificios) << "\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
