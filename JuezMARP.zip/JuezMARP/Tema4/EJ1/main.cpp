
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <limits>
#include <cstdint>
using namespace std;

/*@ <answer>

 Para resolver este ejercicio haremos uso de un algoritmo voraz en la función parches. Para ello, necesitaremos guardarnos
 los parches en un vector de enteros (en este caso, el vector manguera), que los guarda ordenados por orden creciente,
 tal y como aparecen en la entrada del ejercicio. Nuestro algoritmo voraz usa dos índices, uno de ellos el actual (el
 primer elemento de los dos que se comparan) y el índice a comparar (un índice más avanzado en el vector que el actual).
 Si la distancia entre el elemento actual y el que se compara es menor o igual a la longitud del parche deseado, avan
 zamos el elemento que se quiere comparar; si no, sumamos un parche y avanzamos ambos índices hasta donde toque (el
 actual se avanza hasta el último que se ha comparado; y el comparado, uno más que el actual). Finalmente, para tener
 en cuenta el caso inicial, sumamos un parche más.

 La complejidad en tiempo de este algoritmo es del orden de O(N), siendo N el número de agujeros que tiene la manguera
 (al final, recorremos un vector que contiene los agujeros de principio a final, por tanto, el coste del algoritmo
 es el de recorrer el vector), mientras que la complejidad en espacio es del orden de O(N) (usamos un vector, el cual
 ocupa tantos elementos como agujeros haya).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

int parches(std::vector<int64_t> const& manguera, int L) {
    int indiceActual = 0, indiceCompar = 1;
    int numParches = 0;
    while(indiceCompar < manguera.size()) {
        if(manguera[indiceCompar] - manguera[indiceActual] <= L) indiceCompar++;
        else {
            indiceActual = indiceCompar;
            indiceCompar++;
            numParches++;
        }
    }
    numParches++;
    return numParches;
}

bool resuelveCaso() {
    int N, L;
    cin >> N >> L;
    // leer los datos de la entrada

    if (!std::cin)  // fin de la entrada
        return false;

    std::vector<int64_t> manguera;

    for(int i = 0; i < N; ++i) {
        int64_t tmp;
        cin >> tmp;
        manguera.push_back(tmp);
    }
    // escribir la solución
    cout << parches(manguera, L) << "\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
