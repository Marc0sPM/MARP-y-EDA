
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

/*@ <answer>

 Para resolver este ejercicio se ha usado un algoritmo voraz de la siguiente manera:
 primero de todo, se introducen en dos vectores distintos (enemigos y aliados) el número de enemigos y el número
 de aliados tal y como se leen en la entrada. Posteriormente, se ordenan de mayor a menor, ya que el algoritmo
 voraz utilizado necesita tener los vectores ordenados. La función compararVictorias cuenta con dos iteradores, uno
 para el vector de aliados y otro para el vector de enemigos. El número de tropas se compara de la siguiente manera:
 si el mayor número (de los que quedan) de tropas enemigas es mayor que el mayor número de tropas (de los que quedan)
 aliadas, esa batalla está perdida, por lo que miraremos si nuestro mayor número de tropas es capaz de vencer alguna
 batalla con menor número de enemigos. En caso contrario (el número de enemigos es menor o igual al de aliados),
 compararemos los siguientes mayores (el siguiente mayor de enemigos y el siguiente mayor de aliados) y nos añadiremos una victoria,
 así hasta que ya no queden de ninguno o de uno de ellos. El algoritmo trata de maximizar el número de victorias.

 La complejidad de este algoritmo es del orden de O(N log N), ya que prevalece la complejidad temporal de ordenar
 los vectores (N log N) sobre la de recorrer ambos vectores (O(N)). Por otra parte, el coste en espacio adicional
 es del orden de O(N), ya que hacemos uso de dos vectores, cada uno de ellos con N elementos distintos.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

int compararVictorias(std::vector<int> const& enemigos, std::vector<int> const& aliados) {
    int iterEnemigos = 0, iterAliados = 0, victorias = 0;
    while(iterEnemigos != enemigos.size() && iterAliados != aliados.size()) {
        if(enemigos[iterEnemigos] > aliados[iterAliados]) iterEnemigos++;
        else if(enemigos[iterEnemigos] <= aliados[iterAliados]) {
            victorias++;
            iterEnemigos++;
            iterAliados++;
        }
    }
    return victorias;
}

bool resuelveCaso() {
    int N;
    cin >> N;

    if (!std::cin)  // fin de la entrada
        return false;

    std::vector<int> enemigos, aliados;

    for(int i = 0; i < N; ++i) {
        int tmp;
        cin >> tmp;
        enemigos.push_back(tmp);
    }

    for(int j = 0; j < N; j++) {
        int tmp;
        cin >> tmp;
        aliados.push_back(tmp);
    }

    std::sort(enemigos.begin(), enemigos.end(), std::greater<int>());
    std::sort(aliados.begin(), aliados.end(), std::greater<int>());

    // escribir la solución
    std::cout << compararVictorias(enemigos, aliados) << "\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
