
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include "BinTree.h"
#include <algorithm>
#include <vector>

/*@ <answer>

 Para comprobar si el árbol binario es un árbol binario de búsqueda simplemente tenemos que ver
 que cada nodo izquierdo sea menor que la raíz y que al mismo tiempo cada nodo derecho sea mayor que la raíz.
 Para ello, hacemos uso de un vector de elementos, en el que los vamos guardando conforme recorremos el árbol,
 haciéndose un recorrido inorder. Para no tener que recorrer el vector al final para comprobar si los
 elementos están ordenados de menor a mayor, los miramos conforme los introducimos dentro.

 Por otra parte, para comprobar que el árbol está equilibrado comprobamos si el número de hijos izquierdos
 y derechos, al restarlos y ponerlos en valor absoluto, no es menor que 0 ni mayor que 1. En el momento en
 el que esta condición no se cumpla, devolveremos -1, indicando que el árbol no está equilibrado.

 El coste de la solución es O(n) ya que tenemos que recorrer el árbol de arriba a abajo una sola vez,
 comprobando ambas condiciones en cada nodo.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

template <class T>
struct AVLElems {
    std::vector<T> elemsOrdenados;
    int indiceActual;
    int indiceAnterior;
    int numElems;
    bool ABB;
    AVLElems<T>() : ABB(true), indiceActual(0), indiceAnterior(-1), numElems(0) {}
};

template <class T>
int comprobarAVL(const BinTree<T>& binTree, AVLElems<T>& elems) {
    if(elems.ABB) {
        int alturaAcum = 0;
        if(binTree.empty()) return 0;
        else {
            alturaAcum = 1;
            int aAIzq = comprobarAVL(binTree.left(), elems);
            elems.elemsOrdenados.push_back(binTree.root());
            ++elems.numElems;
            if(elems.numElems >= 2) {
                if(elems.elemsOrdenados[elems.indiceActual] <= elems.elemsOrdenados[elems.indiceAnterior]) elems.ABB = false;
                else {
                    ++elems.indiceAnterior; ++elems.indiceActual;
                }
            }
            else {
                ++elems.indiceAnterior; ++elems.indiceActual;
            }
            int aADcha = comprobarAVL(binTree.right(), elems);
            if(aAIzq != -1 && aADcha != -1 && (abs(aAIzq - aADcha) <= 1 && abs(aAIzq - aADcha) >= 0)) return alturaAcum + std::max(aAIzq, aADcha);
            else return -1;
        }
    }
}

//OTRA SOLUCIÓN

template <typename T>
struct sol {
    bool avl;
    int altura;
    T min, max;
};

template <typename T>
sol<T> es_avl_rec(BinTree<T> const& arbol) {
    if(arbol.empty()) return {true, 0, {}, T()};
    else {
        auto [avl_iz, alt_iz, min_iz, max_iz] = es_avl_rec(arbol.left());
        auto [avl_dcha, alt_dcha, min_dcha, max_dcha] = es_avl_rec(arbol.right());

        int alt = 1 + std::max(alt_iz, alt_dcha);
        T max = arbol.right().empty() ? arbol.root() : max_dcha;
        T min = arbol.left().empty() ? arbol.root() : min_iz;

        bool avl = avl_iz && avl_dcha && abs(alt_iz - alt_dcha) <= 1 && (arbol.left().empty() || arbol.root() > max_iz) && (arbol.right().empty() || arbol.root() < min_dcha);

        return (avl, alt, min, max);
    }
}

template <typename T>
bool es_avl(BinTree<T> const& arbol) {
    return es_avl_rec(arbol).avl;
}

bool resuelveCaso() {

    char c;
    std::cin >> c;
    if(c != 'N' && c != 'P' || !std::cin) return false;

    //Lectura del árbol
    if(c == 'N') {
        BinTree<int> binTree = read_tree<int>(std::cin);

        // Salida
        AVLElems<int> elems;
        (comprobarAVL(binTree, elems) != -1 && elems.ABB) ? std::cout << "SI" << std::endl : std::cout << "NO" << std::endl;
    }
    else if(c == 'P') {
        BinTree<std::string> binTree = read_tree<std::string>(std::cin);

        // Salida
        AVLElems<std::string> elems;
        (comprobarAVL(binTree, elems) != -1 && elems.ABB) ? std::cout << "SI" << std::endl : std::cout << "NO" << std::endl;
    }

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
