/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * Indicad el nombre completo y usuario del juez de quienes habéis hecho esta solución:
 * Estudiante 1: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
using namespace std;

#include "TreeSet_AVL_tami.h"

/*@ <answer>
 
 Para encontrar el k-ésimo elemento, en lugar de trabajar con el conjunto, trabajaremos con los
 nodos del árbol. Para buscar el k-ésimo basta con hacer una búsqueda binaria recusriva utilizando
 tam_i, y en los casos requeridos (principalmente cuando hay que ir hacia un hijo derecho) un acumulador.

 Si el k que estamos buscando es menor que el tam_i de la raíz principal del árbol, buscamos el k-ésimo
 con el hijo izquierdo. Si es mayor, lo buscamos en el hijo derecho. Al solamente guardar el número de
 hijos izquierdos, necesitamos ir guardando qué posición tienen los nodos derechos utilizando un acumulador,
 que suma el tam_i del hijo principal con el tam_i del nodo derecho. Si el acumulador ya no es 0 (esto es,
 que en alguna parte del árbol hemos ido hacia la derecha) y ahora vamos hacia la izquierda, basta con solamente
 usar el acumulador (sin sumarle el tam_i del anterior).

 Por último, se modifican las operaciones de inserción y ambas rotaciones para cambiar los tam_i de los elementos
 que lo requieran.
 
 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

//Como el código de la respuesta está en el archivo TreeSet_AVL_tami.h, lo incluiré aquí comentado

/*
 *  En el struct TreeNode:
 *   T const& kesimo(int k, int acum = 0) const {
            if(this == nullptr) throw std::range_error("No se encuentra el kesimo elemento");

            if(k < (tam_i + acum) && iz != nullptr) {
               if(acum == 0) return iz->kesimo(k);
               else return iz->kesimo(k, acum);
            }
            else if(k > (tam_i + acum) && dr != nullptr) {
                return dr->kesimo(k, tam_i + acum);
            }
            else return elem;
      }
 *  En la clase Set:
 * T const& kesimo(int k) const {
       if(k > nelems) throw std::range_error("No se encuentra el kesimo elemento");
       return raiz->kesimo(k);
   }
 *
 * bool inserta(T const& e, Link & a) {
      bool crece;
      if (a == nullptr) { // se inserta el nuevo elemento e
         a = new TreeNode(e);
         ++nelems;
         crece = true;
      } else if (menor(e, a->elem)) {
         crece = inserta(e, a->iz);
         if (crece) {
             ++(a->tam_i);
             reequilibraDer(a);
         }
      } else if (menor(a->elem, e)) {
         crece = inserta(e, a->dr);
         if (crece) reequilibraIzq(a);
      } else // el elemento e ya está en el árbol
         crece = false;
      return crece;
   }
 *
 *  void rotaDer(Link & r2) {
      Link r1 = r2->iz;
      r2->iz = r1->dr;
      r1->dr = r2;

      r2->tam_i -= r1->tam_i;

      r2->altura = std::max(altura(r2->iz), altura(r2->dr)) + 1;
      r1->altura = std::max(altura(r1->iz), altura(r1->dr)) + 1;
      r2 = r1;
   }
 *
 * void rotaIzq(Link & r1) {
      Link r2 = r1->dr;
      r1->dr = r2->iz;
      r2->iz = r1;

    r2->tam_i += r1->tam_i;

      r1->altura = std::max(altura(r1->iz), altura(r1->dr)) + 1;
      r2->altura = std::max(altura(r2->iz), altura(r2->dr)) + 1;
      r1 = r2;
   }
 * */

bool resuelveCaso() {
  int N;
  cin >> N;
  if (N == 0)
     return false;
  
 // los valores de la entrada se insertan en el conjunto
  Set<int> cjto;
  int valor;
  for (int i = 0; i < N; ++i) {
     cin >> valor;
     cjto.insert(valor);
  }
  
  // COMPLETAR

  cin >> N;
  for(int j = 0; j < N; ++j) {
      cin >> valor;
      try {
          std::cout << cjto.kesimo(valor) << std::endl;
      }
      catch (const exception& e) {
          std::cout << "??" << std::endl;
      }
  }
  
  cout << "---\n";
  
  return true;
}


//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
  // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  while (resuelveCaso());

#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
#endif
  return 0;
}
