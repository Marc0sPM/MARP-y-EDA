#include <iostream>
#include <string>
#include "TreeSet.h"

int main() {

   Set<int> ents;
   ents.insert(10);
   ents.insert(20);
   ents.insert(14);
   ents.insert(7);
   ents.insert(8);
   std::cout << ents.minimum() << '\n';  // muestra 7
   ents.erase(8);
   ents.erase(ents.minimum());
   std::cout << ents.minimum() << '\n';  // muestra 10

   Set<std::string> cads;
   cads.insert("uno");
   cads.insert("dos");
   cads.insert("tres");
   cads.insert("cuatro");
   cads.insert("seis");
   std::cout << cads.minimum() << '\n';  // muestra cuatro
   cads.erase(cads.minimum());
   std::cout << cads.minimum() << '\n';  // muestra dos

}