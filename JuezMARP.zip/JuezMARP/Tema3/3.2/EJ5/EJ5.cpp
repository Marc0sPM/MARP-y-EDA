/*
 * MUY IMPORTANTE: Solo se corregirán los comentarios y el código
 * contenidos entre las etiquetas <answer> y </answer>.
 * Toda modificación fuera de esas etiquetas no será corregida.
 */

/*@ <answer>
 *
 * MARP21 Alejandro Massó Martínez
 * MARP34 Miguel Ramírez Castrillo
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include "Digrafo.h"
#include <vector>
#include <string>
using namespace std;


/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

class Programa {
private:
    vector<bool> visitados;
    int numeroInstrucciones;
    Digrafo* prgm;
    std::vector<bool> apilado;
    bool hayciclo;

    void dfs(const Digrafo& d, int v) {
        apilado[v] = true;
        visitados[v] = true;
        for (int w : d.ady(v)) {
            if (!visitados[w]) { // encontrado un nuevo vértice, seguimos
                 dfs(d, w);
            } else if (apilado[w]) { // hemos detectado un ciclo
                // se recupera retrocediendo
                hayciclo = true;
            }
        }
        apilado[v] = false;
    }

public:
    Programa(std::istream& flujo) {
            flujo >> numeroInstrucciones;
            if(!flujo) return;
            visitados = vector<bool>(numeroInstrucciones + 1, false);
            apilado = vector<bool>(numeroInstrucciones + 1, false);
            prgm = new Digrafo(numeroInstrucciones + 1);

            for(int i = 0; i < numeroInstrucciones; ++i) {
                char instruccion;
                flujo >> instruccion;
                switch(instruccion) {
                    case 'A': {
                        prgm->ponArista(i, i+1);
                    } break;
                    case 'J': {
                        int instrEnlazada;
                        cin >> instrEnlazada;
                        prgm->ponArista(i, instrEnlazada - 1);
                    } break;
                    case 'C': {
                        int instrEnlazada;
                        cin >> instrEnlazada;
                        prgm->ponArista(i, i+1);
                        prgm->ponArista(i, instrEnlazada - 1);
                    } break;
                }
            }

            dfs(*prgm, 0);

            if(hayciclo) {
                if(visitados[numeroInstrucciones]) std::cout << "A VECES\n";
                else std::cout << "NUNCA\n";
            }
            else std::cout << "SIEMPRE\n";
        }
};


bool resuelveCaso() {

    Programa* p = new Programa(std::cin);
    if (!cin)
        return false;

    // leer el resto del caso y resolverlo
    delete p;
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    // Resolvemos
    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
#endif
    return 0;
}
