
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <queue>
#include <unordered_map>
#include "Digrafo.h"
using namespace std;


/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class EscalerasYSerpientes {
private:
    std::vector<bool> visit;
    std::vector<int> ant;
    std::vector<int> dist;
    std::unordered_map<int, int>* escaleras;
    int _distancia;

    int bfs(Digrafo const& dg, int inicio, int final, int K) {
        std::queue<int> q;
        dist[inicio] = 0; visit[inicio] = true;
        q.push(inicio);
        while(!q.empty()) {
            int v = q.front();
            q.pop();
            for(int d = 1; d <= K; ++d) {
                int w = v + d;
                if((*escaleras).count(w)) w = (*escaleras)[w];
                if(w == final) return dist[v] + 1;
                if(w < final && !visit[w]) {
                    dist[w] = dist[v] + 1;
                    visit[w] = true;
                    q.push(w);
                }
            }
        }
    }

public:
    EscalerasYSerpientes(Digrafo const& dg, int inicio, int final, int K, std::unordered_map<int, int>& escaleras) : visit(dg.V(), false), ant(dg.V()), dist(dg.V()), escaleras(&escaleras) {
        _distancia = bfs(dg, inicio, final, K);
    }

    int distancia() const {return _distancia;}
};

bool resuelveCaso() {

    // leer los datos de la entrada
    int N, K, S, E;
    cin >> N >> K >> S >> E;

    if (N == 0 && K == 0 && S == 0 && E == 0)
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    Digrafo dg(N * N);
    std::unordered_map<int, int> escaleras;
    for(int i = 0; i < S + E; ++i) {
        int v, w;
        cin >> v >> w;
        dg.ponArista(v-1,w-1);
        if(v < w) escaleras.insert({v-1, w-1});
    }

    EscalerasYSerpientes eys(dg, 0, N*N-1, K, escaleras);

    std::cout << eys.distancia() << "\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
