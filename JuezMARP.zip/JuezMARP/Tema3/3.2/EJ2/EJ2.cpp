
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

#include "Digrafo.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>

    Para resolver este problema haremos uso de una clase OrdenTopologicoYCiclos, que como su nombre indica,
    nos permitirá saber si un grafo dirigido es un DAG (grafo dirigido acíclico), y, si no lo es, nos permitirá
    tener una ordenación topológica de este.

    Para saber si el grafo tiene ciclos o no, basta con comprobar si uno de los elementos adyacentes al elemento
    actual está apilado en el vector de apilados, lo cual significaría que pese a ser uno de los adyacentes al elemento
    actual, está incluido en el camino que llega desde el inicial hasta el actual, por lo que habría un ciclo ahí.

    Para hacer la ordenación topológica, basta con hacer un recorrido en profundidad en el que vayamos metiendo elementos
    en un deque "_orden" si estos no tienen ningún elemento adyacente o si no les queda ningún adyacente más.

    Realizamos la llamada a la función dfs por cada uno de los vértices que no estén visitados que tenga el digrafo, y
    al final devolvemos si hay ciclo, y si no lo hay, la ordenación topológica conseguida.

    La complejidad en tiempo de este ejercicio es del orden de O(N+M), siendo N el número de tareas a realizar y
    M el número de relaciones de dependencia directa que existen.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class OrdenTopologicoYCiclos {
private:
    std::deque<int> _orden;
    std::vector<bool> visit;
    std::vector<bool> apilado;
    bool hayciclo;

    void dfs(Digrafo const& dg, int v) {
        apilado[v] = true;
        visit[v] = true;
        for (int w : dg.ady(v)) {
            if (!visit[w]) {
                dfs(dg, w);
            } else if (apilado[w]) {
                hayciclo = true;
                break;
            }
        }
        _orden.push_front(v + 1);
        apilado[v] = false;
    }

public:
    OrdenTopologicoYCiclos(const Digrafo& dg) : visit(dg.V(), false), apilado(dg.V(), false), hayciclo(false) {
        for(int i = dg.V() - 1 ; i >= 0 && !hayCiclo(); --i) {
            if(!visit[i]) dfs(dg, i);
        }
    }
    bool hayCiclo() const {return hayciclo;}
    std::deque<int> const& orden() const {return _orden;}
};

bool resuelveCaso() {

    // leer los datos de la entrada
    Digrafo dg(cin, 1);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    OrdenTopologicoYCiclos cd(dg);

    // escribir la solución

   if(cd.hayCiclo()) std::cout << "Imposible\n";
   else {
       for(auto e : cd.orden()) std::cout << e << " ";
       std::cout << "\n";
   }

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
