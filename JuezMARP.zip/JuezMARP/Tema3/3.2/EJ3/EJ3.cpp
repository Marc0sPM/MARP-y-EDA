
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "Digrafo.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>

 Para resolver este problema haremos uso de una clase adicional Sumidero, que calculará el número de sumideros
 en un grafo dirigido calculando su inverso. Una vez calculado el inverso, se recorren todos los vértices, y si
 el número de vértices adyacentes en el grafo normal es nulo y el número de vértices adyacentes en el grafo inverso
 es igual al número de vértices menos uno, se añadirá a un vector que contendrá el número de sumideros.

 Es por eso, que el coste de este ejercicio es del orden de O(2V+A) ~ O(V+A), que es el coste de calcular el inverso
 del grafo (O(V+A)) y el coste de recorrer todos los vértices del grafo (O(V)).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class Sumidero {
private:
    Digrafo _inv;
    std::vector<int> _sumideros;
    bool haysumidero;
public:
    Sumidero(const Digrafo& dg) : _inv(dg.inverso()), haysumidero(false) {
        for(int i = 0; i < dg.V(); ++i) {
            if(dg.ady(i).size() == 0 && _inv.ady(i).size() == (dg.V() - 1)) {
                haysumidero = true;
                _sumideros.push_back(i);
            }
        }
    }

    void sumideros() const {
        if(haysumidero) {
            std::cout << "SI ";
            for(int i = 0; i < _sumideros.size(); ++i) {
                std::cout << _sumideros[i] << " ";
            }
            std::cout << "\n";
        }
        else std::cout << "NO\n";
    }
};

bool resuelveCaso() {

    // leer los datos de la entrada

    Digrafo dg(cin);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones

    Sumidero s(dg);
    // escribir la solución

    s.sumideros();

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
