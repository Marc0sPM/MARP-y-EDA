
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
#include <limits>
#include <stack>
using namespace std;

#include "DigrafoValorado.h"  // propios o los de las estructuras de datos de clase
#include "IndexPQ.h"

/*@ <answer>

 Este ejercicio es idéntico al 27 con la diferencia de que para la salida, utilizo el método tramoAnterior, que devuelve,
 para un vértice, cuál es el vértice en el camino mínimo que llega hasta él. En la salida, utilizo una pila para ir
 almacenando los valores desde el destino (el que queda más abajo en la pila) hasta el origen (el que queda más arriba),
 rellenándola haciendo sucesivas llamadas al método tramoAnterior hasta que el valor que ocupe el top de la pila sea
 el valor del origen. Luego, se van sacando hasta que no quede ninguno en la pila y se van sacando por pantalla conforme
 marca el enunciado.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

template <class T>
using Camino = deque<AristaDirigida<T>>;

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;

    int origen;

    void relaja(AristaDirigida<T> a) {
        int v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int orig) : origen(orig), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()) {
        dist[orig] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    T tramoAnterior(int v) const {return ult[v].desde();}
    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T distancia(int v) const {return dist[v];}

};

bool resuelveCaso() {
    // leer los datos de la entrada
    int puntos, calles;
    cin >> puntos >> calles;
    DigrafoValorado<int> dg(puntos);
    for(int j = 0; j < calles; ++j) {
        int v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int> tmp(v - 1, w - 1, valor);
        AristaDirigida<int> tmp2(w - 1, v - 1, valor);
        dg.ponArista(tmp);
        dg.ponArista(tmp2);
    }
    int pedidos;
    cin >> pedidos;

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones

    for(int i = 0; i < pedidos; ++i) {
        int origen, destino;
        cin >> origen >> destino;
        Dijkstra<int>* d = new Dijkstra<int>(dg, origen - 1);
        if(d->hayCamino(destino - 1)) {
            cout << d->distancia(destino - 1) << ": ";
            std::stack<int> orden;
            orden.push(destino);
            while(orden.top() != origen) orden.push(d->tramoAnterior(orden.top() - 1) + 1);
            while(!orden.empty()) {
                int tramo = orden.top(); orden.pop();
                if(!orden.empty()) cout << tramo << " -> ";
                else cout << tramo << "\n";
            }
        }
        else cout << "NO LLEGA\n";
        delete d;
    }
    cout << "---\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
