
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
#include <limits>
using namespace std;

#include "DigrafoValorado.h"  // propios o los de las estructuras de datos de clase
#include "IndexPQ.h"

/*@ <answer>

 Para resolver este ejercicio haremos uso de digrafos valorados y el algoritmo de Dijkstra. En la entrada, leeremos
 los vértices e insertamos tanto la arista v->w como la arista w->v. Una vez insertados, nos crearemos un tipo de la
 clase Dijkstra por cada uno de los pedidos, insertando el origen y viendo su valor en el método distancia para
 el vértice destino que se nos pida. Por otra parte, el algoritmo no está modificado en ninguna manera, por lo que es
 un algoritmo de Dijkstra simple, ergo su coste total es de O(K * (C * log N)), siendo C el número de calles (aristas),
 N el número de puntos de recogida (vértices) y K el número de pedidos.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

template <class T>
using Camino = deque<AristaDirigida<T>>;

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;

    int origen;

    void relaja(AristaDirigida<T> a) {
        int v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int orig) : origen(orig), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()) {
        dist[orig] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T distancia(int v) const {return dist[v];}

};

bool resuelveCaso() {
    // leer los datos de la entrada
    int puntos, calles;
    cin >> puntos >> calles;
    DigrafoValorado<int> dg(puntos);
    for(int j = 0; j < calles; ++j) {
        int v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int> tmp(v - 1, w - 1, valor);
        AristaDirigida<int> tmp2(w - 1, v - 1, valor);
        dg.ponArista(tmp);
        dg.ponArista(tmp2);
    }
    int pedidos;
    cin >> pedidos;

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones

    for(int i = 0; i < pedidos; ++i) {
        int origen, destino;
        cin >> origen >> destino;
        Dijkstra<int>* d = new Dijkstra<int>(dg, origen - 1);
        if(d->hayCamino(destino - 1)) {
            cout << d->distancia(destino - 1) << "\n";
        }
        else cout << "NO LLEGA\n";
        delete d;
    }
    cout << "---\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
