
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <limits>
#include <deque>
using namespace std;
#include "DigrafoValorado.h"
#include "IndexPQ.h"

/*@ <answer>

 Para resolver este problema basta con modificar el algoritmo de Dijkstra para que vaya guardando el número de caminos
 mínimos que llegan hasta un determinado vértice. Para ello, lo implementamos con un vector, numCaminos, de tamaño
 N, donde N es el número de vértices de nuestro digrafo valorado. En el método relaja del algoritmo, si la distancia
 al vértice w es mayor que la distancia al vértice v más la distancia desde el vértice v al w, sustituimos el número
 de caminos mínimos (inicialmente a 0) del vértice w por el número de caminos del vértice v, ya que se cumple que
 si hay un número X de caminos mínimos que llegan hasta el vértice v, y v está conectado mediante una arista dirigida
 con w, formando un camino mínimo, entonces el número de caminos que llegarán hasta w será también de X.
 Por otra parte, si hubiese algún otro camino mínimo que llegase hasta w (es decir, si la distancia al vértice w es
 exactamente igual que la distancia a un vértice v más la distancia desde ese vértice v al w), simplemente se suman
 todos los caminos que lleguen al vértice v al vértice w. En caso de que se encuentre un nuevo camino mínimo, el proceso
 anterior sustituirá los caminos mínimos del vértice w por los correctos.

 La complejidad del algoritmo en tiempo es del orden de O(C log N), donde C es el número de calles y N el número de
 intersecciones del pueblo. El coste en espacio es del orden de O(N), ya que hay que inicializar los vectores y las
 colas de prioridad que usa el algoritmo.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

template <class T>
using Camino = deque<AristaDirigida<T>>;

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;
    int64_t origen, destino;
    vector<int64_t> numCaminos;

    void relaja(AristaDirigida<T> a) {
        int64_t v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
            numCaminos[w] = numCaminos[v];
        }
        else if(dist[w] == dist[v] + a.valor()) numCaminos[w] += numCaminos[v];
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int64_t origen, int64_t destino) : origen(origen), destino(destino), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()), numCaminos(dg.V(), 0) {
        dist[origen] = 0;
        numCaminos[origen] = 1;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    int64_t caminosTotales(int v) const {return numCaminos[v];}
    T verticeAnterior(int v) const {return ult[v].desde();}
    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T tiempo(int v) const {return dist[v];}

};

bool resuelveCaso() {
    int N, C;
    cin >> N >> C;
    if (!std::cin)  // fin de la entrada
        return false;

    DigrafoValorado<int64_t> dg(N);
    for(int i = 0; i < C; ++i) {
        int64_t v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int64_t> tmp1(v - 1, w - 1, valor);
        AristaDirigida<int64_t> tmp2(w - 1, v - 1, valor);
        dg.ponArista(tmp1);
        dg.ponArista(tmp2);
    }
    Dijkstra<int64_t> dj(dg, 0, N-1);
    cout << dj.caminosTotales(N-1) << "\n";
    // resolver el caso posiblemente llamando a otras funciones

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
