
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <limits>
#include <deque>
using namespace std;
#include "DigrafoValorado.h"
#include "IndexPQ.h"


/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;
    int64_t origen, destino;
    vector<int64_t> pasos;
    vector<int64_t> minimosPasosRegistrados;
    bool numMinimoCaminos = true;

    void relaja(AristaDirigida<T> a) {
        int64_t v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pasos[w] = pasos[v] + 1;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int64_t origen, int64_t destino) : origen(origen), destino(destino), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()), pasos(dg.V(), Infinito), minimosPasosRegistrados(dg.V(), Infinito) {
        dist[origen] = 0;
        pasos[origen] = 0;
        minimosPasosRegistrados[origen] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    int64_t numPasos(int v) const {return pasos[v];}
    bool esCaminoMinimo() const {return numMinimoCaminos;}
    T verticeAnterior(int v) const {return ult[v].desde();}
    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T distancia(int v) const {return dist[v];}

};

bool resuelveCaso() {
    int N, C;
    cin >> N >> C;
    if (!std::cin)  // fin de la entrada
        return false;

    DigrafoValorado<int64_t> dg(N);
    DigrafoValorado<int64_t> dgSV(N);
    for(int i = 0; i < C; ++i) {
        int64_t v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int64_t> tmp1(v - 1, w - 1, valor);
        AristaDirigida<int64_t> tmp2(w - 1, v - 1, valor);
        AristaDirigida<int64_t> tmp3(v - 1, w - 1, 1);
        AristaDirigida<int64_t> tmp4(w - 1, v - 1, 1);
        dg.ponArista(tmp1);
        dg.ponArista(tmp2);
        dgSV.ponArista(tmp3);
        dgSV.ponArista(tmp4);
    }

    int K;
    cin >> K;
    for(int j = 0; j < K; ++j) {
        int origen, destino;
        cin >> origen >> destino;
        Dijkstra<int64_t> dj(dg, origen - 1, destino - 1);
        if(dj.hayCamino(destino - 1)) {
            Dijkstra<int64_t> djSV(dgSV, origen - 1, destino - 1);
            cout << dj.distancia(destino -1) << (dj.numPasos(destino - 1) == djSV.numPasos(destino - 1)? " SI\n" : " NO\n");
        }
        else cout << "SIN CAMINO\n";
    }
    cout << "---\n";

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
