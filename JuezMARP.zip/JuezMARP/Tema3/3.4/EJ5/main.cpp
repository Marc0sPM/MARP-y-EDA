
/*@ <authors>
 *
 * Alejandro Massó Martínez (MARP21)
 * Miguel Ramírez Castrillo (MARP34)
 *
 *@ </authors> */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include "DigrafoValorado.h"
#include "IndexPQ.h"
using namespace std;


/*@ <answer>

 NO CORREGIR -> La solución de este EJ5 está en el ejercicio entregado por mi compañero MARP34.

 Este ejercicio tiene como solución un coste de O(C log P + BP), mientras que la solución que hemos entregado
 desde el juez de mi compañero es de coste O(C log P).

 @ </answer> */

// ================================================================
// Escribe el código completo de tu solución aquí debajo (después de la marca)
//@ <answer>

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;

    int origen;

    void relaja(AristaDirigida<T> a) {
        int v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int orig) : origen(orig), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()) {
        dist[orig] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    bool hayCamino(int v) const {return dist[v] != Infinito; }
    int caminos(int origen, int distancia) const {
        int tmp = 0;
        for(int i = 0; i < dist.size(); ++i) {
            if(abs(dist[i] - dist[origen - 1]) <= distancia) tmp++;
        }
        return tmp;
    }

};

bool resuelveCaso() {
  
  // leemos la entrada
  int D, P, C;
  cin >> D >> P >> C;
  
  if (!cin)
    return false;

  // leer el resto del caso y resolverlo
  
  DigrafoValorado<int> dg(P);
    for(int j = 0; j < C; ++j) {
        int v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int> tmp(v - 1, w - 1, valor);
        AristaDirigida<int> tmp2(w - 1, v - 1, valor);
        dg.ponArista(tmp);
        dg.ponArista(tmp2);
    }

    int casos;
    cin >> casos;

    int pueblosTotales = 0;
    Dijkstra<int>* d = new Dijkstra<int>(dg, P-1);
    for(int j = 0; j < casos; ++j) {
        int origen;
        cin >> origen;
        pueblosTotales += d->caminos(origen,D);
    }
    cout << pueblosTotales << "\n";
    delete d;

  return true;
}

//@ </answer>
//  Lo que se escriba debajo de esta línea ya no forma parte de la solución.

int main() {
  // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
  std::ifstream in("casos.txt");
  auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif
  
  // Resolvemos
  while (resuelveCaso());
  
  // para dejar todo como estaba al principio
#ifndef DOMJUDGE
  std::cin.rdbuf(cinbuf);
#endif
  return 0;
}
