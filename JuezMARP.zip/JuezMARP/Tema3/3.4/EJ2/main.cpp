
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <limits>
#include <deque>
#include "IndexPQ.h"
#include "DigrafoValorado.h"
using namespace std;


/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>
template <class T>
using Camino = deque<AristaDirigida<T>>;

template <class T>
class Dijkstra {
private:
    const T Infinito = std::numeric_limits<T>::max();
    vector<T> dist;
    vector<AristaDirigida<T>> ult;
    IndexPQ<T> pq;
    int origen;

    void relaja(AristaDirigida<T> a) {
        int v = a.desde(), w = a.hasta();
        if(dist[w] > dist[v] + a.valor()) {
            dist[w] = dist[v] + a.valor();
            ult[w] = a;
            pq.update(w, dist[w]);
        }
    }

public:
    Dijkstra(const DigrafoValorado<T>& dg, int orig) : origen(orig), dist(dg.V(), Infinito), ult(dg.V()), pq(dg.V()) {
        dist[orig] = 0;
        pq.push(origen, 0);
        while(!pq.empty()) {
            int v = pq.top().elem; pq.pop();
            for(auto ady : dg.ady(v)) {
                relaja(ady);
            }
        }
    }

    T verticeAnterior(int v) const {return ult[v].desde();}
    bool hayCamino(int v) const {return dist[v] != Infinito; }
    T tiempo(int v) const {return dist[v];}

};

bool resuelveCaso() {

    // leer los datos de la entrada
    int N;
    cin >> N;
    if (N == 0)
        return false;

    std::vector<int64_t> tiempoCarga;
    for(int i = 0; i < N; ++i) {
        int64_t tiempo;
        cin >> tiempo;
        tiempoCarga.push_back(tiempo);
    }

    int M;
    cin >> M;

    DigrafoValorado<int64_t> web(N);
    for(int j = 0; j < M; ++j) {
        int64_t v, w, valor;
        cin >> v >> w >> valor;
        AristaDirigida<int64_t> tmp(v - 1, w - 1, valor);
        web.ponArista(tmp);
    }

    Dijkstra<int64_t> dj(web, 0);
    if(dj.hayCamino(N-1)) {
        int64_t valorCamino = dj.tiempo(N-1);
        int64_t elemActual = N-1;
        int64_t valorTotal = valorCamino + tiempoCarga[N-1];
        while(elemActual != 0) {
            elemActual = dj.verticeAnterior(elemActual);
            valorTotal += tiempoCarga[elemActual];
        }
        cout << valorTotal << "\n";
    }
    else cout << "IMPOSIBLE\n";

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
