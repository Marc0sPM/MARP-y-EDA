
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
#include <limits>
using namespace std;
#include "ConjuntosDisjuntos.h"
using Cuadricula = vector<vector<bool>>;

/*@ <answer>

 Para resolver este problema reusaremos parte del código del ejercicio 13, en el que se calculaba el tamaño
 máximo de una mancha con un grafo implícito en una matriz de píxeles/cuadrículas.

 La única diferencia está en que cuando descubrimos una casilla adyacente en cualquiera de las 8 direcciones,
 se unen también en un conjunto disjunto incluido en la clase CuadriculaConCjtosDisjuntos. Como los conjuntos
 disjuntos solo admiten enteros, para calcular el número que ocupa una casilla basta con hacer
 NumCasilla = NumFila * columnasTotales + NumColumna. Ese número lo unimos con su adyacente.

 La otra parte del ejercicio es el método anadirMancha, que dadas unas posiciones x e y hace lo mismo, comprueba
 si esa posición es válida y no ha sido visitada aún, comprueba que las adyacentes son válidas, y si hay alguna
 adyacente que pertenezca a esa mancha, la une consigo misma. Al final, se comprueba si el tamaño que ya había
 calculado anteriormente es menor que el tamaño de esa nueva mancha, y si lo es, se sustituye en la variable
 maximaComponenteConexa.

 Como la cuadrícula se recorre entera (F*C), la complejidad es del orden de O(F*C + F*C), ya que se hacen F*C llamadas
 a la función unir del conjunto disjunto, cuya complejidad es del orden de N + Mlg*N. Como M, el número de llamadas
 es F*C, y N, el número de conjuntos disjuntos de la cuadrícula comienza siendo F*C, la complejidad sería O(F*C + (F*C)lg*(F*C)),
 pero podemos considerar lg*(F*C) como constante, por tanto, O(F*C + F*C);

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class CuadriculaConCjtosDisjuntos {
private:
    int maximaComponenteConexa = 0, filas, columnas;
    Cuadricula visitados;
    Cuadricula cuadricula;
    ConjuntosDisjuntos cd;
    const vector<pair<int, int>> dirsAdy = {{1,0}, {0,1}, {-1,0}, {0, -1}, {1, 1}, {-1, 1}, {1, -1}, {-1, -1}};

    int dfs(const Cuadricula& m, int inicioFilas, int inicioColumnas) {
        visitados[inicioFilas][inicioColumnas] = true;
        int tam = 1;
        for(auto d : dirsAdy) {
            int nF = inicioFilas + d.first, nC = inicioColumnas + d.second;
            if(posCorrecta(nF, nC) && m[nF][nC] && !visitados[nF][nC]) {
                tam += dfs(m, nF, nC);
                cd.unir(inicioFilas * columnas + inicioColumnas, nF * columnas + nC);
            }
        }
        return tam;
    }

    bool posCorrecta(int i, int j) const {
        return 0 <= i && i < filas && 0 <= j && j < columnas;
    }
public:
    CuadriculaConCjtosDisjuntos(Cuadricula const& c, int filas, int columnas) : cd(filas * columnas), cuadricula(c), filas(filas), columnas(columnas){
        visitados = Cuadricula(this->filas, vector<bool>(this->columnas, false));
        for(int i = 0; i < filas; ++i) {
            for(int j = 0; j < columnas; ++j) {
                if(!visitados[i][j] && cuadricula[i][j]) {
                    int tam = dfs(cuadricula, i, j);
                    maximaComponenteConexa = max(tam, maximaComponenteConexa);
                }
            }
        }
    }

    void anadirMancha(int x, int y) {
        if(!visitados[x][y]) {
            cuadricula[x][y] = true;
            for(auto d : dirsAdy) {
                int nF = x + d.first, nC = y + d.second;
                if(posCorrecta(nF, nC) && cuadricula[nF][nC] && !cd.unidos(x * columnas + y, nF*columnas + nC)) {
                    cd.unir(x * columnas + y, nF*columnas + nC);
                }
            }
            maximaComponenteConexa = max(maximaComponenteConexa, cd.cardinal(x*columnas + y));
            visitados[x][y] = true;
        }
    }

    inline int maxCC() const { return maximaComponenteConexa; }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    int F, C;
    std::cin >> F >> C;

    if(!std::cin) return false;

    string aux;
    getline(cin, aux);

    Cuadricula* c = new Cuadricula(F, vector<bool>(C, false));
    for(int i = 0; i < F; ++i) {
        getline(cin, aux);
        for(int j = 0; j < C; ++j) {
            char elem = aux[j];
            if(elem == ' ') continue;
            else if(elem == '#') (*c)[i][j] = true;
        }
    }


    int numFotos;
    cin >> numFotos;

    CuadriculaConCjtosDisjuntos* ccd = new CuadriculaConCjtosDisjuntos(*c, F, C);
    std::cout << ccd->maxCC() << " ";

    for(int k = 0; k < numFotos; ++k) {
        int a, b;
        cin >> a >> b;
        ccd->anadirMancha(a - 1, b - 1);
        std::cout << ccd->maxCC() << " ";
    }
    std::cout << "\n";

    // resolver el caso posiblemente llamando a otras funciones
    // escribir la solución

    delete ccd;
    delete c;
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
