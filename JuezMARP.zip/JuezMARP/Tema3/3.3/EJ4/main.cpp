
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "GrafoValorado.h"  // propios o los de las estructuras de datos de clase
#include "PriorityQueue.h"
#include "ConjuntosDisjuntos.h"

/*@ <answer>

 Escribe aquí un comentario general sobre la solución, explicando cómo
 se resuelve el problema y cuál es el coste de la solución, en función
 del tamaño del problema.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class ARMKruskal {
private:
    std::vector<Arista<int>> _ARM;
    int coste;
    int _aeropuertos;
public:
    int costeARM() const {return coste;}
    int aeropuertos(GrafoValorado<int> const& gv) const {return _aeropuertos;}
    ARMKruskal(GrafoValorado<int> const& gv) : coste(0), _aeropuertos(0) {
        PriorityQueue<Arista<int>> pq(gv.aristas());
        ConjuntosDisjuntos cjtos(gv.V());
        while(!pq.empty()) {
            auto a = pq.top(); pq.pop();
            int v = a.uno(), w = a.otro(v);
            if(!cjtos.unidos(v,w)) {
                cjtos.unir(v,w);
                _ARM.push_back(a); coste += a.valor();
                _aeropuertos = max(cjtos.num_cjtos(), _aeropuertos);
                if(_ARM.size() == gv.V() - 1) {
                    break;
                }
            }
        }
    }
};

bool resuelveCaso() {
    int N, M, A;
    cin >> N >> M >> A;
    // leer los datos de la entrada
    if (!std::cin)  // fin de la entrada
        return false;

    GrafoValorado<int> gv(N);

    for(int i = 0; i < M; ++i) {
        int X, Y, C;
        cin >> X >> Y >> C;
        Arista<int> tmp(X - 1, Y - 1, C);
        gv.ponArista(tmp);
    }

    ARMKruskal arm(gv);
    std::cout << arm.costeARM() + arm.aeropuertos(gv) * A << " " << arm.aeropuertos(gv) << "\n";
    // resolver el caso posiblemente llamando a otras funciones

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
