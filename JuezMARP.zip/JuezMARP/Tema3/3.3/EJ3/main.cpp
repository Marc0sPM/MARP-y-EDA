
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "GrafoValorado.h"  // propios o los de las estructuras de datos de clase
#include "ConjuntosDisjuntos.h"
#include "PriorityQueue.h"

/*@ <answer>

 Para resolver este problema basta con utilizar el algoritmo de Kruskal para calcular el valor de un árbol de
 recubrimiento de coste mínimo. Para comprobar si están todos los puentes presupuestados, basta con comprobar
 si el tamaño del árbol de recubrimiento mínimo es igual al número de vértices del grafo - 1. Si se cumple
 esa condición, hay suficientes puentes presupuestados para recorrer las islas; si no, no los hay, y por tanto
 tendremos que devoler "No hay puentes suficientes".
 La complejidad en tiempo del algortimo es del orden de O(P log I), siendo P el número de puentes presupuestados
 e I el número de islas.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class ARMKruskal {
private:
    std::vector<Arista<int>> _ARM;
    int coste;
public:
   int costeARM() const {return coste;}
   bool todoConectado(GrafoValorado<int> const& gv) const {return _ARM.size() == (gv.V() - 1);}
   ARMKruskal(GrafoValorado<int> const& gv) : coste(0) {
       PriorityQueue<Arista<int>> pq(gv.aristas());
       ConjuntosDisjuntos cjtos(gv.V());
       while(!pq.empty()) {
           auto a = pq.top(); pq.pop();
           int v = a.uno(), w = a.otro(v);
           if(!cjtos.unidos(v,w)) {
               cjtos.unir(v,w);
               _ARM.push_back(a); coste += a.valor();
               if(_ARM.size() == gv.V() - 1) break;
           }
       }
   }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    GrafoValorado<int> gv(cin, 1);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    ARMKruskal arm(gv);

    // escribir la solución
    if(arm.todoConectado(gv)) cout << arm.costeARM() << "\n";
    else cout << "No hay puentes suficientes\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
