
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

#include "GrafoValorado.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>

 Para resolver este problema haremos uso de la clase de GrafoValorado y una clase RecorridoGrafoValorado
 en la que simplemente nos limitaremos a hacer una búsqueda en profundidad. Ya que la búsqueda en profundidad
 nos devuelve en el vector visit todos los nodos que son accesibles desde uno inicial, basta con comprobar
 si el nodo objetivo devuelve "true" en nuestro vector una vez hecha la búsqueda.
 Por cada una de las iteraciones que se hagan a la búsqueda (tantas como consultas haya), el vector de visit
 hay que volver a resetearlo, por tanto, la complejidad de este ejercicio es del orden de O(K * (V+E)), siendo
 K el número de consultas, V el número de intersecciones y E el número de calles.
 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class RecorridoGrafoValorado {
private:
    GrafoValorado<int> const *grafVal;
    std::vector<bool> visit;

    void dfs(GrafoValorado<int> const& gv, int v, int umbral) {
        visit[v] = true;
        for(auto a : gv.ady(v)) {
            if(a.valor() >= umbral) {
                int w = a.otro(v);
                if(!visit[w]) dfs(gv, w, umbral);
            }
        }
    }
public:
    RecorridoGrafoValorado(GrafoValorado<int> const& gv) : grafVal(&gv), visit(gv.V(), false){}
    bool posible(int desde, int hasta, int anchura) {
        for(auto e : visit) e = false;
        dfs(*grafVal, desde, anchura);
        return visit[hasta];
    }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    GrafoValorado<int> gv(cin, 1);
    if (!std::cin)  // fin de la entrada
        return false;

    RecorridoGrafoValorado rgv(gv);
    int K;
    cin >> K;
    for(int i = 0; i < K; ++i) {
        int desde, hasta, anchura;
        cin >> desde >> hasta >> anchura;
        cout << (rgv.posible(desde - 1, hasta -1, anchura) ? "SI\n" : "NO\n");
    }

    // resolver el caso posiblemente llamando a otras funciones

    // escribir la solución

    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
