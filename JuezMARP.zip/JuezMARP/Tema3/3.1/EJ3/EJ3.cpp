
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
using Bitmap = vector<vector<bool>>;

/*@ <answer>

 Para resolver este ejercicio he utilizado una implementación similar a la del vídeo del CV, con la diferencia
 de usar en lugar de una matriz de cadenas, una matriz de booleanos para representar el tablero: cada cuadrado
 blanco está marcado como false, mientras que los cuadrados negros están marcados como true. El resto de la implementación
 es prácticamente igual: en la constructora de la clase DetectorBitmap se crea el Bitmap (vector de vectores de bool) leyendo
 desde la entrada, y posteriomente se hace una búsqueda en profundidad de cada uno de los elementos que no hayan sido
 visitados y que estén marcados como true en nuestro bitmap, devolviendo así el tamaño de la mancha, y, mediante un contador
 teniendo registro del número de componentes conexas que tenemos en nuestro bitmap.

 Por tanto, al tener que recorrer el bitmap entero para analizarlo, tenemos que el coste de nuestra implementación sería
 de complejidad O(F * C), siendo ese el tamaño del bitmap.

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class DetectorBitmap {
private:
    int totalComponentesConexas, filas, columnas, maximaComponenteConexa;
    Bitmap visitados;
    Bitmap bitmap;
    const vector<pair<int, int>> dirsAdy = {{1,0}, {0,1}, {-1,0}, {0, -1}};

    int dfs(const Bitmap& m, int inicioFilas, int inicioColumnas) {
        visitados[inicioFilas][inicioColumnas] = true;
        int tam = 1;
        for(auto d : dirsAdy) {
            int nF = inicioFilas + d.first, nC = inicioColumnas + d.second;
            if(posCorrecta(nF, nC) && m[nF][nC] && !visitados[nF][nC]) {
                tam += dfs(m, nF, nC);
            }
        }
        return tam;
    }

    bool posCorrecta(int i, int j) const {
        return 0 <= i && i < filas && 0 <= j && j < columnas;
    }

    Bitmap lecturaBitmap(std::istream& flujo) {
        //Creación del bitmap
        flujo >> this->filas >> this->columnas;
        Bitmap tmp(filas, vector<bool>(columnas, false));
        char casilla;
        //Rellenamos el bitmap
        for(int j = 0; j < filas; ++j) {
            for(int k = 0; k < columnas; ++k) {
                flujo >> casilla;
                switch(casilla) {
                    case '-': {
                        tmp[j][k] = false;
                    } break;
                    case '#': {
                        tmp[j][k] = true;
                    } break;
                }
            }
        }
        return tmp;
    }

public:
    DetectorBitmap(std::istream& flujo) : bitmap(lecturaBitmap(flujo)), totalComponentesConexas(0){
        visitados = Bitmap(filas, vector<bool>(columnas, false));
        for(int i = 0; i < filas; ++i) {
            for(int j = 0; j < columnas; ++j) {
                if(!visitados[i][j] && bitmap[i][j]) {
                    ++totalComponentesConexas;
                    int tam = dfs(bitmap, i, j);
                    maximaComponenteConexa = max(tam, maximaComponenteConexa);
                }
            }
        }
    }

    inline int numCC() const { return totalComponentesConexas; }
    inline int maxCC() const { return maximaComponenteConexa; }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    DetectorBitmap* dB = new DetectorBitmap(std::cin);

    if (!std::cin)  // fin de la entrada
        return false;

    // escribir la solución

    std::cout << dB->numCC() << " " << dB->maxCC() << "\n";
    delete dB;
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
