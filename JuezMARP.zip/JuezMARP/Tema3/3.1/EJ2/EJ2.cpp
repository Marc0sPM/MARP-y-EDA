
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "Grafo.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>
  
    Para resolver este ejercicio hacemos uso de una clase Amigos, que contendrá un vector de booleanos
    con los nodos anteriormente visitados, y dos enteros, uno con un tamaño de grupo y otro con el tamaño
    más grande de los grupos que se hayan leído.

    En la constructora llamamos al método dfs, que es un recorrido en profundidad que va incrementando en 1
    el número de nodos visitados (tamGrupo); y lo llamamos V veces (una por vértice mientras que no esté
    ya visitado). Finalmente, comprobamos si el tamaño del grupo que se ha leído es mayor que el
    tamaño de grupo máximo, igualamos el tamaño de grupo máximo al del grupo que se acaba de leer, y posteriormente
    "reseteamos" el tamaño del grupo leído.

    Por lo que la complejidad de este ejercicio es O(V * (V+A))
 
 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class Amigos {
private:
    vector<bool> visitados;
    int tamGrupo;
    int maxTamGrupo;

    void dfs(const Grafo& g, int ini) {
        visitados[ini] = true;
        ++tamGrupo;
        for(int w : g.ady(ini)) {
            if(!visitados[w]) {
                dfs(g, w);
            }
        }
    }
public:
    Amigos(const Grafo& g) : visitados(g.V(), false), tamGrupo(0), maxTamGrupo(0) {
        for(int i = 0; i < visitados.size(); ++i) {
            if(!visitados[i]) {
                dfs(g, i);
                if(tamGrupo > maxTamGrupo) maxTamGrupo = tamGrupo;
                tamGrupo = 0;
            }
        }
    }

    inline int maxGrupo() const { return maxTamGrupo; }
};

void resuelveCaso() {

    // leer los datos de la entrada

    Grafo g(std::cin, 1);
    Amigos a(g);

    // resolver el caso posiblemente llamando a otras funciones
    std::cout << a.maxGrupo() << "\n";

    // escribir la solución
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
