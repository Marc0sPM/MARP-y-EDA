
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "Grafo.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>

 Para resolver este problema nos creamos una clase ArbolLibre, en la que tenemos los booleanos que indican
 si un grafo es un árbol libre o no (los booleanos aciclico y conexo), un vector de booleanos de tamaño N
 para indicar los visitados, y un entero que pasa por los nodos visitados del árbol. En la constructora,
 hacemos un recorrido en profundidad del árbol, de manera que cada vez que visitamos un nodo nuevo incrementamos
 el contador de nodos visitados.
 Finalmente, comprobamos si el grafo es conexo si el número total de nodos visitados es igual al número de nodos
 totales del grafo, y comprobamos si es acíclico si el número de aristas totales del grafo coincide con el
 número de nodos visitados - 1.

 Por tanto, la complejidad del ejercicio es O(V+A).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class ArbolLibre {
private:
    bool aciclico;
    bool conexo;
    vector<bool> visitados;
    int totalNodosVisitados;

    void dfs(const Grafo& g, int ini) {
        visitados[ini] = true;
        totalNodosVisitados++;
        for(int w : g.ady(ini)) {
            if(!visitados[w]) {
                dfs(g, w);
            }
        }
    }
public:
    ArbolLibre(const Grafo& g) : visitados(g.V(), false), totalNodosVisitados(0), aciclico(true), conexo(true) {
        dfs(g, 0);
        conexo = totalNodosVisitados == g.V();
        if(conexo) aciclico = g.A() == totalNodosVisitados - 1;
    }

    inline bool esArbolLibre() const { return aciclico && conexo; }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    Grafo g(std::cin);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones
    ArbolLibre aL(g);

    aL.esArbolLibre() ? std::cout << "SI\n" : std::cout << "NO\n";

    // escribir la solución
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
