
/*@ <answer>
 *
 * Nombre y Apellidos: Alejandro Massó Martínez - MARP21
 *
 *@ </answer> */

#include <iostream>
#include <fstream>
using namespace std;

#include "Grafo.h"  // propios o los de las estructuras de datos de clase

/*@ <answer>

 Para resolver este problema he hecho uso de una clase Red, que contendrá un vector de booleanos para representar
 los elementos visitados, un vector de enteros para llevar la cuenta de la distribución de noticias de cada uno
 de los usuarios de la red y un grafo red. La entrada se lee desde el método lecturaRed, que guarda los elementos leídos
 en un vector de tamaño UG (usuarios de grupo), para posteriormente introducirlos en el grafo haciendo uso
 del método ponArista, que es constante O(1), por tanto la lectura tiene complejidad O(M * UG).

 Posteriormente, en la constructora, tenemos que recorrer el grafo entero N veces, para guardar en el vector
 distrNoticias el número de veces que se han distribuido las noticias dada una persona (el número de adyacentes
 que este tiene), por lo que al final del recorrido en profundidad, se deben volver a poner todos los booleanos
 del vector visitado a false.

 Por tanto, la complejidad de este ejercicio es O(N * (N + A)), siendo N el número de usuarios y A el número de
 aristas del grafo (las relaciones de una persona con otras).

 @ </answer> */


// ================================================================
// Escribe el código completo de tu solución aquí debajo
// ================================================================
//@ <answer>

class Red {
private:
    vector<bool> visitados;
    vector<int> distrNoticias;
    int usuarios;
    Grafo* red;

    void lecturaRed(std::istream& flujo) {
        int grupos;
        flujo >> usuarios >> grupos;
        red = new Grafo(usuarios);
        distrNoticias = vector<int>(usuarios, 0);
        for(int i = 0; i < grupos; ++i) {
            int usersGrp;
            vector<int> users;
            flujo >> usersGrp;
            for(int j = 0; j < usersGrp; ++j) {
                int user;
                flujo >> user;
                users.push_back(user);
            }
            for(int k = 0; k < users.size() - 1 && !users.empty() && users.size() <= usuarios; ++k) {
                red->ponArista(users[k] - 1, users[k+1] - 1);
            }
        }
    }

    int dfs(const Grafo& g, int ini) {
        visitados[ini] = true;
        int tam = 1;
        for(auto w : g.ady(ini)) {
            if(!visitados[w]) {
                tam += dfs(g, w);
            }
        }
        return tam;
    }

    void resetVisitas() {
        for(int i = 0; i < visitados.size(); ++i) visitados[i] = false;
    }
public:
    Red(std::istream& flujo) {
        lecturaRed(flujo);
        visitados = std::vector(usuarios, false);
        for(int i = 0; i < usuarios; ++i) {
            distrNoticias[i] = dfs(*red, i);
            resetVisitas();
        }
    }

    void distribucionNoticias() const {
        for(int i = 0; i < distrNoticias.size(); ++i) {
            std::cout << distrNoticias[i] << " ";
        }
    }
};

bool resuelveCaso() {

    // leer los datos de la entrada
    Red* r = new Red(std::cin);

    if (!std::cin)  // fin de la entrada
        return false;

    // resolver el caso posiblemente llamando a otras funciones

    // escribir la solución
    r->distribucionNoticias();
    std::cout << "\n";
    return true;
}

//@ </answer>
//  Lo que se escriba dejado de esta línea ya no forma parte de la solución.

int main() {
    // ajustes para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // para dejar todo como estaba al principio
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
