#include <iostream>
#include <fstream>
#include "bintree_eda.h"
using namespace std;

/// <summary>
/// Coste lineal ya que se debe recorrer todo el espacio de busqueda (los nodos) para determinar la cantidad de tramos navegables
/// 
/// Es decir: se realizan dos llamadas recursivas de tamaño mitad sin costes adicionales;
/// </summary>
/// <param name="arb"></param>
/// <returns></returns>
pair<int, int> Tramos(bintree<int> arb) {
    if (arb.empty()) {
        return pair<int, int>(0, 0);
    }

    if (arb.left().empty() && arb.right().empty()) {
        return { 1,0 };
    }

    pair<int,int> left = Tramos(arb.left());
    pair<int, int> right = Tramos(arb.right());

    int caudal = left.first + right.first - arb.root();
    int tramos = left.second + right.second;

    if (left.first >= 3) tramos++;
    if (right.first >= 3) tramos++;
    /*if (caudal >= 3) {
        tramos++;
    }*/

    return { caudal, tramos };

}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso(){
	bintree<int> arb;
	arb = leerArbol(-1); // -1 es la repr. de arbol vacio
    cout << Tramos(arb).second << endl;
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}

