#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
#include <stack>
#include "bintree_eda.h"
using namespace std;


bintree<int> reconstruir(const vector<int>& preorden, const vector<int>& inorden, 
	int iterator, int inorIni, int inorFin) {

	int raiz = preorden[iterator];
	//cout << raiz << endl;
	//final
	if (inorIni >= inorFin) {
		return {raiz};
	}
	//determinar los parametros mágicos
	else {
		//busqueda del centro en el inorden
		int posInor = inorIni;
		while (posInor < inorFin && raiz != inorden[posInor]) {
			posInor++;
		}


		int iterDer = iterator;
		if (posInor == inorFin) {
			while (iterDer < preorden.size() && inorden[posInor + 1] != preorden[iterDer])
			{
				iterDer++;
			}
		}
		

		//construccion del arbol
		bintree<int> iz = {};
		bintree<int> dr = {};
		if(posInor != inorIni)
			iz = reconstruir(preorden, inorden, iterator+1, inorIni,posInor);
		if(posInor +1 != inorFin)
			dr = reconstruir(preorden, inorden, iterDer, posInor, inorFin);
		return { iz, raiz, dr };
	}
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
	bintree<int> tree;
	vector<int> preordenV;
	vector<int> inordenV;
	if (!cin) {
		return false;
	}
	string line;
	getline(cin, line);
	istringstream iss(line);
	int n;
	while (iss >> n)
	{
		preordenV.push_back(n);
	}
	getline(cin, line);
	istringstream iss2(line);
	while (iss2 >> n)
	{
		inordenV.push_back(n);
	}
	//cout << preordenV.back();
	tree = reconstruir(preordenV, inordenV,0,0,inordenV.size());

	for (int& e : tree.postorder()) {
		cout << e << " ";
	}
	cout << endl;
	// leer los datos de la entrada
	//bintree<int> tree = leerArbol(-1);


	return true;
}


//#define DOMJUDGE
int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	while (resuelveCaso())
		;

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	//system("PAUSE");
#endif

	return 0;
}