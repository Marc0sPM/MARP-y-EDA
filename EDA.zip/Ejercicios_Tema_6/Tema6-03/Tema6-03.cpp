#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include "bintree_eda.h"
using namespace std;


template <class T>
//hay que asegurarse de no llegar al arbol vacío
T singulares( bintree<T> const& tree) {
	T left, right;
	//si es hoja
	if (tree.left().empty() && tree.right().empty()) {
		return tree.root();
	}
	//sin izquierda
	else if (tree.left().empty()) {
		return min(singulares(tree.right()), tree.root());
	}
	//sin derecha
	else if (tree.right().empty()) {
		return min(singulares(tree.left()), tree.root());
	}
	else
	{
		left = singulares(tree.left());
		right = singulares(tree.right());

		return min(tree.root(), min(right, left));
	}
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {

	char tipo;
	cin >> tipo;

	if (!cin) {
		return false;
	}


	// leer los datos de la entrada
	if (tipo == 'N'){
		bintree<int> tree = leerArbol(-1);
		cout << singulares(tree) << endl;
	}
		
	else if (tipo == 'P') {
		bintree<string> tree = leerArbol<string>("#");
		cout << singulares(tree) << endl;
	}
	
	return true;
}


//#define DOMJUDGE
int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	while (resuelveCaso())
		;

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	//system("PAUSE");
#endif

	return 0;
}