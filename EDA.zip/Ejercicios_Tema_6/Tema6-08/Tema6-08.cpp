#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <climits>
#include <stack>
#include "bintree_eda.h"
using namespace std;

int singular( const bintree<int>& tree, int sumaAncestros, int& suma) {
	if (tree.empty()) {
		return 0;
	}
	else {
		int sumaIz = 0;
		int sumaDr = 0;

		//suma in place para no tener que actualizar fuera de las llamadas
		int iz = singular(tree.left(), sumaAncestros + tree.root(), sumaIz);
		int dr = singular(tree.right(), sumaAncestros + tree.root(), sumaDr);
		int res = iz + dr;
		suma += sumaIz + sumaDr;
		if (sumaAncestros == suma) res++;
		suma += tree.root();
		return res;
	}

}

//int suma(bintree a) {
//	if (a.empty())
//		return 0;
//	return suma(a.left()) + suma(a.right()) + a.root();
//}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
	// leer los datos de la entrada
	bintree<int> tree;
	tree = leerArbol(-1);
	int sol = 0;
	int suma = 0;
	sol = singular(tree,0,suma);
	cout<< sol<< endl;
}


//#define DOMJUDGE
int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	//system("PAUSE");
#endif

	return 0;
}