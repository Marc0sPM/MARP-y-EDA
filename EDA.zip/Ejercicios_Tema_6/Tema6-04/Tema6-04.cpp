#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <climits>
#include "bintree_eda.h"
using namespace std;


template <class T>
bool binDeBusqueda(bintree<T> const& tree, T& max, T& min) {
	if (tree.empty()) {
		min = INT_MAX;
		max = INT_MIN;
		return true;
	}
	//si soy hoja siempre soy de búsqueda
	else if (tree.left().empty() && tree.right().empty()) {
		min = max = tree.root();
		return true;
	}
	else {
		int minIz, maxIz, minDr, maxDr;

		// Propago para obtener el maximo y minimo del hijo izquierdo
		if (!binDeBusqueda(tree.left(), maxIz, minIz)) return false;
		// Propago para obtener el maximo y minimo del hijo derecho
		if (!binDeBusqueda(tree.right(), maxDr, minDr)) return false;

		// Calculo el minimo y maximo del subarbol
		min = std::min(tree.root(), std::min(minIz, minDr));
		max = std::max(tree.root(), std::max(maxIz, maxDr));

		// Comprobacion de que la parte izquierda es menor que la raiz y la parte derecha es mayor que la raiz
		return maxIz < tree.root() && minDr > tree.root();

	}
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
	// leer los datos de la entrada
	bintree<int> tree;
	tree = leerArbol(-1);
	int min = INT_MIN;
	int max = INT_MAX;
	cout << (binDeBusqueda(tree,max,min)? "SI": "NO") << endl;
}


//#define DOMJUDGE
int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	//system("PAUSE");
#endif

	return 0;
}
