#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <climits>
#include "bintree_eda.h"
using namespace std;


bool genealogico (bintree<int> const& tree, int& generaciones) {
	if (tree.empty()) {
		return true;
	}
	else if (tree.left().empty()&& !tree.right().empty()) {
		generaciones++;
		return false;
	}
	else {
		int generacionesIz, generacionesDr;
		bool condicion1, condicion2,condicion3;
		condicion1 = condicion2 = true;
		//inicializamos la generacion
		generacionesDr = generacionesIz = generaciones;
		generaciones++;

		//los hijos son 18 años mas pequeños que el padre
		if (!tree.left().empty()) {
			condicion1 = tree.root() >= tree.left().root() + 18;
		}
		//entre hermanos se llevan 2 o mas años
		if (!tree.right().empty()) {
			condicion1 = condicion1 && tree.root() >= tree.right().root() + 18;
			condicion2 = (tree.left().root() >= tree.right().root() + 2);
		}
		//ambios hijos cumplen con el arbol
		condicion3 = genealogico(tree.left(), generacionesIz) && genealogico(tree.right(), generacionesDr);
		//determinamos en que generacion estamos
		generacionesDr++;
		generacionesIz++;
		generaciones = max(generacionesIz, generacionesDr);
		return condicion1 && condicion2 && condicion3;
	}
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
	// leer los datos de la entrada
	bintree<int> tree;
	tree = leerArbol(-1);
	int nivel = 0;
	if (genealogico(tree, nivel)) {
		cout << "SI " << nivel<<endl;
	}
	else {
		cout << "NO " << endl;
	}
	//cout << endl;
}


//#define DOMJUDGE
int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();

	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	//system("PAUSE");
#endif

	return 0;
}