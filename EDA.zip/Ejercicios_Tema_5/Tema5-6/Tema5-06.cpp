// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

bool noVocal(char a) {
    return a != 'a' && a != 'e' && a != 'i' && a != 'o' && a != 'u' &&
        a != 'A' && a != 'E' && a != 'I' && a != 'O' && a != 'U';
}

// función que resuelve el problema
string resolver(string datos) {
    string aux;
    stack<char> pilaImpares;
    for (int i = 0; i < datos.size(); i++) {
        if (i % 2 == 0) {
            aux+= datos[i];
        }
        else {
            pilaImpares.push(datos[i]);
        }
    }
    //cout << aux << endl;
    int iteraciones = pilaImpares.size();
    for (int i = (datos.size() / 2); !pilaImpares.empty();) {
        aux += pilaImpares.top();
        pilaImpares.pop();
    }
    //cout << aux << endl;

    stack<char> rotationStakc;
    int lastVowelIndex = 0;
    for (int i = 0; i < aux.size(); i++) {
        if (noVocal(aux[i])){
            rotationStakc.push(aux[i]);
        }
        else{
            for (int j = lastVowelIndex+1; j < i; j++) {
                aux[j] = rotationStakc.top();
                rotationStakc.pop();
            }
            lastVowelIndex = i;
        }

    }
    return aux;
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada


    string caso;
    getline(cin, caso);
    if (!std::cin)
        return false;

    cout <<resolver(caso)<<endl;

    // escribir sol


    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}