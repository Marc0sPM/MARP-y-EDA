#include <iostream>
#include <iomanip>
#include <fstream>
#include "queue_eda.h"
using namespace std;


template <class T>
class queue_plus : public queue<T> {
    using Nodo = typename queue<T>::Nodo;

public:
    void cuela(const T& a, queue_plus<T>& other) {
        // Ojo que para acceder a prim o ult hay que escribir this->prim o this->ult
        Nodo* aux = this->prim;

        //busqueda del pringado
        while (aux != nullptr && aux->elem != a)
        {
            aux = aux->sig;
        }
        //si el pringado se encuentra ahi
        if (aux != nullptr) {
            other.ult->sig = aux->sig;
            other.ult = nullptr;

            aux->sig = other.prim;
            other.prim = nullptr;

            this->nelems += other.nelems;
            other.nelems = 0;
        }
        
    }
};


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n, a;
    queue_plus<int> q;
    queue_plus <int> q2;
    queue_plus<int> q3;
    cin >> n;
    if (n == -1) return false;
    while (n != -1) {
        q.push(n);
        cin >> n;
    }
    cin >> a;
    cin >> n;
    while (n != -1) {
        q2.push(n);
        cin >> n;
    }

    q3 = q;

    // llamada a metodo
    q.cuela(a, q2);

    // Ahora imprimimos la cola y de paso la dejamos vacía
    while (!q3.empty()) {
        cout << q3.front() << " ";
        q3.pop();
    }
    cout << endl;
    // Ahora imprimimos la cola y de paso la dejamos vacía
    while (!q.empty()) {
        cout << q.front() << " ";
        q.pop();
    }
    cout << endl;
    return true;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif
    int iterations;
    cin >> iterations;
    for (int i = 0; i < iterations; i++)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}
