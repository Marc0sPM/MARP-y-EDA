#include <iostream>
#include <iomanip>
#include <fstream>
#include "list_eda.h"
using namespace std;


template <class T>
class list_plus : public list<T> {
    using Nodo = typename list<T>::Nodo;

public:
    void eliminaMulti(const T& a) {
        Nodo* it = this->fantasma->sig;
        Nodo* aux = it;
        while (it != this->fantasma)
        {
            aux = aux->sig;
            if (it->elem == a)
                this->borra_elem(it);
            it = aux;
        }

    }
};

template <class T>
void resolver(list<T>& lista, T a){
    typename list<T>::iterator it = lista.begin();


    while (it != lista.end())
    {
        if ((*it) == a) {
            it = lista.erase(it);
        }
        //para evitar avances dobles
        else
        {
            ++it;
        }
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n, a;
    list<int> l;
    list<int> original;
    cin >> n;
    if (n == -1) return false;
    while (n != -1) {
        l.push_back(n);
        cin >> n;
    }
    cin >> a;

    original = l;
    // llamada a metodo
    resolver(l, a);
    // Ahora imprimimos la cola y de paso la dejamos vacía
    for (int a : original) {
        cout << a << " ";
    }
    cout << endl;
    // Ahora imprimimos la cola y de paso la dejamos vacía
    for (int a : l) {
        cout << a << " ";
    }
    cout << endl;
    return true;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif
    int iterations;
    cin >> iterations;
    for (int i = 0; i < iterations; i++)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}

