﻿// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <deque>
#include <vector>

using namespace std;

// función que resuelve el problema
deque<int> resolver(vector<int> datos) {
    deque<int> salida;
    for (int num : datos) {
        if (num > 0) salida.push_back(num);
        else salida.push_front(num);
    }
    return salida;
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    int tam;
    // leer los datos de la entrada
    cin >> tam;
    if (tam == 0)
        return false;
    deque<int> sol;
    vector<int> datos(tam);
    for (int i = 0; i < datos.size(); i++ ) {
        cin >> datos[i];
    }
    sol =resolver(datos);
    // escribir sol
    for (int& a : sol)
        cout << a << " ";
    cout << endl;
    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}
