#include <iostream>
#include <iomanip>
#include <fstream>
#include "queue_eda.h"
using namespace std;


template <class T>
class queue_plus : public queue<T> {
    using Nodo = typename queue<T>::Nodo;

public:
    void sortedMerge(queue_plus<T>& other) {
        //solo se procede si la segunda cola tiene algo que llenar
        if (!other.empty()) {
            //si la cola principal esta vacia
            if (this->empty()) {
                this->prim = other.prim;
                this->ult = other.ult;
                this->nelems = other.nelems;
                other.prim = nullptr;
            }
            else {
                Nodo* aux = this->prim;
                Nodo* aux2 = other.prim;
                //si el primer elemento de la cola 2 es menos que el de la original
                if (aux->elem > aux2->elem) {
                    aux2 = other.prim->sig;
                    this->prim = other.prim;
                    other.prim = other.prim->sig;
                    this->prim->sig = aux;
                    aux = this->prim;
                }
                while(aux!=nullptr && aux2 != nullptr)
                {
                    // si aux es el ultimo elemento
                    if (aux->sig == nullptr) {
                        aux->sig = aux2;
                        other.prim = nullptr;
                    }
                    // insertar elemento de la cola 2 a cola 1
                    else if (aux->elem <= aux2->elem && aux->sig->elem >= aux2->elem) {
                        other.prim = aux2->sig;
                        aux2->sig = aux->sig;
                        aux->sig = aux2;
                    }
                    //avanzar punteros
                    aux = aux->sig;
                    aux2 = other.prim;
                }

                this->ult = aux;
                this->nelems += other.nelems;
            }
        }
    }
};


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n;
    queue_plus<int> q;
    queue_plus<int> q2;
    cin >> n;
    if (!cin) return false;
    while (n != 0) {
        q.push(n);
        cin >> n;
    }
    cin >> n;
    while (n != 0) {
        q2.push(n);
        cin >> n;
    }

    // llamada a metodo
    q.sortedMerge(q2);

    // Ahora imprimimos la cola y de paso la dejamos vacía
    while (!q.empty()) {
        cout << q.front() << " ";
        q.pop();
    }
    cout << endl;
    return true;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif
    int iterations;
    cin >> iterations;
	for (int i = 0; i < iterations; i++)
		resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}