﻿// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <stack>
#include <string>

using namespace std;


// función que resuelve el problema
string resolver(stack<pair<string, int>>& dates,pair<string,int> accidentes) {
    while (!dates.empty() && dates.top().second <= accidentes.second) {
        dates.pop();
    }
    if (dates.empty()) {
        dates.push(accidentes);
        return "NO HAY";
    }
    else {
        string date;
        date = dates.top().first;
        dates.push(accidentes);
        return date;
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int nDates;
    cin >> nDates;
    if (!std::cin)
        return false;
    stack<pair<string,int>> values;
    string date;
    int nMuertos;
    for (int i = 0; i < nDates; i++) {
        cin >> date >> nMuertos;
        //cout << date << " " <<nMuertos <<endl;
        cout << resolver(values, { date,nMuertos })<<endl;
    }

    // escribir sol
    cout << "---"<<endl;

    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}