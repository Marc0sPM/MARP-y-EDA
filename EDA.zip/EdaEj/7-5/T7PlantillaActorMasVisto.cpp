#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;


using Pelicula = string;
using Actor = string;
using Reparto = vector < pair<Actor, int>>;
using RepartosPeliculas = unordered_map<Pelicula, Reparto>;



void leerRepartos(int numPeliculas, RepartosPeliculas& peliculas){
    Pelicula peli; int numActores;
    Actor actor; int minutos;
    for (int i = 0; i < numPeliculas; ++i){
        cin >> peli; cin >> numActores;
        for (int j = 0; j < numActores; ++j){
            cin >> actor >> minutos;
            peliculas[peli].push_back({actor,minutos});
        }
    }
}


void procesarEmisiones(RepartosPeliculas const& repartos, vector<string> const& secEmisiones){

    unordered_map<Pelicula, int> peliculas;

    for (auto e : secEmisiones) {
        peliculas[e]++;
    }
    // busqueda de la mejor pelicula lineal respecto al numero de emisiones
    Pelicula peli = secEmisiones[0];
    for (auto p = secEmisiones.begin(); p != secEmisiones.end() - 1; p++) {
        if (peliculas[*p] < peliculas[*(p + 1)]) {
            peli = *(p + 1);
        }
    }

    cout << peliculas[peli] << " " << peli << endl;

    unordered_map<string, int> actores;
    //caculo de minutos por actor lineal respecto del numero de apariciones de un actor
    for (auto p : repartos) {
        for (auto act : p.second) {
            actores[act.first] += act.second * peliculas[p.first];
        }
    }

    //for (auto a : actores) {
    //    cout << a.first << " ";
    //}
    vector<string> masVistos;
    int maxTime = 0;
    for (auto act : actores) {
        if (act.second > maxTime) {
            maxTime = act.second;
            masVistos.clear();
            masVistos.push_back(act.first);
        }
        else if (act.second == maxTime) {
            masVistos.push_back(act.first);
        }
    }

    sort(masVistos.begin(), masVistos.end());

    cout << maxTime<< " ";
    for (auto act : masVistos) {
        cout << act << " ";
    }
    cout << endl;
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int numPelis, numEmisiones;
    cin >> numPelis;
    if (numPelis == 0)
        return false;

    // Lectura de los repartos de las peliculas
    RepartosPeliculas repartos;
    leerRepartos(numPelis, repartos);

    // Lectura de la secuencia de peliculas emitidas en vector<string>
    cin >> numEmisiones;
    vector<string> secEmisiones(numEmisiones);
    for (string& s : secEmisiones) cin >> s;

    procesarEmisiones(repartos, secEmisiones);

    return true;
}


//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("input3.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
#endif

    return 0;
}