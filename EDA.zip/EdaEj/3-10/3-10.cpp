#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
using namespace std;


template <class T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    for (auto e : v) out << e << " ";
    return out;
}

//bool esValido(vector<int>& sol, const vector<string>tipos, int k) {
//
//}

void resolver(vector<int>& sol, int k, int n,int nReg, vector<bool>&disponibles, const vector<vector<int>>& preferencias, 
    int valor, int& mejorValor, vector<int>& mejorSol, const vector<int>poda) {
    for (int i = 0; i < nReg; i++) {
        sol[k] = i;
        valor += preferencias[k][i];

        //validez
        if (disponibles[i]) {
            //solucion
            if (k==n-1) {
                //mejor Solucion
                if (valor > mejorValor) {
                    mejorValor = valor;
                    mejorSol = sol;
                }

            }
            else {
                if (valor+poda[k+1] > mejorValor) {
                    disponibles[i] = false;
                    resolver(sol, k + 1, n, nReg, disponibles, preferencias, valor, mejorValor, mejorSol,poda);
                    disponibles[i] = true;
                }
            }
        }
        valor -= preferencias[k][i];
    }
}


bool resuelveCaso() {
    //parametros de entradas
    int nRegalos, nNinios;
    // leer los datos de la entrada
    //num regalos
    cin >> nRegalos;
    if (!cin)
        return false;
    //num ninios
    cin >> nNinios;

    vector<int>niniosOptimizados(nNinios, 0);
    vector<vector<int>> preferencias(nNinios, vector<int>(nRegalos));
    for (int i = 0; i < nNinios; ++i)
        for (int j = 0; j < nRegalos; ++j) {
            cin >> preferencias[i][j];
            if (preferencias[i][j] > niniosOptimizados[i])
                niniosOptimizados[i] = preferencias[i][j];
        }

    for (int i = niniosOptimizados.size() - 2; i >= 0; i--)
        //acumulo el valor de potencia de forma descendente usando el valor del anterior
        niniosOptimizados[i] += niniosOptimizados[i + 1];


    vector<bool>disponibles(nRegalos, true);


    //solucion
    vector<int>sol(nNinios);
    vector<int>mejorSol(nNinios);

    bool conSol = false;
    int mejorValor = 0;
    resolver(sol, 0, nNinios,nRegalos, disponibles,preferencias,0,mejorValor,mejorSol, niniosOptimizados);
    //}

    // escribir sol
    cout <<mejorValor<< endl;

    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}