
#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <map>
#include <list>
#include <algorithm>
#include <vector>
using namespace std;

struct TeamData {
    int time = 0;
    int solved = 0;
    //nombre del problema y calificacion
    unordered_map<string, int> problems;
};

using resultados = unordered_map<string,TeamData>;
//nombre y numero de fallos si -1 ya es correcto
using problem = pair<string, int>;
using equipoP = pair<string, TeamData>;


bool sortingFunc(equipoP a,equipoP b) {

    return a.second.solved > b.second.solved ||
        ((a.second.solved == b.second.solved) && a.second.time < b.second.time) ||
        ((a.second.solved == b.second.solved) && (a.second.time == b.second.time) && a.first < b.first);
}


//coste lineal al numero de envios ya que la insercion en los mapas es constante
//coste n log n respecto al numero de equipos al usar el sort de algorithm
void procesaEnvios(vector<equipoP>& ans){
    resultados res;
    string equipo, problema, veredicto;
    int minuto;
    resultados::iterator team;
    //nombre del equipo
    cin >> equipo;
    while (equipo != "FIN") {
        cin >> problema >> minuto >> veredicto;
        resultados::iterator team = res.find(equipo);
        //si no estaba
        if (team == res.end()) {
            TeamData aux;
            //y es correcto
            res.insert(equipoP(equipo, aux)).first;
            if (veredicto == "AC") {
                //añadimos problema ya solucionado
                res[equipo].problems[problema] = -1;
                res[equipo].solved++;
                //añadimos tiempo
                res[equipo].time += minuto;
            }
            else {
                //añadimos problema con un fallo
                res[equipo].problems[problema] = 1;
            }
        }
        //si si estaba
        else {
            unordered_map<string, int>::iterator problem = res[equipo].problems.find(problema);
            //si el problema esta
            if (problem != res[equipo].problems.end()) {
                if (res[equipo].problems[problema] != -1) {
                    if (veredicto == "AC") {
                        //actualizamos temporizador
                        res[equipo].time += minuto + 20 * res[equipo].problems[problema];
                        //marcamos problema como correcto
                        res[equipo].problems[problema] = -1;
                        res[equipo].solved++;
                    }
                    else {
                        res[equipo].problems[problema]++;
                    }
                }
            }
            //si el problema no esta
            else {
                if (veredicto == "AC") {
                    //añadimos problema ya solucionado
                    res[equipo].problems[problema] = -1;
                    res[equipo].solved++;
                    //añadimos tiempo
                    res[equipo].time += minuto;
                }
                else {
                    //añadimos problema con un fallo
                    res[equipo].problems[problema] = 1;
                }
            }
        }

        //siguiente equipo
        cin >> equipo;
    }
    for (auto e : res) {
        ans.push_back(e);
    }

    sort(ans.begin(), ans.end(),sortingFunc);

}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
    vector<equipoP> ans;
    procesaEnvios(ans);

    for (auto e : ans) {
        cout << e.first << " " << e.second.solved << " " << e.second.time << endl;
    }

    // Se imprime la salida
    
    cout << "---\n";
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("input.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}