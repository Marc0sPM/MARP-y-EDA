#include <iostream>
#include <stdexcept>
#include <fstream>
#include <vector>
#include <string>
#include <unordered_map>
#include <algorithm>

using namespace std;
using Estado = string;
using Partido = string;
using Partidos = unordered_map<Partido, int>;

bool pairSort(pair<Partido, int>& a, pair<Partido, int>& b) {
    return a.first < b.first;
}

class ConteoVotos {

private:
    unordered_map<Estado, int> estados;
    unordered_map<Estado, pair<Partido,int>> ganador;
    unordered_map<Estado, Partidos> votos;
    Partidos partidos;
    

public:
    //complejidad constante de insercion
    void nuevo_estado(const Estado &nombre, int num_compromisarios) {
        if (estados.count(nombre) == 0) {
            estados[nombre] = num_compromisarios;
        }
        else {
            throw domain_error("Estado ya existente");
        }
    }  
    //complejidad constante de insercion
    void sumar_votos(const Estado &estado, const Partido &partido, int num_votos) {
        if (estados.count(estado) != 0) {
            votos[estado][partido] += num_votos;

            if (votos[estado][partido] > votos[estado][ganador[estado].first]) {
                partidos[ganador[estado].first] -= estados[estado];
                ganador[estado] = pair<Partido, int>(partido, votos[estado][partido]);
                partidos[ganador[estado].first] += estados[estado];
            }
        }
        else
        {
            throw domain_error("Estado no encontrado");
        }
    }
    //complejidad constante
    Partido ganador_en(const Estado &estado) const {
        if (estados.count(estado) == 0) {
            throw domain_error("Estado no encontrado");
        }
        else {
            return ganador.at(estado).first;
        }
    }

    //complejidad n log (n) siendo n el numero de partidos con representacion en la camara debido al sort aplicado

    vector<pair<Partido,int>> resultados() const {
        vector<pair<Partido, int>> resul;
        for (auto a : partidos) {
            if (a.second > 0) {
                resul.push_back(a);
            }
        }
        sort(resul.begin(), resul.end(),pairSort);
        return resul;
    }

}; 



bool resuelveCaso() {
    string comando;
    cin >> comando;
    if (!cin) return false;

    ConteoVotos elecciones;

    while (comando != "FIN") {
        try {
            if (comando == "nuevo_estado") {
                Estado estado;
                int num_compromisarios;
                cin >> estado >> num_compromisarios;
                elecciones.nuevo_estado(estado, num_compromisarios);
            } else if (comando == "sumar_votos") {
                Estado estado;
                Partido partido;
                int num_votos;
                cin >> estado >> partido >> num_votos;
                elecciones.sumar_votos(estado, partido, num_votos);
            } else if (comando == "ganador_en") {
                Estado estado;
                cin >> estado;
                Partido ganador  = elecciones.ganador_en(estado);
                cout << "Ganador en " << estado << ": " << ganador << "\n";
            } else if (comando == "resultados") {
                for (const auto &par : elecciones.resultados()) {
                    cout << par.first << " " << par.second << "\n";
                }
            }
        } catch (std::exception &e) {
            cout << e.what() << "\n";
        }
        cin >> comando;
    }

    cout << "---\n";
    return true;
}

int main() {
#ifndef DOMJUDGE
    ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); 
#endif

    while(resuelveCaso()) { }

#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif
    return 0;
}
