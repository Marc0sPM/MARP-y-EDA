#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
using namespace std;


template <class T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    for (auto e : v) out << e << " ";
    return out;
}

bool esValido(vector<int>& sol,const vector<string>tipos, int k) {
    
    return (k%2==0)||
        ((k%2==1)&&(tipos[sol[k]]!=tipos[sol[k-1]] && sol[k] >= sol[k - 1]));
}

/// <summary>
/// 
/// </summary>
/// <param name="sol"></param>
/// <param name="k"></param>
/// <param name="n"></param>
/// <param name="m">num ninios</param>
/// <param name="tipos"></param>
void resolver(vector<int>& sol, int k, int n, int m, const vector<string>& tipos, bool& conSol) {
    for (int i = 0; i < tipos.size(); i++){
        sol[k] = i;
        //valido
        if (esValido(sol, tipos, k)) {
            //solucion?
            if (k == m*2 - 1) {
                conSol = true;
                cout << sol <<endl;
            }
            else {
                resolver(sol, k + 1, n, m, tipos,conSol);
            }
        }
	}
}


bool resuelveCaso() {
    //parametros de entradas
    int n, m;
    // leer los datos de la entrada
    //tipos de regalos
    cin >> n;
    if (!cin)
        return false;
    //num ninios
    cin >> m;

    vector<string> tipos(n);

    for (auto& a : tipos) {
        cin >> a;
    }
    //tama�o = num de ninos * 2
    vector<int>sol(m*2);

    bool conSol = false;
    resolver(sol, 0,n,m,tipos, conSol);
    //}

    if(!conSol)
        cout << "SIN SOLUCION" << endl;

    // escribir sol
    cout << endl;

    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}