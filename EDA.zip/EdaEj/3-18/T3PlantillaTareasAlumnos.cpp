#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

template <class T>
ostream& operator<<(ostream& out, const vector<T>& v){
    for (auto e : v) out << e;
    return out;
}


bool esValido(const vector<int>& sol, int task, int maxTask, int al, const vector<int>& alumnos) {
    //si el alumno tiene mas de las tareas maximas
    return alumnos[al] < maxTask;
}

// función que resuelve el problema
void resolver(vector<int>& sol, int nAlumnos, int nCargos, int k, int t, int valor, int& mejorValor, vector<int>& alumnos, vector<vector<int>>& preferencias, vector<int>& trueSol) {
    for (int i = 0; i < nAlumnos; i++) {

        sol[k] = i; //posibilidad de que el alumno sea el correcto para el cargo

        if (esValido(sol, k/t, t, i,alumnos)) { //Es Valida
            valor += preferencias[i][k / t];
            if (k == nCargos * t - 1) { //Es Solucion
                if ( valor > mejorValor) //Es mejor
                {
                    mejorValor = valor;
                    trueSol = sol;
                }
            }
            else if (k < nCargos*2 - 1) {
                alumnos[i]++;
                resolver(sol, nAlumnos, nCargos, k + 1, t, valor, mejorValor, alumnos, preferencias, trueSol);
                alumnos[i]--;
            }
            valor -= preferencias[i][k / t];
        }
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n, a, t;
    cin >> n >> a >> t;
    if (n == 0 && a == 0 && t == 0) return false;
    vector<vector<int>> preferencias(a,vector<int>(n));
    for (int i = 0; i < a ; ++i)
        for (int j = 0; j < n; ++j) {
            cin >> preferencias[i][j];
        }

    vector<int> sol(n*2);
    vector<int> trueSol(n * 2);
    vector<int> alumnos(a); //registro de los alumnos que ya tienen cargo
    int mejorVal = INT_MIN;

    resolver(sol, a, n,0,t,0,mejorVal, alumnos, preferencias, trueSol);
    // Imprimir solucion
    cout << sol << endl;
    cout << alumnos << endl;
    cout << mejorVal<<endl;

    return true;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("input1.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}