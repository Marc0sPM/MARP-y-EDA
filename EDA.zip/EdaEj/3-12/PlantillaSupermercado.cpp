

#include <iostream>
#include <fstream>
#include <vector>
#include <climits>
using namespace std;



// función que resuelve el problema
void resolver(vector<int>& soluc, int k, int n, int m, const vector<vector<int>>& precios, vector<int>&frecsSuper, int valor, int& mejorValor, vector<int>& poda){
    for (int i = 0; i < m; i++) {
        soluc[k] = i;
        valor += precios[i][k];
        frecsSuper[i]++;
        if (frecsSuper[i] <= 3) {
            //solucion
            if (k == n-1) {
                //mejor SOl
                if (valor < mejorValor) {
                    mejorValor = valor;
                }
            }
            else {

                if((valor+poda[k+1]) < mejorValor)
                    resolver(soluc, k +1, n, m, precios, frecsSuper, valor, mejorValor,poda);
            }
        }
        frecsSuper[i]--;
        valor -= precios[i][k];
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
    // leer los datos de la entrada
    int n, m, mejorGasto;
    cin >> m >> n;
    vector<vector<int>> precios(m,vector<int>(n));
    // Lectura de datos

    mejorGasto = INT_MAX;
    vector<int> minimizacion(n,INT_MAX);

    for (int i = 0; i< m; i++)
        for (int j = 0; j < n; j++) {
            cin >> precios[i][j];
            if (precios[i][j] < minimizacion[j]) {
                minimizacion[j] = precios[i][j];
            }
        }

    for (int i = minimizacion.size() - 2; i >= 0; i--)
        minimizacion[i] += minimizacion[i + 1];

    vector<int>soluc(n);
    vector<int>frecsSuper(m);

    resolver(soluc,0,n,m,precios,frecsSuper,0,mejorGasto,minimizacion);
    cout << mejorGasto << endl;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif
    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}
