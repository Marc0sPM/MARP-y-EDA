// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
using namespace std;


template <class T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    for (auto e : v) out << e;
    return out;
}

// función que resuelve el problema
void resolver(int k, int n, int m, vector<char>& cadena,vector<bool>&frecs) {
    for (char c = 'a'; c<'a' +m; c++) {
        cadena[k] = c;
        //valido
		if (!frecs[c - 'a']) {
            //solucion
            if (k == n-1) {
                cout << cadena<<endl;
            }
            else
            {
                frecs[c - 'a'] = true;
                resolver(k + 1, n, m, cadena,frecs);
                frecs[c - 'a'] = false;
            }
        }
    }
    
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    int n, m;
    // leer los datos de la entrada
    cin >> m;
    if (!cin)
        return false;

    cin >> n;

    vector<bool> frecs(27);
    vector<char> cad(n);
    resolver(0,n,m,cad,frecs);
    
    // escribir sol
    cout << endl;
    
    return true;
    
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
    #ifndef DOMJUDGE
     std::ifstream in("datos.txt");
     auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
     #endif 
    
    
    while (resuelveCaso())
        ;

    
    // Para restablecer entrada. Comentar para acepta el reto
     #ifndef DOMJUDGE // para dejar todo como estaba al principio
     std::cin.rdbuf(cinbuf);
     system("PAUSE");
     #endif
    
    return 0;
}