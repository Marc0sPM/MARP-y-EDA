
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

template <class T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    for (auto e : v) out << e;
    return out;
}

bool esValido(vector<int>& sol, int consMax, vector<int> totalesPorColor,int k, int color, int consumoTotal) {
    //si hay mas de dos colores repetidos
    bool coloresRepetidos = k > 1 && sol[k] == sol[k - 1] && sol[k - 1] == sol[k - 2];
    int acum = 0;
    int i = 0;
    while (i < totalesPorColor.size() && totalesPorColor[color] > acum + 1)
    {
        if(i != color) 
            acum += totalesPorColor[i];
        i++;
    }
    return consumoTotal <= consMax && !coloresRepetidos && totalesPorColor[color] <= acum +1;
}

void resolver(vector<int>& sol, int k, int n, int m,int consumMax, 
    vector<int> totalesPorColor, vector<int> consumosPorColor, int& numCombinaciones, int consumTotal) {
    for (int i = 0; i < m; i++) {
        sol[k] = i;
        totalesPorColor[i]++;
        consumTotal += consumosPorColor[i];
        //validez
        if (esValido(sol,consumMax,totalesPorColor, k, i,consumTotal)) {
            //solucion
            if (k == n -1) {
                numCombinaciones++;
                //cout << sol<<endl;
            }
            else {
                resolver(sol, k + 1, n, m,consumMax,totalesPorColor,consumosPorColor,numCombinaciones,consumTotal);
            }
        }
        totalesPorColor[i]--;
        consumTotal -= consumosPorColor[i] ;
    }
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n, m, consumoMax;
    int combinaciones = 0;
    cin >> n;
    if (n == 0) return false;
    cin >> m >> consumoMax;
    vector<int> consumosPorColor(m);
    for (int& e : consumosPorColor) cin >> e;
    vector<int> soluc(n);
    int k = 0;
    vector<int> totalesPorColor(m,0);
    int numSol = 0;
    int consumTotal = 0;
    resolver(soluc, k, n, m,consumoMax,totalesPorColor,consumosPorColor,numSol,0);
    // Salida
    cout << numSol<<endl;
    return true;
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}