// Plantilla para el ejercicio del Consultorio Médico

#include <iomanip>
#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>
#include <cassert>
#include <unordered_map>
#include <map>
using namespace std;

using medico = string;
using paciente = string;

class fecha {
private:
public:
    int dia, hora, minuto;
    fecha(int d, int h, int m) : dia(d), hora(h), minuto(m){};

    //inline int dia() { return dia; }

    


};

bool operator< (const fecha& main, const fecha& other) {
    return (main.dia < other.dia) ||
        ((main.dia == other.dia) && (main.hora < other.hora)) ||
        ((main.dia == other.dia) && (main.hora == other.hora) && (main.minuto < other.minuto));
}

ostream& operator<<(ostream& os, const fecha& dt)
{
    os << dt.hora << ':' << dt.minuto;
    return os;
}

class Consultorio{
private:
    //using cita = pair<fecha, paciente>;
    unordered_map<medico, map<int,map<fecha,paciente>>> medicos;

public:
    void nuevoMedico(medico med){
        medicos[med];
    }
    void pideConsulta(paciente pac, medico med, fecha f) {
        if (medicos.count(med) == 0)
            throw invalid_argument("Medico no existente");

        if (medicos[med].count(f.dia) > 0 && medicos[med][f.dia].count(f) > 0)
            throw invalid_argument("Fecha ocupada");

        medicos[med][f.dia][f] = pac;
    }
    string siguientePaciente(medico med) {
        if (medicos.count(med) == 0)
            throw invalid_argument("Medico no existente");

        if (medicos[med].empty())
            throw invalid_argument("No hay Pacientes");

        return (* (*medicos[med].begin()).second.begin()).second;
    }
    void atiendeConsulta(medico med) {
        if (medicos.count(med) == 0)
            throw invalid_argument("Medico no existente");
        if (medicos[med].empty())
            throw invalid_argument("No hay Pacientes");
        (*medicos[med].begin()).second.erase((*medicos[med].begin()).second.begin());
        if ((*medicos[med].begin()).second.empty())
            medicos[med].erase(medicos[med].begin());

    }
    map<fecha,paciente> listaPacientes(medico med, fecha dia) {
        return medicos[med][dia.dia];
    }
};


int casos = 0;
bool resuelve() {

    int N;
    cin >> N;
    if (!cin) return false;

    string inst; medico med; paciente pac; int d, h, m; char c;
    Consultorio con;

    for (int i = 0; i < N; ++i) {
        try {
            cin >> inst;
            if (inst == "nuevoMedico") {
                cin >> med;
                con.nuevoMedico(med);
            }
            else if (inst == "pideConsulta") {
                cin >> pac >> med >> d >> h >> c >> m;
                con.pideConsulta(pac, med, fecha(d, h, m));
            }
            else if (inst == "siguientePaciente") {
                cin >> med;
                pac = con.siguientePaciente(med);
                cout << "Siguiente paciente doctor " << med << '\n';
                cout << pac << '\n';
            }
            else if (inst == "atiendeConsulta") {
                cin >> med;
                con.atiendeConsulta(med);
            }
            else if (inst == "listaPacientes") {
                cin >> med >> d;
                auto vec = con.listaPacientes(med, fecha(d, 0, 0));
                cout << "Doctor " << med << " dia " << d << '\n';
                for (auto p : vec) {
                    cout << p.second << ' ' << p.first << '\n';
                }
            }
            else
                assert(false);
        }
        catch (invalid_argument e) { cout << e.what() << '\n'; }
    }
    cout << "---\n";

    return true;
}

int main() {
    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
   // _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelve());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    //system("pause");
#endif
    return 0;
}
