// ExamenEnero23-Ej2.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include <fstream>
#include "bintree_eda.h"
#include <climits>


using namespace std;
//devuelve el nuemro de nodo
int resolver(bintree<int> a, int& numDragones) {
    if (a.empty()) {
        numDragones = INT_MAX;
        return -1;
    }

    if (a.root() > 2) {
        return a.root();
    }
    else {
        if (a.root() == 1) {
            numDragones++;
        }

        int numDr = 0;
        int numIz = 0;

        int left = resolver(a.left(), numIz);
        int right = resolver(a.right(), numDr);

        int res;

        if (numIz <= numDr) {
            res = left;
            numDragones += numIz;
        }
        else {
            res = right;
            numDragones += numDr;
        }

        return res;
    }
}



// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
    bintree<int> arb;
    arb = leerArbol(-1); // -1 es la repr. de arbol vacio
    int navegables = 0;
    cout << resolver(arb, navegables) << endl;
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}