// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <climits>

using namespace std;


/*
la tupla solucion es un vector que indica cuantas monedas de cada tipo hay en la solucion
*/
// función que resuelve el problema
void resolver(vector<int>& sol, int k,int valorPedido, int valorAcum,
    vector<int>const& cantidadMon, vector<int> const& valoresMonedas,
    int& numMonedas, int& maxMonedas) {

    for (int i = 0; i <= cantidadMon[k]; i++) {
        sol[k] = i;
        valorAcum += valoresMonedas[k] * i;
        numMonedas += i;
        if (valorAcum <= valorPedido) {//validez
            if (valorAcum == valorPedido) {//sol?
                if (numMonedas > maxMonedas) {//mejor
                    maxMonedas = numMonedas;
                }
            }
            else if(k < cantidadMon.size()-1) {
                if (valoresMonedas[k+1] <= valorPedido-valorAcum) {
                    resolver(sol, k + 1, valorPedido, valorAcum, cantidadMon, valoresMonedas, numMonedas, maxMonedas);
                }
            }
        }
        valorAcum -= valoresMonedas[k]*i;
        numMonedas -= i;
    }

}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
    // leer los datos de la entrada
    int valor;
    cin >> valor;
    vector<int> cantidadMonedas(8);
    for (int& e : cantidadMonedas)
        cin >> e;

    vector<int> valoresMonedas = { 1,2,5,10,20,50,100,200};



    vector<int> sol(8);
    int numMonedas = 0;
    int maxMonedas = INT_MIN;
    int acum = 0;

    resolver(sol, 0,valor,acum,cantidadMonedas,valoresMonedas,numMonedas,maxMonedas);


    // escribir sol
    if (maxMonedas == INT_MIN)
        cout << "IMPOSIBLE" << endl;
    else
        cout << maxMonedas << endl;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}