// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>


using namespace std;

// función que resuelve el problema
void resolver(vector<int>& datos, int& ini, int& fin, int tam) {
	size_t i = 0;

	while (i < datos.size() && ini == -1) {
		if (datos[i] > tam && datos[i+1] > tam)
			ini = i;
		i++;
	}
	while (i < datos.size() && fin == -1) {
		if (datos[i] < tam && ini != -1) {
			fin = i - 1;
		}
		i++;
	}
	if (fin == -1 && ini != -1) {
		fin = datos.size() - 1;
	}

}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
	int ini = -1;
	int fin = -1;
	int nEdificios;
	int altura;
	int entry;
	vector<int> datos;
	// leer los datos de la entrada
	cin >> nEdificios;
	cin >> altura;
	for (int i = 0; i < nEdificios; i++) {
		cin >> entry;
		datos.push_back(entry);
	}

	resolver(datos, ini, fin, altura);

	cout << ini << " " << fin << endl;

}

int main() {
	// Para la entrada por fichero.
	// Comentar para acepta el reto
#ifndef DOMJUDGE
	std::ifstream in("datos.txt");
	auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


	int numCasos;
	std::cin >> numCasos;
	for (int i = 0; i < numCasos; ++i)
		resuelveCaso();


	// Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
	std::cin.rdbuf(cinbuf);
	system("PAUSE");
#endif

	return 0;
}