// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include<string>

using namespace std;
// función que resuelve el problema
/*Preconcicion: entra el array de los valores de altura de los hermanos
Postcondicion: devuelve un string con la respuesta a la pregunta
Invariante: ???
Funcion de cota ???*/
string resolver(const int valores[],int num) {
    string respuesta;
    int i = 1;
    int j = num - 1;
    while (i<num && valores[i]> valores[i - 1]) {
        i++;
    }
    while (j>0 && valores[j] < valores[j - 1]) {
        j--;
    }
    
    respuesta = i == num || j == 0 ? "DALTON" : "DESCONOCIDOS";

    return respuesta;
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int num;
    cin >> num;
    if (num ==0)
        return false;
    int* valores = new int[num];
    for (int i = 0; i < num; i++) {
        cin >> valores[i];
    }

    // escribir sol
    cout << resolver(valores, num) << "\n";


    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}