#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


bool anagramas(const string& cad1, const string& cad2) {
    int letras[27];
    for (size_t i = 0; i < 27; i++)
    {
        letras[i] = 0;
    }
    for (int i = 0; i < cad1.size(); i++) {
        letras[(cad1[i]-'a')]++;
    }
    for (int i = 0; i < cad1.size(); i++) {
        letras[(cad2[i] - 'a')]--;
    }
    int i = 0;
    while (i < 27 && letras[i] == 0)
        i++;

    return i == 27;

}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
void resuelveCaso() {
    // leer los datos de la entrada
    string word1, word2;
    cin >> word1 >> word2;
    cout << (anagramas(word1, word2) ? "SI" : "NO") << endl;
}

//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}