#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;

// función que resuelve el problema
int resolver(const vector<int>& sec, int ini, int fin) {
    int n = fin - ini;
    int m = (ini + fin) / 2;

    if (n == 1) {
        return sec[ini];
    }
    if (n == 2) {
        return sec[ini] % 2 == 0 ? sec[fin - 1] : sec[ini];
    }
    else {
        if (sec[ini] % 2 != 0) return sec[ini];
        if (sec[m - 1] % 2 != 0) return sec[m - 1];
        //izquierda
        if (sec[ini] + 2 * (m-ini -1) != sec[m-1]) {
            return resolver(sec, ini, m);
        }
        else {
            return resolver(sec, m, fin);
        }
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int n;
    cin >> n;
    if (n == 0) return false;
    vector<int> sec(n);
    for (int& e : sec) cin >> e;
    cout << resolver(sec, 0, n) << endl;
    return true;
}
//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}