// Nombre del alumno .....
// Usuario del Juez ......


#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>

using namespace std;

bool buscarElemVectorRotado(const vector<int>& v, int k, int ini, int fin) {

    if (fin - ini == 1) {
        return v[ini] == k;
    }

    int mid = (ini + fin) / 2;

    if (v[ini] == k || v[mid] == k || v[fin - 1] == k) return true;

    if (v[mid] < v[fin - 1]) {
        if (k < v[mid] || k > v[fin - 1]) {
            return buscarElemVectorRotado(v, k, ini, mid);
        }
        else if (k < v[fin - 1]) {
            return buscarElemVectorRotado(v, k, mid, fin);
        }
    }
    else {
        if (k > v[mid] || k < v[fin - 1]) {
            return buscarElemVectorRotado(v, k, mid, fin);
        }
        else if (k > v[fin - 1]) {
            return buscarElemVectorRotado(v, k, ini, mid);
        }
    }

}

bool buscarElemVectorRotado(const vector<int>& v, int k) {

    return buscarElemVectorRotado(v, k, 0, v.size());
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada

    int nElem;
    cin >> nElem;

    if (nElem == -1) return false;

    int k;
    cin >> k;

    vector<int> sec;
    for (int i = 0; i < nElem; i++) {
        int elem;
        cin >> elem;
        sec.push_back(elem);
    }

    cout << (buscarElemVectorRotado(sec, k) ? "SI" : "NO") << endl;
    return true;

}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif 


    while (resuelveCaso())
        ;


    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}