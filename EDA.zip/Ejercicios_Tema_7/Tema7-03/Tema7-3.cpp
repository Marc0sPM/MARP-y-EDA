#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

using namespace std;
//indice , ultimo dia emitido
using Diccionario = unordered_map<int, int>;

int resuelve(vector<int>& valores) {
    Diccionario map;
    int ultimoDia = 0; //en el que se repitio un cap
    int racha = 0;
    int episodiosMax = 0;
    for (int i = 0; i < valores.size(); i++) {
        if (map.count(valores[i]) > 0 && ultimoDia <= map[valores[i]]) {
            ultimoDia = map[valores[i]] + 1;
        }

        racha = (i - ultimoDia) + 1;

        map[valores[i]] = i;

        if (racha > episodiosMax) {
            episodiosMax = racha;
        }
        
    }
    return episodiosMax;
}


void resuelveCaso() {

    int n;
    int aux;
    cin >> n;

    vector<int> valores;

    for (int i = 0; i < n; i++) {
        cin >> aux;
        valores.push_back(aux);
    }

    cout << resuelve(valores) << endl;
}


int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    int numCasos;
    std::cin >> numCasos;
    for (int i = 0; i < numCasos; ++i)
        resuelveCaso();

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    //system("PAUSE");
#endif

    return 0;
}