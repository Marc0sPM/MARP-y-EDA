#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <climits>
using namespace std;


using Pelicula = string;
using Actor = string;
using RepartosPeliculas = unordered_map < Pelicula, vector<pair<Actor,int>>>;
using MinutosActores = unordered_map<Actor, int>;

//complejidad lineal respecto del numero de acotores por pelicula
void leerRepartos(int numPeliculas, RepartosPeliculas& peliculas) {
    Pelicula peli; int numActores;
    Actor actor; int minutos;
    for (int i = 0; i < numPeliculas; ++i) {
        cin >> peli; cin >> numActores;
        //...
            for (int j = 0; j < numActores; ++j) {
                cin >> actor >> minutos;
                peliculas[peli].push_back({ actor,minutos });
            }
    }
}


void procesarEmisiones(RepartosPeliculas const& repartos, vector<string> const& secEmisiones, MinutosActores& actores) {
    unordered_map<Pelicula,int> peliEmision;
    string masEmitida;
    for (string emi : secEmisiones) {
        peliEmision[emi]++;
        if (peliEmision[emi] >= peliEmision[masEmitida])  masEmitida = emi;
    }
    cout << peliEmision[masEmitida] << " " << masEmitida << endl;
    //determinar actor mas visto
    int maxMins = INT_MIN;
    for (auto peli : repartos) {
        //si la pelicula ha sido emitida
        if (peliEmision[peli.first] > 0) {
            for (auto act : peli.second) {
                actores[act.first] += peliEmision[peli.first] * act.second;
                if (actores[act.first] > maxMins) maxMins = actores[act.first];
            }
        }
    }

    vector<string> salida;
    for (auto act : actores) {
        if (act.second == maxMins) salida.push_back(act.first);
    }

    sort(salida.begin(), salida.end());
    cout << maxMins << " ";
    for (auto act : salida) {
        cout << act << " ";
    }
    cout << endl;
}


// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    int numPelis, numEmisiones;
    cin >> numPelis;
    if (numPelis == 0)
        return false;

    // Lectura de los repartos de las peliculas
    RepartosPeliculas repartos;
    MinutosActores actores;
    leerRepartos(numPelis, repartos);

    // Lectura de la secuencia de peliculas emitidas en vector<string>
    cin >> numEmisiones;
    vector<string> secEmisiones(numEmisiones);
    for (string& s : secEmisiones) cin >> s;

    procesarEmisiones(repartos, secEmisiones, actores);

    return true;
}


//#define DOMJUDGE
int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("input3.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
#endif

    return 0;
}