#include <iostream>
#include <fstream>
#include <cctype>
#include <unordered_map>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

bool menorDepor(pair<string, int> a, pair<string, int> b) {
    return (a.second > b.second) || ((a.second == b.second) && a.first < b.first);
}

void resolver(string const& primerDeporte, unordered_map<string, string>& alumnoDepor, unordered_map<string,int>& deportes) {
    string deporte, alumno;
    deporte = primerDeporte;
    while (deporte != "_FIN_") {
        deportes[deporte] = 0;
            cin >> alumno;

        while (!isupper(alumno[0]) && alumno != "_FIN_") {
            if (alumnoDepor.count(alumno) > 0 && alumnoDepor[alumno] != deporte) {
                alumnoDepor[alumno] = " ";
            }
            else {
                alumnoDepor[alumno] = deporte;
            }
            cin >> alumno;
        }
        deporte = alumno;
    }
}

// Resuelve un caso de prueba, leyendo de la entrada la
// configuración, y escribiendo la respuesta
bool resuelveCaso() {
    // leer los datos de la entrada
    string primerDeporte;
    cin >> primerDeporte;
    if (!cin) return false;
    unordered_map<string, int> deportes;
    unordered_map<string, string> alumnos;
    resolver(primerDeporte, alumnos,deportes);

    for (auto alum : alumnos) {
        if (alum.second != " ") {
            deportes[alum.second]++;
        }
    }
    vector<pair<string, int>> aux;
    for (auto e : deportes) {
        aux.push_back(e);
    }

    sort(aux.begin(),aux.end(), menorDepor);

    for (auto e : aux) {
        cout << e.first << " " << e.second<<endl;
    }

    cout << "---\n";
    return true;
}

int main() {
    // Para la entrada por fichero.
    // Comentar para acepta el reto
#ifndef DOMJUDGE
    std::ifstream in("datos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf()); //save old buf and redirect std::cin to casos.txt
#endif

    while (resuelveCaso())
        ;

    // Para restablecer entrada. Comentar para acepta el reto
#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
#endif

    return 0;
}