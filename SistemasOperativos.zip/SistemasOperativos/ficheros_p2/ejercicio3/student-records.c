#include <stdio.h>
#include <unistd.h> /* for getopt() */
#include <stdlib.h> /* for EXIT_SUCCESS, EXIT_FAILURE */
#include <string.h>
#include "defs.h"


/* Assume lines in the text file are no larger than 100 chars */
#define MAXLEN_LINE_FILE 100

char* loadstr(FILE *file)
{
	char c;
	int seguir = 1;
	int contador = 0;

	while(seguir) {
		fread(&c, sizeof(char), 1, file);
		contador++;
		if(c == '\0') seguir = 0;
	}

	char* tmp = malloc(sizeof(char) * contador);
	fseek(file, -contador, SEEK_CUR);
	fread(tmp, sizeof(char), contador, file);
	
	if(*tmp == NULL) return NULL;
	return tmp;
}

int print_text_file(char *path)
{
	FILE* file;
	int lineas = 0;
	char* token;
	int tokenId = 0;
	int contador = 0;
	char linea[MAXLEN_LINE_FILE + 1];
	char* lineaPtr;

	if((file = fopen(path, "r")) == NULL) {
		fprintf(stderr, "%s could not be opened: ", path);
		perror(NULL);
		return EXIT_FAILURE;
	}

	//Vamos a saltarnos el primer número de momento

	fgets(linea, MAXLEN_LINE_FILE + 1, file);

	while(fgets(linea, MAXLEN_LINE_FILE + 1, file) != NULL) { //Usamos la pr
		lineaPtr = linea;
		
		tokenId = 0;
		printf("[Entry #%i]\n", contador);
		++contador;
		
		while((token = strsep(&lineaPtr, ":")) != NULL) { //Guardamos en token los diferentes campos de cada persona, que están separados por ":"
			switch(tokenId) {
				case 0:
					printf("\tstudent_id=%s\n", token);
				break;
				case 1:
					printf("\tNIF=%s\n", token);
				break;
				case 2:
					printf("\tfirst_name=%s\n", token);
				break;
				case 3:
					printf("\tlast_name=%s\n", token);
				break;
				default:
				break;
			}
			tokenId++;
		}
	}

	fclose(file);
	return EXIT_SUCCESS;
}

int print_binary_file(char *path)
{
	FILE* file;
	if((file = fopen(path, "rb")) == NULL) {
		fprintf(stderr, "%s could not be opened: ", path);
		perror(NULL);
		return EXIT_FAILURE;
	}

	int numBuffer;
	fread(&numBuffer, sizeof(int), 1, file);
	
	student_t* st = (malloc(sizeof(student_t)));
	char* tmp;
	for(int i = 0; i < numBuffer; ++i) {
		printf("[Entry #%i]\n", i);
		fread(&st->student_id, sizeof(int), 1, file);
		printf("\tstudent_id=%i\n", st->student_id);
		tmp = loadstr(file);
		strcpy(st->NIF, tmp);
		free(tmp);
		printf("\tNIF=%s\n", st->NIF);
		tmp = loadstr(file);
		st->first_name = tmp;
		printf("\tfirst_name=%s\n", st->first_name);
		free(tmp);
		tmp = loadstr(file);
		st->last_name = tmp;
		printf("\tlast_name=%s\n",st->last_name);
		free(tmp);
	}
	
	free(st);
	fclose(file);
	return 0;
}


int write_binary_file(char *input_file, char *output_file)
{
	FILE* inpFile;
	FILE* outFile;

	int lineas = 0;
	char* token;
	int tokenId = 0;
	int contador = 0;
	char linea[MAXLEN_LINE_FILE + 1];
	char* lineaPtr;
	student_t* students;

	if((inpFile = fopen(input_file, "r")) == NULL) {
		fprintf(stderr, "%s could not be opened: ", input_file);
		perror(NULL);
		return EXIT_FAILURE;
	}

	if((outFile = fopen(output_file, "w")) == NULL) {
		fprintf(stderr, "%s could not be opened or created: ", output_file);
		perror(NULL);
		return EXIT_FAILURE;
	}

	fgets(linea, MAXLEN_LINE_FILE + 1, inpFile); //Cogemos el número de estudiantes
	int tamArray = atoi(linea); 
	fwrite(&tamArray, sizeof(int), 1, outFile);

	students = malloc(sizeof(student_t) * tamArray); //Creamos un array de estudiantes
	while(fgets(linea, MAXLEN_LINE_FILE + 1, inpFile) != NULL) {
		lineaPtr = linea;
		
		tokenId = 0;
		
		while((token = strsep(&lineaPtr, ":")) != NULL) {
			switch(tokenId) {
				case 0:;
					int tmp = atoi(token);
					fwrite(&tmp, sizeof(int), 1, outFile);
				break;
				case 1:
					fwrite(token, sizeof(char), strlen(token) + 1, outFile);
				break;
				case 2:
					fwrite(token, sizeof(char), strlen(token) + 1, outFile);
				break;
				case 3:
					fwrite(token, sizeof(char), strlen(token) + 1, outFile);
				break;
				default:
				break;
			}
			tokenId++;
		}
		++contador;
	}

	//fwrite(students, sizeof(student_t), tamArray, outFile);

	free(students);
	fclose(inpFile);
	fclose(outFile);
	return EXIT_SUCCESS;
}

int main(int argc, char *argv[])
{
	int ret_code, opt;
	struct options options;

	/* Initialize default values for options */
	options.input_file = NULL;
	options.output_file = NULL;
	options.action = NONE_ACT;
	ret_code = 0;

	/* Parse command-line options (incomplete code!) */
	while ((opt = getopt(argc, argv, "hi:po:b")) != -1) {
		switch (opt) {
		case 'h':
			fprintf(stderr, "Usage: %s [ -h | -p | -i <input_file> | -o <output_file> | -b]\n", argv[0]);
			exit(EXIT_SUCCESS);
		case 'i':
			options.input_file = optarg;
			break;
		case 'p':
			options.action = PRINT_TEXT_ACT;
			break;
		case 'o':
			options.output_file = optarg;
			options.action = WRITE_BINARY_ACT;
			break;
		case 'b':
			options.action = PRINT_BINARY_ACT;
			break;
		default:
			exit(EXIT_FAILURE);
		}
	}

	if (options.input_file == NULL)
	{
		fprintf(stderr, "Must specify one record file as an argument of -i\n");
		exit(EXIT_FAILURE);
	}

	switch (options.action)
	{
	case NONE_ACT:
		fprintf(stderr, "Must indicate one of the following options: -p, -o, -b \n");
		ret_code = EXIT_FAILURE;
		break;
	case PRINT_TEXT_ACT:
		/* Part A */
		ret_code = print_text_file(options.input_file);
		break;
	case WRITE_BINARY_ACT:
		/* Part B */
		ret_code = write_binary_file(options.input_file, options.output_file);
		break;
	case PRINT_BINARY_ACT:
		/* Part C */
		ret_code = print_binary_file(options.input_file);
		break;
	default:
		break;
	}
	exit(ret_code);
}
