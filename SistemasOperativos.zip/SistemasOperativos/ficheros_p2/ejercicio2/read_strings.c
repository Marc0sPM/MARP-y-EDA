#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>

/** Loads a string from a file.
 *
 * file: pointer to the FILE descriptor
 *
 * The loadstr() function must allocate memory from the heap to store
 * the contents of the string read from the FILE.
 * Once the string has been properly built in memory, the function returns
 * the starting address of the string (pointer returned by malloc())
 *
 * Returns: !=NULL if success, NULL if error
 */

char* loadstr(FILE *file)
{
	char c;
	int seguir = 1;
	int contador = 0;

	while(seguir) {
		fread(&c, sizeof(char), 1, file);
		contador++;
		if(c == '\0') seguir = 0;
	}

	char* tmp = malloc(sizeof(char) * contador);
	fseek(file, -contador, SEEK_CUR);
	fread(tmp, sizeof(char), contador, file);
	
	if(*tmp == NULL) return NULL;
	return tmp;
}

int main(int argc, char *argv[])
{
	FILE* file = NULL;
	if(argc < 2) {
		fprintf(stderr,"Usage: %s <file_name>\n",argv[0]);
		exit(1);
	}

	if((file = fopen(argv[1], "r")) == NULL) err(2, "The input file %s could not be opened", argv[1]);

	char* cadena;
	while((cadena = loadstr(file)) != NULL) {
		fwrite(cadena, sizeof(char), strlen(cadena), stdout);
		*cadena = '\n';
		fwrite(cadena, sizeof(char), 1, stdout);
	}

	free(cadena);
	fclose(file);

	return 0;
}
