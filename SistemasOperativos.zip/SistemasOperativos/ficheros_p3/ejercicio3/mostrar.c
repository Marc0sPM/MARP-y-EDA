#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>


int main(int argc, char *argv[])
{
	int N = 0, opt;
	int jumpBytes = 0;

	if(argc < 2) {
		fprintf(stderr, "File name was not given. Aborting.\n");
		exit(EXIT_FAILURE);
	}

	char* dirname = argv[1];
	while ((opt = getopt(argc, argv, "hn:e")) != -1) {
		switch (opt) {
		case 'h':
			fprintf(stderr, "Usage: %s [ -n | -e ]\n", argv[0]);
			exit(EXIT_SUCCESS);
		case 'n': {
			N = atoi(optarg);
		} break;
		case 'e': {
			jumpBytes = 1;
		} break;
		default:
			exit(EXIT_FAILURE);
		}
	}

	int fd = open(dirname, O_RDONLY);

	int fileSize = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);

	if(!jumpBytes) {
		lseek(fd, N, SEEK_SET);
		fileSize -= N;
	}
	else {
		lseek(fd, -N, SEEK_END);
		fileSize = N;
	}

	char* buf = malloc(sizeof(char) * fileSize);
	
	read(fd, buf, fileSize);
	write(STDOUT_FILENO, buf, fileSize);

	free(buf);
	close(fd);
	return 0;
}
