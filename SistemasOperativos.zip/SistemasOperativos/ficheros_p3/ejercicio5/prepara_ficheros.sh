#!/bin/bash

# $0 es el nombre del programa -> argv[0]
# $1 es el primer argumento que le pasamos al programa -> argv[1]
# así sucesivamente...

if [ $# -lt 1 ]
then
    echo "Usage: $0 <DIRNAME>"
    exit 1
fi

NOMBRE_DIR=$1

if [ -d $NOMBRE_DIR ]
then
    rm -rf $NOMBRE_DIR/*
else
    mkdir $NOMBRE_DIR
fi

exit 0