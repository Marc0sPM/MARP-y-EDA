#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>

/* Forward declaration */
int get_size_dir(char *fname, size_t *blocks);

/* Gets in the blocks buffer the size of file fname using lstat. If fname is a
 * directory get_size_dir is called to add the size of its contents.
 */
int get_size(char *fname, size_t *blocks)
{
	struct stat s;
	lstat(fname, &s);
	if(S_ISDIR(s.st_mode)) get_size_dir(fname, blocks);
	else {
		blocks = s.st_size;
	}
}


/* Gets the total number of blocks occupied by all the files in a directory. If
 * a contained file is a directory a recursive call to get_size_dir is
 * performed. Entries . and .. are conveniently ignored.
 */
int get_size_dir(char *dname, size_t *blocks)
{
	DIR* d = opendir(dname);
	struct dirent* tmp;
	unsigned short len;

	while((tmp = readdir(d)) != NULL) {
		if(tmp->d_type == DT_DIR && strcmp(".", tmp->d_name) && strcmp("..", tmp->d_name)) len += get_size_dir(tmp->d_name, blocks);
		else if(tmp->d_type == DT_REG);
	}

	printf("%i", len);



	closedir(d);
}

/* Processes all the files in the command line calling get_size on them to
 * obtain the number of 512 B blocks they occupy and prints the total size in
 * kilobytes on the standard output
 */
int main(int argc, char *argv[])
{
	size_t* blocks;
	for(int i = 0; i < argc - 1; ++i) {
		get_size(argv[i + 1], blocks);
		printf("%iK \t%s\n", *blocks, argv[i+1]);
	}

	return 0;
}
