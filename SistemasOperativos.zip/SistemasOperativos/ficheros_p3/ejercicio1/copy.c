#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

void copy(int fdo, int fdd) {
	int tam = lseek(fdo, 0, SEEK_END);
	lseek(fdo, 0, SEEK_SET);
	char* c[512];
	int i = 0;
	if(tam < 512) {
		read(fdo, c, tam);
		write(fdd, c, tam);
	}
	else {
		while(i <= tam && tam - i >= 512) {
			read(fdo, c, 512);
			write(fdd, c, 512);
			i += 512;
		}
		if(i - tam != 0) {
			read(fdo, c, abs(tam - i));
			write(fdd, c, abs(tam - i));
		}
	}
	
	/*int tam = lseek(fdo, 0, SEEK_END);
	lseek(fdo, 0, SEEK_SET);
	const int tamBloque = 512;
	char bloque[tamBloque];
	int numBytes = 0;
	while((numBytes = read(fdo, bloque, tamBloque)) != 0) {
		if(write(fdd, bloque, numBytes) == -1) return;
	}
	int lastOffset = tam % 512;
	lseek(fdd, -lastOffset, SEEK_CUR);
	write(fdd, bloque, lastOffset);*/
}

int main(int argc, char *argv[])
{
	if(argc < 3) {
		fprintf(stderr,"Usage: %s <file_name 1> <file_name 2>\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	
	int origin, destiny;

	origin = open(argv[1], O_RDONLY);

	if(origin == -1) {
		fprintf(stderr,"File %s was not found",argv[1]);
		exit(EXIT_FAILURE);
	}

	destiny = open(argv[2], O_CREAT | O_TRUNC | O_WRONLY, S_IRUSR | S_IWUSR);

	copy(origin, destiny);

	close(destiny);
	close(origin);

	return 0;
}
