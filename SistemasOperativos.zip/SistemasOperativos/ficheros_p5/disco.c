#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define CAPACITY 5
#define VIPSTR(vip) ((vip) ? "  vip  " : "not vip")

int num_clients = 0; //Número total de clientes que hay que crear
int nturn = 0; //Turno para los clientes normales
int nticket = 0; //Ticket para los clientes normales
int vturn = 0; //Turno para los clientes vip
int vticket = 0; //Ticket para los clientes vip
int vip_waiting = 0;
int clients_inside = 0;
pthread_mutex_t m;
pthread_cond_t empty;

typedef struct {
	int id;
	int isvip;
} client_arg_t;

void enter_normal_client(int id)
{
	int miturno;
	pthread_mutex_lock(&m);
	miturno = nticket++;
	while(miturno != nturn || clients_inside == CAPACITY || vip_waiting) pthread_cond_wait(&empty, &m);
	clients_inside++;
	nturn++;
	pthread_cond_broadcast(&empty);
	pthread_mutex_unlock(&m);
}

void enter_vip_client(int id)
{
	int miturno;
	pthread_mutex_lock(&m);
	vip_waiting++;
	miturno = vticket++;
	while(miturno != vturn ||  clients_inside == CAPACITY) pthread_cond_wait(&empty, &m);
	clients_inside++;
	vip_waiting--;
	vturn++;
	pthread_cond_broadcast(&empty);
	pthread_mutex_unlock(&m);
}

void dance(int id, int isvip)
{
	printf("Client %2d (%s) dancing in disco, vips waiting: %d\n", id, VIPSTR(isvip), vip_waiting);
	sleep((rand() % 3) + 1);
}

void disco_exit(int id, int isvip)
{
	pthread_mutex_lock(&m);
	clients_inside--;
	pthread_cond_broadcast(&empty);
	pthread_mutex_unlock(&m);
}

void *client(void *arg)
{
	client_arg_t* args = (client_arg_t*) arg;

	if(args->isvip) enter_vip_client(args->id);
	else enter_normal_client(args->id);

	dance(args->id, args->isvip);
	disco_exit(args->id, args->isvip);

	free(args);

	pthread_exit(0);
}

int main(int argc, char *argv[])
{
	if(argc < 2){
		fprintf(stderr, "Se debe introducir un archivo\n");
		exit(EXIT_FAILURE);
	}
	FILE* file = fopen(argv[1], "r");
	pthread_mutex_init(&m, NULL);
	pthread_cond_init(&empty, NULL);
	pthread_t *tid;
	int num;
	if(fscanf(file, "%d\n", &num) == 0 ){
		fprintf(stderr, "Formato incorrecto. Abortando.\n");
		exit(EXIT_FAILURE);
	}

	tid = malloc(num * sizeof(pthread_t));

	for(int i = 0; i < num; ++i) {
		client_arg_t* tmp = malloc(sizeof(client_arg_t));
		tmp->id = i;
		fscanf(file, "%d\n", &tmp->isvip);
		pthread_create(&tid[i],NULL, client, tmp);
	}
	fclose(file);

	for(int i = 0; i < num; ++i) {
		pthread_join(tid[i], NULL);
	}
	
	pthread_mutex_destroy(&m);
	pthread_cond_destroy(&empty);

	return 0;
}
