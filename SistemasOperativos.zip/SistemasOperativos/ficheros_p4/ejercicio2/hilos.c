#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#define NUM_HILOS 15

struct thread_info{
	int index;
	char priority;
};

void *thread_usuario(void *arg)
{
	struct thread_info *info = (struct thread_info *) arg;

	printf("Thread %d with pthread id %ld with priority %c\n", info->index, (long)pthread_self(), info->priority);

	free(info);
	
	pthread_exit(0);
}

int main(int argc, char* argv[])
{
	pthread_attr_t attr;
	pthread_t thid[NUM_HILOS];

	pthread_attr_init(&attr);
	for(int i = 0; i < NUM_HILOS; i++){
		struct thread_info* info = malloc(sizeof(int) + sizeof(char));
		info->index = i;
		if(i % 2 == 0) info->priority = 'P';
		else info->priority = 'N';
		pthread_create(&thid[i], &attr, thread_usuario, info);
		pthread_join(thid[i], NULL);
	}

	return 0;
}
