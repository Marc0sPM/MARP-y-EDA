#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

__pid_t i;

/*programa que temporiza la ejecución de un proceso hijo */
void sigalrm_handler(int signum){
	if(signum == SIGALRM) kill(i, 1);
}

int main(int argc, char **argv)
{
	if(argc < 2 ) return -1;

	i = fork();
	if(i == 0){
		char** args = argv + 1;
		execvp(argv[1],args);
	}
	else{
		alarm(5);
		struct sigaction s;
		s.sa_handler = sigalrm_handler;
		sigaction(SIGALRM, &s, NULL);
		signal(SIGINT, SIG_IGN);
		int status;
		wait(&status);
		if(WIFSIGNALED(status))
		{
			printf("I STOPPED THE PROCESS\n");
			WTERMSIG(status);
		}
	}

	return 0;
}
