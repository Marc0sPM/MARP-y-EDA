#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>

#define NUMITER 3

sem_t *q, *empty, *full;
int *buffer = NULL;
#define caldero (*buffer)

int getServingsFromPot(void)
{
	sem_wait(q);
	if (caldero == 0) {
		sem_post(empty);
		sem_wait(full);
	}
	caldero--;
	sem_post(q);
}

void eat(void)
{
	unsigned long id = (unsigned long) getpid();
	printf("Savage %lu eating\n", id);
	sleep(rand() % 5);
}

void savages(void)
{
	for(int i = 0; i < NUMITER; ++i) {
		getServingsFromPot();
		eat();
	}
}

int main(int argc, char *argv[])
{
	int fd = shm_open("/caldero", O_RDWR, 0);
	buffer = (int*) mmap(NULL, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0);
	q = sem_open("/queue", 0);
	empty = sem_open("/empty", 0);
	full = sem_open("/full", 0);

	savages();

	munmap(buffer, sizeof(int));
	sem_close(q);
	sem_close(empty);
	sem_close(full);

	return 0;
}
