#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <err.h>
#include <signal.h>

#define M 10

sem_t *q, *empty, *full;
int finish = 0;
int *buffer = NULL; //primero shm_open y luego mmap
#define caldero (*buffer)

void putServingsInPot(int servings)
{
	if(sem_wait(empty) == -1) return;
	caldero += M; //Caldero tiene que ser una región de memoria compartida entre el proceso cocinero y salvajes
	sem_post(full);
}

void cook(void)
{
	while(!finish) {
		putServingsInPot(M);
	}
}

void handler(int signo)
{
	finish = 1;
}

int main(int argc, char *argv[])
{
	struct sigaction act;
	sigset_t mask;
	sigfillset(&mask);
	act.sa_flags = 0;
	act.sa_mask = mask;
	act.sa_handler = handler;
	sigaction(SIGTERM, &act, NULL);
	sigaction(SIGINT, &act, NULL);

	int fd = shm_open("/caldero", O_CREAT|O_RDWR|O_EXCL, S_IRUSR | S_IWUSR);
	if(fd == -1) warn("Error at creating shared memory");
	ftruncate(fd, sizeof(int));
	buffer = (int*) mmap(NULL, sizeof(int), PROT_WRITE | PROT_READ, MAP_SHARED, fd, 0); //El primer NULL es para decirle al sistema que no quiero ubicarlo en una dirección específica
	if(buffer == MAP_FAILED) warn("Error at mmap");
	
	q = sem_open("/queue", O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	if(q == SEM_FAILED) {
		warn("Error at opening queue");
		goto queueStatement;
	}
	empty = sem_open("/empty", O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 0);
	if(empty == SEM_FAILED) {
		warn("Error at opening empty");
		goto emptyStatement;
	}
	full = sem_open("/full", O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 0);
	if(full == SEM_FAILED){
		warn("Error at opening full");
		goto fullStatement;
	}

	cook();

	munmap(buffer, sizeof(int));
	shm_unlink("/caldero");
	
	fullStatement: 
		sem_close(full);
		sem_unlink("/full");
	emptyStatement: 
		sem_close(empty);
		sem_unlink("/empty");
	queueStatement: 
		sem_close(q);
		sem_unlink("/queue");
	return 0;
}
