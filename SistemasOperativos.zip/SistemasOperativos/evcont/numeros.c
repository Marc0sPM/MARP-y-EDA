#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <err.h>
#include <signal.h>
#define TOTAL_HILOS 4

pthread_mutex_t m;
pthread_cond_t c;
int turno = 0;
int ticket = 0;
typedef struct {
    int id;
} hilo_t;

int main(int argc, char* argv[]) {
    pthread_mutex_init(&m, NULL);
    pthread_cond_init(&c, NULL);

    pthread_t* tid = malloc(TOTAL_HILOS * sizeof(pthread_t));

    for(int i = 0; i < TOTAL_HILOS; ++i) {
        hilo_t* hilo = malloc(sizeof(hilo_t));
        hilo->id = i+1;
        
    }

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&m);
}