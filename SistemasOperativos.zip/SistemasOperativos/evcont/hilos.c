#include <pthread.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#define MAX_THREADS 32

int fd = -1;

void* threadfun(void* args) {
    if(args == 0) {
        fd = open("data.txt", O_WRONLY | O_CREAT | O_TRUNC, 0751);
    }
    write(fd, "Hello\n", 6);
    return NULL;
}

int main(void) {
    int i = 0, n = 0;
    pid_t pid;
    pid_t start = getpid();
    pthread_t desc[MAX_THREADS];
    threadfun(0);

    for(i = 0; i < 3; i++) {
        n += 2;
        pid=fork();
        //if(pid == 0) write(1, "Hello\n", 6);
    }

    while(wait(NULL) != -1) {};

    if(getpid() != start) exit(0);

    for(i = 0; i < n; ++i) pthread_create(&desc[i], NULL, threadfun, 1);
    for(i = 0; i < n; ++i) pthread_join(desc[i], NULL);

    close(fd);
    exit(0);
}