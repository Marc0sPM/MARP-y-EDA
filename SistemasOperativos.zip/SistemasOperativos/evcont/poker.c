#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <err.h>
#include <signal.h>

#define JUGADORES 12
#define MAX_JUGADORES_PARTIDA 4
#define RONDAS 3

typedef struct {
    int id;
} players_attributes;

pthread_mutex_t m;
pthread_cond_t cond;
int ticket = 0;
int turno = 0;
int players_at_table = 0;
int players_currently_playing = 0;
int canPlay = 1;
int gameInProgress = 0;
int playersPlayed = 0;
int letLeave = 0;

void seat_at_table(int id) {
    int miturno;
    pthread_mutex_lock(&m);
    miturno = ticket++;
    while(miturno != turno || players_at_table == MAX_JUGADORES_PARTIDA || gameInProgress) pthread_cond_wait(&cond, &m);
    fprintf(stdout, "Player with id %d and turn %d has sat on the table.\n", id, miturno);
    players_at_table++;
    turno++;
    pthread_cond_broadcast(&cond);
    if(players_at_table == 4) fprintf(stdout, "All %d players ready! Starting game now!\n", MAX_JUGADORES_PARTIDA);
    pthread_mutex_unlock(&m);
}

void play(int id) {
    pthread_mutex_lock(&m);
    while(players_at_table < MAX_JUGADORES_PARTIDA && !gameInProgress) pthread_cond_wait(&cond, &m);
    gameInProgress = 1;
    fprintf(stdout, "Player with id %d is playing.\n", id);
    pthread_mutex_unlock(&m);
}

void leave_table(int id) {
    pthread_mutex_lock(&m);
    playersPlayed++;
    if(playersPlayed == MAX_JUGADORES_PARTIDA) {
        letLeave = 1;
        pthread_cond_broadcast(&cond);
    }
    while(!letLeave) pthread_cond_wait(&cond, &m);
    fprintf(stdout, "Player with id %d has left the table.\n", id);
    players_at_table--;
    if(players_at_table == 0) {
        playersPlayed = 0;
        letLeave = 0;
        gameInProgress = 0;
        pthread_cond_broadcast(&cond);
        fprintf(stdout, "Player with id %d has been the last one leaving the table and thus broadcasting.\n", id);
    }
    pthread_mutex_unlock(&m);
}

void *player(void *arg) {
    
    players_attributes* attr = (players_attributes*) arg;
    int ronda = RONDAS;
    while(ronda) {
        seat_at_table(attr->id);
        play(attr->id);
        leave_table(attr->id);
        ronda--;
    }

    free(attr);
    pthread_exit(0);
}

void handler(int signal) {
    canPlay = 0;
    fprintf(stdout, "ENDING POKER SIMULATION\n");
}

int main(int argc, char* argv[]) {

    /*struct sigaction action;
    sigset_t mask;
    sigfillset(&mask);
    action.sa_flags = 0;
	action.sa_mask = mask;
	action.sa_handler = handler;
	sigaction(SIGTERM, &action, NULL);
	sigaction(SIGINT, &action, NULL);*/

    pthread_mutex_init(&m, NULL);
    pthread_cond_init(&cond, NULL);
    pthread_t* tid = malloc(JUGADORES * sizeof(pthread_t));

    for(int i = 0; i < JUGADORES; ++i) {
        players_attributes* tmp = malloc(sizeof(players_attributes));
        tmp->id = i;
        pthread_create(&tid[i], NULL, player, tmp);
    }

    for(int j = 0; j < JUGADORES; ++j) {
        pthread_join(tid[j], NULL);
    }

    pthread_cond_destroy(&cond);
    pthread_mutex_destroy(&m);
    free(tid);
    return 0;
}
