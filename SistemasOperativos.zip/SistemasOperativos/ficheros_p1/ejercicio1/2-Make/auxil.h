#ifndef _AUX_H
#define _AUX_H

double sinDegrees(double x);
double cosDegrees(double x);

#endif
